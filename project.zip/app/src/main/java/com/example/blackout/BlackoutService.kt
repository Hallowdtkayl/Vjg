package com.example.blackout

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class BlackoutService : Service() {

    private val channelId = "blackout"
    private var panelOff = false
    private var wakeLock: PowerManager.WakeLock? = null

    // زر الطاقة => النظام يحاول النوم => نستعيد كل شيء ونوقظ الشاشة فورًا
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (panelOff) restore(wake = true)
        }
    }

    override fun onCreate() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "Blackout", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, buildNotification())
        val f = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_OFF -> turnOff()
            ACTION_STOP -> {
                restore(wake = false)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun displayCmd(state: String, apk: String): String =
        "OUT=\$(cmd display power-$state 0 2>&1); " +
        "case \"\$OUT\" in *nknown*|*xception*|*rror*|*nvalid*) " +
        "CLASSPATH=$apk app_process /system/bin com.example.blackout.PowerHelper $state;; esac"

    private fun turnOff() {
        if (panelOff) return
        panelOff = true

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "blackout:cpu").apply { acquire() }

        val apk = applicationInfo.sourceDir
        val lib = applicationInfo.nativeLibraryDir + "/libtouchgrab.so"
        val tmp = "/data/local/tmp"

        val script = listOf(
            "cmd statusbar collapse",
            // احذف أي حجز قديم
            "kill \$(cat $tmp/bo.pid 2>/dev/null) 2>/dev/null",
            // احفظ مهلة الشاشة الأصلية ثم ارفعها للحد الأقصى
            "T=\$(settings get system screen_off_timeout)",
            "[ \"\$T\" != \"2147483647\" ] && echo \$T > $tmp/bo.timeout",
            "settings put system screen_off_timeout 2147483647",
            // احجز جهاز اللمس على مستوى النواة
            "CLASSPATH=$apk nohup app_process /system/bin com.example.blackout.TouchGrab $lib > $tmp/bo.log 2>&1 & echo \$! > $tmp/bo.pid",
            "sleep 1",
            displayCmd("off", apk)
        ).joinToString("; ")
        runRoot(script)
    }

    private fun restore(wake: Boolean) {
        val apk = applicationInfo.sourceDir
        val tmp = "/data/local/tmp"
        val parts = mutableListOf(
            "kill \$(cat $tmp/bo.pid 2>/dev/null) 2>/dev/null",
            "rm -f $tmp/bo.pid",
            "T=\$(cat $tmp/bo.timeout 2>/dev/null)",
            "[ -n \"\$T\" ] && settings put system screen_off_timeout \$T",
            "rm -f $tmp/bo.timeout",
            displayCmd("on", apk)
        )
        if (wake) parts.add("input keyevent KEYCODE_WAKEUP")
        runRoot(parts.joinToString("; "))

        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        panelOff = false
    }

    private fun runRoot(script: String) {
        Thread {
            try {
                Runtime.getRuntime().exec(arrayOf("su", "-c", script)).waitFor()
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun buildNotification(): Notification {
        fun pi(code: Int, action: String) = PendingIntent.getService(
            this, code,
            Intent(this, BlackoutService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_power_off)
            .setContentTitle("إطفاء الشاشة")
            .setContentText("اضغط للإطفاء. زر الطاقة يوقظ الشاشة")
            .setContentIntent(pi(0, ACTION_OFF))
            .addAction(Notification.Action.Builder(null, "إغلاق", pi(1, ACTION_STOP)).build())
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        if (panelOff) restore(wake = false)
    }

    override fun onBind(i: Intent?): IBinder? = null

    companion object {
        const val ACTION_OFF = "com.example.blackout.OFF"
        const val ACTION_STOP = "com.example.blackout.STOP"
    }
}
