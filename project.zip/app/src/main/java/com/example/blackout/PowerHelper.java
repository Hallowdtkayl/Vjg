package com.example.blackout;

import android.os.Build;
import android.os.IBinder;
import java.lang.reflect.Method;

/** يعمل داخل عملية root عبر app_process لإطفاء/تشغيل لوحة العرض فقط. */
public class PowerHelper {
    public static void main(String[] args) {
        try {
            int mode = (args.length > 0 && args[0].equals("off")) ? 0 : 2; // 0=OFF 2=NORMAL
            Class<?> sc = Class.forName("android.view.SurfaceControl");
            IBinder token;

            if (Build.VERSION.SDK_INT >= 34) {
                ClassLoader loader = new dalvik.system.PathClassLoader(
                        "/system/framework/services.jar", ClassLoader.getSystemClassLoader());
                Class<?> dc = loader.loadClass("com.android.server.display.DisplayControl");
                Method ll = Runtime.class.getDeclaredMethod("loadLibrary0", Class.class, String.class);
                ll.setAccessible(true);
                ll.invoke(Runtime.getRuntime(), dc, "android_servers");
                long[] ids = (long[]) dc.getMethod("getPhysicalDisplayIds").invoke(null);
                token = (IBinder) dc.getMethod("getPhysicalDisplayToken", long.class)
                        .invoke(null, ids[0]);
            } else {
                long[] ids = (long[]) sc.getMethod("getPhysicalDisplayIds").invoke(null);
                token = (IBinder) sc.getMethod("getPhysicalDisplayToken", long.class)
                        .invoke(null, ids[0]);
            }
            sc.getMethod("setDisplayPowerMode", IBinder.class, int.class).invoke(null, token, mode);
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
        System.exit(0);
    }
}
