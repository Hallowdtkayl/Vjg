package com.example.blackout

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        val status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = "اضغط الزر لتثبيت الإشعار في الستارة"
        }
        val start = Button(this).apply {
            text = "تشغيل الإشعار"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
                }
                startForegroundService(Intent(this@MainActivity, BlackoutService::class.java))
                status.text = "الإشعار يعمل. اسحب الستارة واضغط عليه.\nزر الطاقة يوقظ الشاشة."
            }
        }
        val note = TextView(this).apply {
            text = "يتطلب Root. امنح الصلاحية في Magisk عند أول إطفاء، واستثنِ التطبيق من توفير البطارية."
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 0)
        }
        root.addView(status); root.addView(start); root.addView(note)
        setContentView(root)
    }
}
