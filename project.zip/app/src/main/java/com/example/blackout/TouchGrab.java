package com.example.blackout;

/** يعمل بصلاحية root عبر app_process: يحجز اللمس ويبقى حيًا حتى يُقتل. */
public class TouchGrab {
    static native int grab();

    public static void main(String[] args) {
        try {
            System.load(args[0]);
            int n = grab();
            System.out.println("grabbed=" + n);
            if (n == 0) System.exit(2);
            while (true) {
                try { Thread.sleep(3600000L); } catch (Throwable ignored) { }
            }
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
    }
}
