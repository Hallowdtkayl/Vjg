#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <linux/input.h>

#define BITS(n) ((n) / 8 + 1)

static int test_bit(int b, const unsigned char *a) {
    return a[b / 8] & (1 << (b % 8));
}

/* يحجز (EVIOCGRAB) كل جهاز لمس. الـ fd تبقى مفتوحة حتى تموت العملية فيتحرر اللمس تلقائيًا */
JNIEXPORT jint JNICALL
Java_com_example_blackout_TouchGrab_grab(JNIEnv *env, jclass clazz) {
    int count = 0;
    char path[64];
    for (int i = 0; i < 64; i++) {
        snprintf(path, sizeof(path), "/dev/input/event%d", i);
        int fd = open(path, O_RDWR);
        if (fd < 0) continue;

        unsigned char ev[BITS(EV_MAX)];
        memset(ev, 0, sizeof(ev));
        ioctl(fd, EVIOCGBIT(0, sizeof(ev)), ev);

        int touch = 0;
        if (test_bit(EV_ABS, ev)) {
            unsigned char abs[BITS(ABS_MAX)];
            memset(abs, 0, sizeof(abs));
            ioctl(fd, EVIOCGBIT(EV_ABS, sizeof(abs)), abs);
            if (test_bit(ABS_MT_POSITION_X, abs)) touch = 1;
        }

        if (touch && ioctl(fd, EVIOCGRAB, 1) == 0) {
            count++;
        } else {
            close(fd);
        }
    }
    return count;
}
