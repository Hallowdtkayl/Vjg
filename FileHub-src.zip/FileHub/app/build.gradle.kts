plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "app.filehub"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.filehub"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.8"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }  // يقلّص حجم libVLC و7-Zip
    }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources { excludes += setOf("META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES", "META-INF/*.md", "META-INF/INDEX.LIST") } }
}
dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("io.coil-kt:coil-compose:2.7.0")   // مصغّرات الصور
    implementation("io.coil-kt:coil-video:2.7.0")     // مصغّرات الفيديو
    // المرحلة 2: العارضات والضغط
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("net.lingala.zip4j:zip4j:2.11.5")             // zip + كلمة مرور + AES
    implementation("com.github.junrar:junrar:7.5.5")             // rar (الإصدار 4)
    implementation("org.apache.commons:commons-compress:1.26.2") // 7z
    implementation("org.tukaani:xz:1.9")
    // المرحلة 3: المشاركة
    implementation("org.nanohttpd:nanohttpd:2.3.1")   // خادم HTTP محلي
    implementation("com.google.zxing:core:3.5.3")     // توليد رمز QR
    // المرحلة 3: المشاركة
    implementation("org.nanohttpd:nanohttpd:2.3.1")   // خادم HTTP محلي
    implementation("com.google.zxing:core:3.5.3")     // توليد رمز QR
    // الإصدار 1.1
    implementation("org.videolan.android:libvlc-all:3.6.0")          // AVI/WMV/FLV… (يتضمن FFmpeg داخلياً)
    implementation("androidx.media3:media3-session:1.4.1")           // تشغيل الصوت في الخلفية
    implementation("com.github.omicronapps:7-Zip-JBinding-4Android:Release-16.02-2.02") // RAR5
    implementation("androidx.webkit:webkit:1.11.0")                      // متصفح الويب (ميزات WebView الحديثة)
    // المراحل القادمة (مُعلّقة الآن):
    // Media3 (فيديو/صوت) • commons-compress/junrar/sevenzipjbinding (ضغط)
    // NanoHTTPD (خادم المشاركة) • ZXing (QR) • Room (سلة المحذوفات)
}
