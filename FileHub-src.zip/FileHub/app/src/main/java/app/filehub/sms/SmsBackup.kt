package app.filehub.sms

import android.content.ContentValues
import android.content.Context
import android.provider.Telephony
import android.util.Xml
import app.filehub.phone.ContactsLookup
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** تصدير/استيراد بصيغة XML المتوافقة مع تطبيق «SMS Backup & Restore» */
object SmsBackup {
    private fun esc(s: String?): String {
        if (s == null) return ""
        val b = StringBuilder(s.length + 8)
        for (c in s) when {
            c == '&' -> b.append("&amp;"); c == '<' -> b.append("&lt;"); c == '>' -> b.append("&gt;")
            c == '"' -> b.append("&quot;"); c == '\'' -> b.append("&apos;")
            c == '\n' -> b.append("&#10;"); c == '\r' -> b.append("&#13;"); c == '\t' -> b.append("&#9;")
            c.code < 0x20 -> {}
            else -> b.append(c)
        }
        return b.toString()
    }

    /** threadId == null → كل الرسائل. يرجع عدد الرسائل المصدَّرة */
    fun export(ctx: Context, out: OutputStream, threadId: Long?): Int {
        val sel = threadId?.let { "thread_id=$it" }
        val total = ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms._ID), sel, null, null)?.use { it.count } ?: 0
        val fmt = SimpleDateFormat("d MMM yyyy HH:mm:ss", Locale.US)
        val names = HashMap<String, String?>()
        var n = 0
        out.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>\n<smses count=\"$total\">\n")
            ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "date", "date_sent", "type", "body", "read", "status"), sel, null, "date ASC")?.use { c ->
                while (c.moveToNext()) {
                    val a = c.getString(0).orEmpty()
                    val name = names.getOrPut(a) { ContactsLookup.lookup(ctx, a)?.name }
                    w.write("  <sms protocol=\"0\" address=\"${esc(a)}\" date=\"${c.getLong(1)}\" type=\"${c.getInt(3)}\" subject=\"null\" body=\"${esc(c.getString(4))}\" " +
                        "toa=\"null\" sc_toa=\"null\" service_center=\"null\" read=\"${c.getInt(5)}\" status=\"${c.getInt(6)}\" locked=\"0\" " +
                        "date_sent=\"${c.getLong(2)}\" readable_date=\"${fmt.format(Date(c.getLong(1)))}\" contact_name=\"${esc(name ?: "(Unknown)")}\" />\n")
                    n++
                }
            }
            w.write("</smses>\n")
        }
        return n
    }

    private fun key(addr: String, date: Long, type: Int) = "${addr.filter { it.isDigit() }.takeLast(9)}|$date|$type"

    /** يرجع (المستورد، المتخطّى لأنه مكرر). يتطلب أن نكون تطبيق الرسائل الافتراضي */
    fun import(ctx: Context, input: InputStream): Pair<Int, Int> {
        check(SmsRepo.isDefault(ctx)) { "الاستيراد يتطلب جعل «ملفاتي» تطبيق الرسائل الافتراضي" }
        val existing = HashSet<String>()
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "date", "type"), null, null, null)?.use { c ->
            while (c.moveToNext()) existing.add(key(c.getString(0).orEmpty(), c.getLong(1), c.getInt(2)))
        }
        val p = Xml.newPullParser(); p.setInput(input, "UTF-8")
        val batch = ArrayList<ContentValues>()
        var imported = 0; var skipped = 0
        fun flush() { if (batch.isNotEmpty()) { ctx.contentResolver.bulkInsert(Telephony.Sms.CONTENT_URI, batch.toTypedArray()); imported += batch.size; batch.clear() } }
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name == "sms") {
                val addr = p.getAttributeValue(null, "address").orEmpty()
                val date = p.getAttributeValue(null, "date")?.toLongOrNull() ?: 0L
                val type = p.getAttributeValue(null, "type")?.toIntOrNull() ?: 1
                if (addr.isNotEmpty() && type in 1..6) {
                    if (existing.add(key(addr, date, type))) {
                        batch.add(ContentValues().apply {
                            put("address", addr); put("body", p.getAttributeValue(null, "body").orEmpty()); put("date", date)
                            put("date_sent", p.getAttributeValue(null, "date_sent")?.toLongOrNull() ?: 0L); put("type", type)
                            put("read", p.getAttributeValue(null, "read")?.toIntOrNull() ?: 1); put("seen", 1)
                            put("status", p.getAttributeValue(null, "status")?.toIntOrNull() ?: -1)
                        })
                        if (batch.size >= 200) flush()
                    } else skipped++
                }
            }
            ev = p.next()
        }
        flush()
        return imported to skipped
    }
}
