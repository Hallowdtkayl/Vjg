package app.filehub.ui.screens

import app.filehub.clock.AlarmScheduler as ClockAlarmScheduler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import app.filehub.FileApp
import app.filehub.ui.components.SectionTitle

@Composable
private fun Choice(title: String, options: List<Pair<String, Int>>, current: Int, onPick: (Int) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (label, v) -> FilterChip(current == v, { onPick(v) }, { Text(label) }) }
        }
    }
}

@Composable
fun SettingsScreen(pad: PaddingValues) {
    val app = LocalContext.current.applicationContext as FileApp
    val st = app.settings
    val ctx = LocalContext.current
    var portText by remember { mutableStateOf(st.port.toString()) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(app.prefs.exportJson().toByteArray(Charsets.UTF_8)) }
        }.onSuccess { Toast.makeText(ctx, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show() }
         .onFailure { Toast.makeText(ctx, "تعذّر الحفظ: ${it.message}", Toast.LENGTH_LONG).show() }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val text = ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }
            app.prefs.importJson(text)
        }.onSuccess { n -> st.reload(); portText = st.port.toString(); app.repo.invalidate(); ClockAlarmScheduler.rescheduleAll(ctx)
            Toast.makeText(ctx, "تمت استعادة $n إعداد", Toast.LENGTH_SHORT).show() }
         .onFailure { Toast.makeText(ctx, "ملف غير صالح: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle("المظهر") }
        item { Choice("الثيم", listOf("تلقائي" to 0, "فاتح" to 1, "داكن" to 2), st.theme) { st.theme = it; st.save() } }

        item { SectionTitle("الملفات") }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("إظهار الملفات المخفية", Modifier.weight(1f))
                Switch(st.showHidden, { st.showHidden = it; st.save(); app.repo.invalidate() })
            }
        }
        item { Choice("مدة بقاء الملفات في السلة", listOf("7 أيام" to 7, "30 يوماً" to 30, "90 يوماً" to 90), st.trashDays) { st.trashDays = it; st.save() } }

        item { SectionTitle("المشاركة") }
        item {
            OutlinedTextField(portText, { v ->
                portText = v.filter { it.isDigit() }.take(5)
                portText.toIntOrNull()?.takeIf { it in 1024..65535 }?.let { st.port = it; st.save() }
            }, Modifier.fillMaxWidth().padding(horizontal = 20.dp), singleLine = true,
                label = { Text("منفذ الخادم (1024–65535)") },
                supportingText = { Text("إن كان مشغولاً يُختار منفذ حر تلقائياً") })
        }
        item { Choice("إيقاف المشاركة تلقائياً بعد", listOf("بلا" to 0, "15 د" to 15, "30 د" to 30, "60 د" to 60), st.autoStop) { st.autoStop = it; st.save() } }

        item { SectionTitle("النسخ الاحتياطي") }
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton({
                    exporter.launch("filehub-backup-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".json")
                }) { Text("تصدير الإعدادات") }
                OutlinedButton({ importer.launch(arrayOf("application/json", "*/*")) }) { Text("استعادة") }
            }
            Text("يشمل الثيم والمنفذ ومدة السلة وأسلوب الترتيب والعرض لكل تصنيف. يمكنك حفظ الملف في Drive أو بطاقة الذاكرة.",
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { SectionTitle("حول") }
        item {
            ElevatedCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ملفاتي 1.1", style = MaterialTheme.typography.titleMedium)
                    Text("مستكشف ملفات مع عارضات داخلية، وفك ضغط zip وrar و7z، ومشاركة عبر QR على الشبكة المحلية.",
                        style = MaterialTheme.typography.bodySmall)
                    Text("المكتبات: Jetpack Compose • Media3 • zip4j • junrar • Apache Commons Compress • NanoHTTPD • ZXing • Coil",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
