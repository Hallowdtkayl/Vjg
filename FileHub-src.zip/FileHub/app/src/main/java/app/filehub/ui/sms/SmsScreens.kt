package app.filehub.ui.sms

import android.Manifest
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.filehub.phone.Blocklist
import app.filehub.phone.ContactHit
import app.filehub.phone.ContactsLookup
import app.filehub.phone.DialerUtil
import app.filehub.sms.*
import app.filehub.ui.components.RequirePerms
import app.filehub.ui.phone.Avatar
import app.filehub.ui.readableDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val SMS_PERMS: Array<String> = buildList {
    addAll(listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
        Manifest.permission.RECEIVE_MMS, Manifest.permission.RECEIVE_WAP_PUSH, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE))
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()
private fun timeOf(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
private fun dayKey(t: Long) = Calendar.getInstance().apply { timeInMillis = t }.let { it.get(Calendar.YEAR) * 400 + it.get(Calendar.DAY_OF_YEAR) }
private fun dayLabel(t: Long): String {
    val d = dayKey(System.currentTimeMillis()) - dayKey(t)
    return when (d) { 0 -> "اليوم"; 1 -> "أمس"; else -> t.readableDate() }
}
private fun listTime(t: Long) = if (dayKey(t) == dayKey(System.currentTimeMillis())) timeOf(t) else if (dayKey(System.currentTimeMillis()) - dayKey(t) == 1) "أمس" else t.readableDate()

@Composable
private fun rememberDefaultSms(): Pair<Boolean, () -> Unit> {
    val ctx = LocalContext.current
    var isDef by remember { mutableStateOf(SmsRepo.isDefault(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { isDef = SmsRepo.isDefault(ctx) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { isDef = SmsRepo.isDefault(ctx) }
    return isDef to { runCatching { launcher.launch(SmsRepo.requestIntent(ctx)) } }
}

@Composable
private fun DefaultBanner(onRequest: () -> Unit) = Card(Modifier.padding(12.dp).fillMaxWidth(), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
    Column(Modifier.padding(14.dp)) {
        Text("اجعل «ملفاتي» تطبيق الرسائل الافتراضي", fontWeight = FontWeight.SemiBold)
        Text("بدونه لا يمكن حفظ الرسائل المرسلة ولا استقبال الجديدة ولا الاستيراد.", style = MaterialTheme.typography.bodySmall)
        TextButton(onRequest) { Text("تعيين كافتراضي") }
    }
}

// ───────────────────────── قائمة المحادثات ─────────────────────────
class MessagesViewModel(app: Application) : AndroidViewModel(app) {
    var threads by mutableStateOf<List<SmsThread>>(emptyList()); private set
    var loading by mutableStateOf(true); private set
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(s: Boolean) { reload() } }
    init { app.contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs); reload() }
    fun reload() {
        viewModelScope.launch {
            threads = withContext(Dispatchers.IO) { runCatching { SmsRepo.threads(getApplication()) }.getOrDefault(emptyList()) }
            loading = false
        }
    }
    fun deleteThreads(ids: Collection<Long>) { viewModelScope.launch(Dispatchers.IO) { ids.forEach { runCatching { SmsRepo.deleteThread(getApplication(), it) } }; reload() } }
    fun markRead(ids: Collection<Long>) { viewModelScope.launch(Dispatchers.IO) { ids.forEach { SmsRepo.markThreadRead(getApplication(), it) }; reload() } }
    fun markAllRead() { viewModelScope.launch(Dispatchers.IO) { SmsRepo.markAllRead(getApplication()); reload() } }
    override fun onCleared() { getApplication<Application>().contentResolver.unregisterContentObserver(obs) }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun MessagesScreen(onBack: () -> Unit, onThread: (Long, String) -> Unit, onNew: () -> Unit) {
    RequirePerms(SMS_PERMS, "صلاحيات الرسائل", "لقراءة الرسائل وإرسالها واستقبالها.", Icons.Rounded.Sms) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val vm: MessagesViewModel = viewModel()
        val (isDef, requestDef) = rememberDefaultSms()
        var filter by remember { mutableIntStateOf(0) }
        var query by remember { mutableStateOf("") }
        var searching by remember { mutableStateOf(false) }
        var selected by remember { mutableStateOf(setOf<Long>()) }
        var menu by remember { mutableStateOf(false) }
        var confirmDelete by remember { mutableStateOf(false) }
        val selecting = selected.isNotEmpty()

        val shown = remember(vm.threads, filter, query) {
            vm.threads.filter { (filter == 0 || it.unread > 0) && (query.isBlank() || it.name?.contains(query, true) == true || it.address.contains(query) || it.snippet.contains(query, true)) }
        }
        val hits by produceState(emptyList<SmsMsg>(), query) {
            delay(250); value = if (query.length >= 2) withContext(Dispatchers.IO) { runCatching { SmsRepo.search(ctx, query) }.getOrDefault(emptyList()) } else emptyList()
        }
        val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/xml")) { uri ->
            if (uri != null) scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { SmsBackup.export(ctx, it, null) } } }
                toast(ctx, r.fold({ "تم تصدير $it رسالة" }, { "تعذّر التصدير: ${it.message}" }))
            }
        }
        val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) scope.launch {
                toast(ctx, "جارٍ الاستيراد…")
                val r = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)!!.use { SmsBackup.import(ctx, it) } } }
                toast(ctx, r.fold({ "استُورد ${it.first} رسالة، وتُخطّي ${it.second} مكررة" }, { it.message ?: "فشل الاستيراد" })); vm.reload()
            }
        }
        BackHandler2(selecting) { selected = emptySet() }

        Scaffold(
            topBar = {
                if (selecting) TopAppBar(title = { Text("${selected.size} محدد") },
                    navigationIcon = { IconButton({ selected = emptySet() }) { Icon(Icons.Rounded.Close, "إلغاء") } },
                    actions = {
                        IconButton({ selected = shown.map { it.id }.toSet() }) { Icon(Icons.Rounded.SelectAll, "الكل") }
                        IconButton({ vm.markRead(selected); selected = emptySet() }) { Icon(Icons.Rounded.MarkEmailRead, "مقروءة") }
                        IconButton({
                            val addrs = vm.threads.filter { it.id in selected }.map { it.address }
                            val ok = addrs.count { Blocklist.block(ctx, it) }
                            toast(ctx, if (ok > 0) "تم حظر $ok" else "الحظر يتطلب جعل التطبيق الافتراضي"); selected = emptySet()
                        }) { Icon(Icons.Rounded.Block, "حظر") }
                        IconButton({ confirmDelete = true }) { Icon(Icons.Rounded.Delete, "حذف") }
                    })
                else TopAppBar(
                    title = { if (searching) TextField(query, { query = it }, singleLine = true, placeholder = { Text("بحث في الرسائل") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent, unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                            focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent, unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent)) else Text("الرسائل") },
                    navigationIcon = { IconButton({ if (searching) { searching = false; query = "" } else onBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                    actions = {
                        if (!searching) IconButton({ searching = true }) { Icon(Icons.Rounded.Search, "بحث") }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "المزيد") }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text("تعليم الكل كمقروء") }, { vm.markAllRead(); menu = false })
                                DropdownMenuItem({ Text("تصدير الرسائل (XML)") }, { exporter.launch("sms-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".xml"); menu = false })
                                DropdownMenuItem({ Text("استيراد رسائل (XML)") }, { importer.launch(arrayOf("text/xml", "application/xml", "*/*")); menu = false })
                            }
                        }
                    })
            },
            floatingActionButton = { FloatingActionButton(onNew) { Icon(Icons.Rounded.Edit, "رسالة جديدة") } }
        ) { pad ->
            Column(Modifier.padding(pad)) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp, 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(filter == 0, { filter = 0 }, { Text("الكل") })
                    FilterChip(filter == 1, { filter = 1 }, { Text("غير مقروءة") })
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    if (!isDef) item { DefaultBanner(requestDef) }
                    if (vm.loading) item { Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { CircularProgressIndicator() } }
                    else if (shown.isEmpty()) item { Text("لا توجد رسائل", Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(shown, key = { it.id }) { t ->
                        val title = t.name ?: t.address.ifEmpty { "مجهول" }
                        val sel = t.id in selected
                        Row(Modifier.fillMaxWidth().background(if (sel) MaterialTheme.colorScheme.primaryContainer else androidx.compose.ui.graphics.Color.Transparent)
                            .combinedClickable(onClick = { if (selecting) selected = if (sel) selected - t.id else selected + t.id else onThread(t.id, t.address) },
                                onLongClick = { selected = if (sel) selected - t.id else selected + t.id })
                            .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(title, t.photo)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = if (t.unread > 0) FontWeight.Bold else FontWeight.Medium)
                                Text((if (t.lastType == Telephony.Sms.MESSAGE_TYPE_SENT) "أنت: " else "") + t.snippet, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodyMedium, color = if (t.unread > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = if (t.unread > 0) FontWeight.SemiBold else FontWeight.Normal)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(listTime(t.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (t.unread > 0) Badge { Text(t.unread.toString()) }
                            }
                        }
                    }
                    if (hits.isNotEmpty()) {
                        item { Text("نتائج في نصوص الرسائل", Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                        items(hits, key = { "m" + it.id }) { m ->
                            ListItem({ Text(m.body, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                                supportingContent = { Text(m.address + " • " + m.date.readableDate()) },
                                modifier = Modifier.clickable { onThread(m.threadId, m.address) })
                        }
                    }
                }
            }
        }
        if (confirmDelete) AlertDialog({ confirmDelete = false }, title = { Text("حذف ${selected.size} محادثة؟") }, text = { Text("لا يمكن التراجع.") },
            confirmButton = { TextButton({ vm.deleteThreads(selected); selected = emptySet(); confirmDelete = false }) { Text("حذف") } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("إلغاء") } })
    }
}

@Composable
private fun BackHandler2(enabled: Boolean, onBack: () -> Unit) = androidx.activity.compose.BackHandler(enabled, onBack)

// ───────────────────────── شاشة المحادثة ─────────────────────────
class ThreadViewModel(app: Application, tid: Long) : AndroidViewModel(app) {
    var threadId by mutableLongStateOf(tid); private set
    var msgs by mutableStateOf<List<SmsMsg>>(emptyList()); private set
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(s: Boolean) { reload() } }
    init { app.contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs); reload() }
    fun reload() {
        val id = threadId
        if (id < 0) return
        viewModelScope.launch { msgs = withContext(Dispatchers.IO) { runCatching { SmsRepo.messages(getApplication(), id) }.getOrDefault(emptyList()) } }
    }
    fun bind(id: Long) { threadId = id; reload() }
    fun markRead() { val id = threadId; if (id >= 0) viewModelScope.launch(Dispatchers.IO) { SmsRepo.markThreadRead(getApplication(), id); app.filehub.sms.MessageNotifier.cancel(getApplication(), id) } }
    override fun onCleared() { getApplication<Application>().contentResolver.unregisterContentObserver(obs) }
}

private sealed interface Row { data class M(val m: SmsMsg) : Row; data class D(val label: String) : Row }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ThreadScreen(threadId0: Long, address0: String, body0: String, onBack: () -> Unit, onContact: (String) -> Unit, onForward: (String) -> Unit) {
    RequirePerms(SMS_PERMS, "صلاحيات الرسائل", "لقراءة الرسائل وإرسالها واستقبالها.", Icons.Rounded.Sms) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val vm: ThreadViewModel = viewModel(key = "t$threadId0|$address0", factory = viewModelFactory {
            initializer { ThreadViewModel(this[APPLICATION_KEY] as Application, threadId0) }
        })
        val (isDef, requestDef) = rememberDefaultSms()
        var address by remember { mutableStateOf(address0) }
        var text by remember { mutableStateOf(body0) }
        val sims = remember { SmsRepo.sims(ctx) }
        var sim by remember { mutableIntStateOf(-1) }
        var menuFor by remember { mutableStateOf<Long?>(null) }
        var topMenu by remember { mutableStateOf(false) }
        var confirmDelete by remember { mutableStateOf(false) }
        var needDefault by remember { mutableStateOf(false) }
        val isNew = vm.threadId < 0
        val info by produceState<app.filehub.phone.ContactInfo?>(null, address) { value = withContext(Dispatchers.IO) { ContactsLookup.lookup(ctx, address) } }
        val suggestions by produceState(emptyList<ContactHit>(), address, isNew) {
            delay(150); value = if (isNew && address0.isEmpty() && address.length >= 2) withContext(Dispatchers.IO) { ContactsLookup.search(ctx, address, 5) } else emptyList()
        }
        val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/xml")) { uri ->
            if (uri != null) scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { SmsBackup.export(ctx, it, vm.threadId) } } }
                toast(ctx, r.fold({ "تم تصدير $it رسالة" }, { "تعذّر التصدير: ${it.message}" }))
            }
        }

        LaunchedEffect(address0) { if (isNew && address0.isNotBlank()) withContext(Dispatchers.IO) { SmsRepo.threadForAddress(ctx, address0) }?.let { vm.bind(it) } }
        LaunchedEffect(vm.msgs.size) { vm.markRead() }

        val rows = remember(vm.msgs) {
            val rev = vm.msgs.asReversed(); val out = ArrayList<Row>()
            rev.forEachIndexed { i, m -> out.add(Row.M(m)); val n = rev.getOrNull(i + 1); if (n == null || dayKey(n.date) != dayKey(m.date)) out.add(Row.D(dayLabel(m.date))) }
            out
        }
        fun send() {
            val to = address.trim(); val t = text.trim()
            if (to.isEmpty() || t.isEmpty()) return
            if (!isDef) { needDefault = true; return }
            scope.launch {
                val ok = withContext(Dispatchers.IO) { SmsRepo.send(ctx, to, t, sim) }
                if (ok) { text = ""; delay(500); if (vm.threadId < 0) withContext(Dispatchers.IO) { SmsRepo.threadForAddress(ctx, to) }?.let { vm.bind(it) }; vm.reload() }
                else toast(ctx, "تعذّر الإرسال")
            }
        }

        Scaffold(topBar = {
            TopAppBar(
                title = {
                    if (isNew && address0.isEmpty()) TextField(address, { address = it.filter { c -> c.isDigit() || c in "+*# " || c.isLetter() } }, singleLine = true,
                        placeholder = { Text("إلى: اسم أو رقم") }, colors = TextFieldDefaults.colors(focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                            unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent, focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent, unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent))
                    else Row(Modifier.clickable { onContact(address) }, verticalAlignment = Alignment.CenterVertically) {
                        Avatar(info?.name ?: address, info?.photo, 36); Spacer(Modifier.width(10.dp))
                        Column { Text(info?.name ?: address.ifEmpty { "رسالة جديدة" }, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            if (info != null) Text(address, style = MaterialTheme.typography.labelSmall) }
                    }
                },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                actions = {
                    if (address.isNotBlank()) IconButton({ DialerUtil.call(ctx, address) }) { Icon(Icons.Rounded.Call, "اتصال") }
                    Box {
                        IconButton({ topMenu = true }) { Icon(Icons.Rounded.MoreVert, "المزيد") }
                        DropdownMenu(topMenu, { topMenu = false }) {
                            DropdownMenuItem({ Text("حظر الرقم") }, { topMenu = false; toast(ctx, if (Blocklist.block(ctx, address)) "تم الحظر" else "الحظر يتطلب جعل التطبيق الافتراضي") })
                            if (!isNew) {
                                DropdownMenuItem({ Text("تصدير المحادثة") }, { topMenu = false; exporter.launch("sms-" + address.filter { it.isDigit() } + ".xml") })
                                DropdownMenuItem({ Text("حذف المحادثة") }, { topMenu = false; confirmDelete = true })
                            }
                        }
                    }
                })
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
                if (!isDef) DefaultBanner(requestDef)
                suggestions.forEach { h ->
                    ListItem({ Text(h.name) }, supportingContent = { Text(h.number) }, leadingContent = { Avatar(h.name, h.photo, 36) },
                        modifier = Modifier.clickable { address = h.number })
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = true, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(rows, key = { when (it) { is Row.M -> "m${it.m.id}"; is Row.D -> "d${it.label}${rows.indexOf(it)}" } }) { r ->
                        when (r) {
                            is Row.D -> Text(r.label, Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            is Row.M -> {
                                val m = r.m
                                val mine = m.type != Telephony.Sms.MESSAGE_TYPE_INBOX
                                val failed = m.type == Telephony.Sms.MESSAGE_TYPE_FAILED
                                Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
                                    Surface(
                                        color = if (failed) MaterialTheme.colorScheme.errorContainer else if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(18.dp, 18.dp, if (mine) 4.dp else 18.dp, if (mine) 18.dp else 4.dp),
                                        modifier = Modifier.widthIn(max = 300.dp).combinedClickable(
                                            onClick = { if (failed) { scope.launch(Dispatchers.IO) { SmsRepo.deleteMessages(ctx, listOf(m.id)); SmsRepo.send(ctx, m.address, m.body, sim) } } },
                                            onLongClick = { menuFor = m.id })) {
                                        Column(Modifier.padding(12.dp, 8.dp)) {
                                            Text(m.body)
                                            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                                                if (failed) Text("فشل الإرسال — اضغط للإعادة  ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                                else if (m.type == Telephony.Sms.MESSAGE_TYPE_OUTBOX || m.type == Telephony.Sms.MESSAGE_TYPE_QUEUED) Icon(Icons.Rounded.Schedule, null, Modifier.size(12.dp))
                                                Text(timeOf(m.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                        DropdownMenu(menuFor == m.id, { menuFor = null }) {
                                            DropdownMenuItem({ Text("نسخ") }, { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sms", m.body)); menuFor = null; toast(ctx, "تم النسخ") })
                                            DropdownMenuItem({ Text("إعادة توجيه") }, { menuFor = null; onForward(m.body) })
                                            DropdownMenuItem({ Text("حذف") }, { menuFor = null; scope.launch(Dispatchers.IO) { SmsRepo.deleteMessages(ctx, listOf(m.id)) } })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (sims.size > 1) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    sims.forEach { (id, label) -> FilterChip(sim == id || (sim < 0 && id == sims.first().first), { sim = id }, { Text(label) }) }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") }, maxLines = 5, shape = RoundedCornerShape(24.dp),
                        supportingText = { if (text.length > 100) Text("${text.length} حرفاً • ${SmsRepo.segments(ctx, text)} رسالة") })
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(::send, Modifier.size(52.dp), enabled = text.isNotBlank() && address.isNotBlank()) { Icon(Icons.AutoMirrored.Rounded.Send, "إرسال") }
                }
            }
        }
        if (needDefault) AlertDialog({ needDefault = false }, title = { Text("تطبيق الرسائل الافتراضي") },
            text = { Text("لحفظ الرسائل المرسلة يجب جعل «ملفاتي» تطبيق الرسائل الافتراضي.") },
            confirmButton = { TextButton({ needDefault = false; requestDef() }) { Text("تعيين") } },
            dismissButton = { TextButton({ needDefault = false }) { Text("إلغاء") } })
        if (confirmDelete) AlertDialog({ confirmDelete = false }, title = { Text("حذف المحادثة؟") }, text = { Text("لا يمكن التراجع.") },
            confirmButton = { TextButton({ confirmDelete = false; scope.launch(Dispatchers.IO) { SmsRepo.deleteThread(ctx, vm.threadId) }; onBack() }) { Text("حذف") } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("إلغاء") } })
    }
}
