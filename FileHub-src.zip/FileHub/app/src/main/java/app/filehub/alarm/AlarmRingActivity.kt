package app.filehub.alarm

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.filehub.ui.theme.FileHubTheme
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

class AlarmRingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else @Suppress("DEPRECATION") window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { FileHubTheme(dark = true) { RingScreen { finish() } } }
    }
}

@Composable
private fun RingScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val ring by RingState.current.collectAsState()
    var seen by remember { mutableStateOf(false) }
    LaunchedEffect(ring) { if (ring != null) seen = true else { delay(if (seen) 150 else 2000); if (RingState.current.value == null) onDone() } }
    fun send(a: String) = ctx.startService(Intent(ctx, AlarmService::class.java).setAction(a))
    val r = ring
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B2250), Color(0xFF0B0D17)))), Alignment.Center) {
        if (r != null) Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Icon(Icons.Rounded.Alarm, null, Modifier.size(72.dp), tint = Color.White)
            Spacer(Modifier.height(16.dp))
            Text(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(now)), fontSize = 64.sp, color = Color.White)
            Text(r.label.ifBlank { r.title }, fontSize = 24.sp, color = Color.White.copy(alpha = .85f), textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            if (r.snoozeMin > 0) FilledTonalButton({ send(AlarmService.ACT_SNOOZE) }, Modifier.fillMaxWidth().height(64.dp)) { Text("غفوة ${r.snoozeMin} دقائق", fontSize = 18.sp) }
            if (r.kind == "timer") FilledTonalButton({ send(AlarmService.ACT_ADD_MIN) }, Modifier.fillMaxWidth().height(64.dp)) { Text("+1 دقيقة", fontSize = 18.sp) }
            Spacer(Modifier.height(14.dp))
            Button({ send(AlarmService.ACT_DISMISS) }, Modifier.fillMaxWidth().height(72.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("إيقاف", fontSize = 22.sp) }
            Spacer(Modifier.height(32.dp))
        }
    }
}
