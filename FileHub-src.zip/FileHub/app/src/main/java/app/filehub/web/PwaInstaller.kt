package app.filehub.web

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import org.json.JSONObject
import java.net.URI

/** بيانات manifest مبسّطة لموقع ويب تقدمي (PWA) */
data class WebManifest(val name: String, val startUrl: String, val scope: String, val display: String, val themeColor: Int?, val iconUrl: String?)

/**
 * «تثبيت الموقع» كتطبيق: نقرأ manifest الصفحة (إن وُجد) ثم ننشئ:
 *  1) سجلاً في قاعدة البيانات يظهر في الشاشة الرئيسية للتطبيق
 *  2) اختصاراً مثبّتاً على شاشة الجهاز يفتح WebAppActivity (نافذة مستقلة بلا شريط عنوان)
 * ملاحظة: هذا ليس WebAPK من كروم (لا يتوفر لتطبيقات الطرف الثالث)، لكنه يعطي التجربة نفسها تقريباً.
 */
object PwaInstaller {
    /** JS يُنفَّذ في الصفحة لإرجاع رابط manifest والأيقونة والعنوان ولون السمة */
    const val PROBE_JS = """(function(){
        var m=document.querySelector('link[rel="manifest"]');
        var i=document.querySelector('link[rel~="apple-touch-icon"]')||document.querySelector('link[rel~="icon"]');
        var t=document.querySelector('meta[name="theme-color"]');
        return JSON.stringify({manifest:m?m.href:null,icon:i?i.href:null,title:document.title,theme:t?t.content:null});})()"""

    fun parseManifest(json: String, manifestUrl: String, pageUrl: String): WebManifest? = runCatching {
        val o = JSONObject(json)
        fun abs(u: String) = URI(manifestUrl).resolve(u).toString()
        val start = abs(o.optString("start_url", pageUrl))
        val icons = o.optJSONArray("icons")
        var best: String? = null; var bestSize = 0
        if (icons != null) for (n in 0 until icons.length()) {
            val ic = icons.getJSONObject(n)
            val sz = ic.optString("sizes", "0x0").substringBefore('x').toIntOrNull() ?: 0
            if (sz >= bestSize) { bestSize = sz; best = abs(ic.getString("src")) }
        }
        WebManifest(o.optString("short_name").ifBlank { o.optString("name", "") }, start,
            o.optString("scope").takeIf { it.isNotBlank() }?.let { abs(it) } ?: start.substringBeforeLast('/') + "/",
            o.optString("display", "standalone"), runCatching { Color.parseColor(o.optString("theme_color")) }.getOrNull(), best)
    }.getOrNull()

    /** أيقونة بديلة: أول حرف من الاسم على خلفية ملوّنة */
    fun letterIcon(name: String, color: Int = Color.parseColor("#3949D6")): Bitmap {
        val b = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(color)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE; textSize = 110f; textAlign = Paint.Align.CENTER }
        c.drawText(name.firstOrNull { it.isLetter() }?.uppercase() ?: "W", 96f, 96f - (p.descent() + p.ascent()) / 2, p)
        return b
    }

    fun launchIntent(ctx: Context, site: PinnedSite) = Intent(ctx, WebAppActivity::class.java).setAction(Intent.ACTION_VIEW)
        .setData(Uri.parse(site.url)).putExtra("site_id", site.id).putExtra("scope", site.scope).putExtra("name", site.name)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)

    fun launch(ctx: Context, site: PinnedSite) { ctx.startActivity(launchIntent(ctx, site).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    /** يضيف الموقع ويطلب من النظام تثبيت اختصار في شاشة الجهاز */
    fun install(ctx: Context, site: PinnedSite, icon: Bitmap?): Boolean {
        val id = WebDb.get(ctx).addPinned(site)
        val saved = site.copy(id = id)
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) return true      // يبقى ظاهراً داخل التطبيق فقط
        val info = ShortcutInfoCompat.Builder(ctx, "site_$id").setShortLabel(site.name.take(24)).setLongLabel(site.name)
            .setIcon(IconCompat.createWithBitmap(icon ?: letterIcon(site.name))).setIntent(launchIntent(ctx, saved)).build()
        return ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    }
    // TODO(phase-2): تنزيل الأيقونة من iconUrl، اكتشاف قابلية التثبيت تلقائياً بعد تحميل الصفحة، تحديث الأيقونة دورياً
}
