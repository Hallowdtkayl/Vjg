package app.filehub.ui.clock

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.filehub.clock.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// أيام الأسبوع بترتيب عربي (السبت أولاً) مع قيمة Calendar.DAY_OF_WEEK
private val DAYS = listOf(7 to "سبت", 1 to "أحد", 2 to "إثنين", 3 to "ثلاثاء", 4 to "أربعاء", 5 to "خميس", 6 to "جمعة")

private fun daysText(mask: Int): String = when {
    mask == 0 -> "مرة واحدة"
    mask == 127 -> "كل يوم"
    else -> DAYS.filter { (mask shr (it.first - 1)) and 1 == 1 }.joinToString(" • ") { it.second }
}

private fun timeText(ctx: Context, h: Int, m: Int): String {
    val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }
    return SimpleDateFormat(if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a", Locale.getDefault()).format(c.time)
}

private fun remainingText(ms: Long): String {
    val mins = (ms / 60_000).coerceAtLeast(0)
    val d = mins / 1440; val h = (mins % 1440) / 60; val m = mins % 60
    return buildString {
        if (d > 0) append("$d يوم ")
        if (h > 0) append("$h ساعة ")
        append(if (m > 0 || (d == 0L && h == 0L)) "$m دقيقة" else "")
    }.trim()
}

private fun clockText(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)
}

private fun swText(ms: Long): String {
    val cs = (ms / 10) % 100; val s = ms / 1000
    return (if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)) + ".%02d".format(cs)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClockScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var fsOk by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { ClockModel.load(ctx); Stopwatch.load(ctx) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        ClockModel.load(ctx)
        fsOk = Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    Scaffold(topBar = {
        TopAppBar(title = { Text("الساعة") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("المنبه") }, icon = { Icon(Icons.Rounded.Alarm, null) })
                Tab(tab == 1, { tab = 1 }, text = { Text("المؤقّت") }, icon = { Icon(Icons.Rounded.HourglassBottom, null) })
                Tab(tab == 2, { tab = 2 }, text = { Text("ساعة الإيقاف") }, icon = { Icon(Icons.Rounded.Timer, null) })
            }
            if (!fsOk) Card(Modifier.padding(12.dp).fillMaxWidth(), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.errorContainer)) {
                Column(Modifier.padding(14.dp)) {
                    Text("لتظهر شاشة المنبه كاملة فوق القفل، فعّل «الإشعارات بملء الشاشة» للتطبيق.", style = MaterialTheme.typography.bodyMedium)
                    TextButton({ runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))) } }) { Text("فتح الإعداد") }
                }
            }
            when (tab) { 0 -> AlarmsTab(); 1 -> TimersTab(); else -> StopwatchTab() }
        }
    }
}

// ───────────────────────── المنبهات ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmsTab() {
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf<Alarm?>(null) }
    val alarms = ClockModel.alarms.sortedWith(compareBy({ it.hour }, { it.minute }))
    val next = ClockModel.alarms.filter { it.enabled }.minOfOrNull { AlarmScheduler.nextTrigger(it) }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(15_000) } }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(if (next != null) "يرنّ المنبه القادم بعد ${remainingText(next - now)}" else "لا توجد منبهات مفعّلة",
                    style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp))
            }
            if (alarms.isEmpty()) item { Text("اضغط + لإضافة منبه", Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(alarms, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth().clickable { editing = a }, colors = CardDefaults.cardColors(if (a.enabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(timeText(ctx, a.hour, a.minute), fontSize = 40.sp, fontWeight = FontWeight.Light,
                                    color = if (a.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(listOf(a.label, daysText(a.days)).filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(a.enabled, { ClockModel.toggleAlarm(ctx, a.id, it) })
                    }
                }
            }
        }
        FloatingActionButton({ val c = Calendar.getInstance(); editing = Alarm(0, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)) },
            Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Icon(Icons.Rounded.Add, "إضافة منبه") }
    }
    editing?.let { a -> AlarmEditor(a, { editing = null }) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmEditor(initial: Alarm, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val state = rememberTimePickerState(initial.hour, initial.minute, DateFormat.is24HourFormat(ctx))
    var label by remember { mutableStateOf(initial.label) }
    var days by remember { mutableIntStateOf(initial.days) }
    var vibrate by remember { mutableStateOf(initial.vibrate) }
    var snooze by remember { mutableIntStateOf(initial.snoozeMin) }
    var tone by remember { mutableStateOf(initial.ringtone) }
    val toneTitle = remember(tone) { runCatching { RingtoneManager.getRingtone(ctx, tone?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).getTitle(ctx) }.getOrDefault("الافتراضية") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }?.let { tone = it.toString() }
    }
    AlertDialog(onDismiss, title = { Text(if (initial.id == 0) "منبه جديد" else "تعديل المنبه") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth(), Alignment.Center) { TimePicker(state) }
                OutlinedTextField(label, { label = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الاسم (اختياري)") })
                Text("التكرار", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DAYS.forEach { (dow, name) -> FilterChip((days shr (dow - 1)) and 1 == 1, { days = days xor (1 shl (dow - 1)) }, { Text(name) }) }
                }
                Text(daysText(days), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ListItem({ Text("النغمة") }, supportingContent = { Text(toneTitle) }, leadingContent = { Icon(Icons.Rounded.MusicNote, null) },
                    modifier = Modifier.clickable {
                        pick.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, tone?.let(Uri::parse)))
                    })
                ListItem({ Text("الاهتزاز") }, leadingContent = { Icon(Icons.Rounded.Vibration, null) }, trailingContent = { Switch(vibrate, { vibrate = it }) })
                Text("مدة الغفوة", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(5, 10, 15, 20).forEach { FilterChip(snooze == it, { s -> snooze = it }, { Text("$it د") }) } }
                if (initial.id != 0) TextButton({ ClockModel.deleteAlarm(ctx, initial.id); onDismiss() }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                    Icon(Icons.Rounded.Delete, null); Spacer(Modifier.width(6.dp)); Text("حذف المنبه")
                }
            }
        },
        confirmButton = { TextButton({
            ClockModel.saveAlarm(ctx, initial.copy(hour = state.hour, minute = state.minute, label = label.trim(), enabled = true, days = days, ringtone = tone, vibrate = vibrate, snoozeMin = snooze))
            onDismiss()
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onDismiss) { Text("إلغاء") } })
}

// ───────────────────────── المؤقّت (عدّ تنازلي) ─────────────────────────
@Composable
private fun TimersTab() {
    val ctx = LocalContext.current
    var h by remember { mutableStateOf("") }; var m by remember { mutableStateOf("") }; var s by remember { mutableStateOf("") }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(200) } }
    val total = (h.toLongOrNull() ?: 0) * 3_600_000 + (m.toLongOrNull() ?: 0) * 60_000 + (s.toLongOrNull() ?: 0) * 1000

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("مؤقّت جديد", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("1 د" to 1, "5 د" to 5, "10 د" to 10, "15 د" to 15, "30 د" to 30, "1 س" to 60).forEach { (l, min) ->
                            AssistChip({ ClockModel.addTimer(ctx, min * 60_000L) }, { Text(l) }, leadingIcon = { Icon(Icons.Rounded.PlayArrow, null) })
                        }
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            @Composable fun box(v: String, set: (String) -> Unit, label: String) = OutlinedTextField(v, { set(it.filter(Char::isDigit).take(2)) }, Modifier.weight(1f),
                                singleLine = true, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 22.sp, textAlign = TextAlign.Center))
                            box(h, { h = it }, "ساعة"); box(m, { m = it }, "دقيقة"); box(s, { s = it }, "ثانية")
                            FilledIconButton({ if (total > 0) { ClockModel.addTimer(ctx, total); h = ""; m = ""; s = "" } }, enabled = total > 0) { Icon(Icons.Rounded.PlayArrow, "ابدأ") }
                        }
                    }
                }
            }
        }
        items(ClockModel.timers, key = { it.id }) { t ->
            val rem = if (t.running) (t.endAt - now).coerceAtLeast(0) else t.remainingMs
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(72.dp), Alignment.Center) {
                        CircularProgressIndicator(progress = { if (t.durationMs > 0) (rem.toFloat() / t.durationMs).coerceIn(0f, 1f) else 0f }, Modifier.fillMaxSize(), strokeWidth = 5.dp)
                        Icon(if (t.running) Icons.Rounded.HourglassTop else Icons.Rounded.HourglassBottom, null)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(clockText(rem + if (t.running) 999 else 0), fontSize = 34.sp, fontWeight = FontWeight.Light, fontFamily = FontFamily.Monospace)
                        }
                        Text("من " + clockText(t.durationMs), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row {
                            if (t.running) IconButton({ ClockModel.pauseTimer(ctx, t.id) }) { Icon(Icons.Rounded.Pause, "إيقاف مؤقت") }
                            else IconButton({ ClockModel.startTimer(ctx, t.id) }, enabled = rem > 0) { Icon(Icons.Rounded.PlayArrow, "متابعة") }
                            IconButton({ ClockModel.addMinute(ctx, t.id) }) { Icon(Icons.Rounded.Add, "+1 دقيقة") }
                            IconButton({ ClockModel.resetTimer(ctx, t.id) }) { Icon(Icons.Rounded.RestartAlt, "إعادة") }
                            IconButton({ ClockModel.deleteTimer(ctx, t.id) }) { Icon(Icons.Rounded.Delete, "حذف") }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── ساعة الإيقاف (عدّ تصاعدي) ─────────────────────────
@Composable
private fun StopwatchTab() {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(30) } }
    val elapsed = Stopwatch.elapsed(now)
    val laps = Stopwatch.laps.toList()
    val splits = laps.mapIndexed { i, t -> t - (laps.getOrNull(i - 1) ?: 0L) }
    val best = if (splits.size >= 3) splits.min() else null
    val worst = if (splits.size >= 3) splits.max() else null

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(32.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(swText(elapsed), fontSize = 54.sp, fontWeight = FontWeight.Light, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            OutlinedButton({ if (Stopwatch.running) Stopwatch.lap(ctx) else Stopwatch.reset(ctx) }, Modifier.width(120.dp).height(52.dp), enabled = Stopwatch.running || elapsed > 0) {
                Text(if (Stopwatch.running) "لفّة" else "تصفير")
            }
            Button({ if (Stopwatch.running) Stopwatch.stop(ctx) else Stopwatch.start(ctx) }, Modifier.width(120.dp).height(52.dp)) {
                Text(if (Stopwatch.running) "إيقاف" else if (elapsed > 0) "متابعة" else "ابدأ")
            }
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
            itemsIndexed(laps.indices.reversed().toList()) { _, i ->
                val isBest = splits[i] == best; val isWorst = splits[i] == worst
                ListItem({ Text("لفّة ${i + 1}") },
                    supportingContent = { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text("الإجمالي " + swText(laps[i])) } },
                    trailingContent = {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(swText(splits[i]), fontFamily = FontFamily.Monospace,
                                color = if (isBest) androidx.compose.ui.graphics.Color(0xFF2E7D32) else if (isWorst) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                        }
                    })
            }
        }
    }
}
