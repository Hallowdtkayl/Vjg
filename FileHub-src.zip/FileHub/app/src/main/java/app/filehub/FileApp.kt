package app.filehub

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import app.filehub.data.FileRepository
import app.filehub.data.PrefsStore

class FileApp : Application(), ImageLoaderFactory {
    val repo by lazy { FileRepository(this) }
    val prefs by lazy { PrefsStore(this) }
    val settings by lazy { app.filehub.data.SettingsState(prefs) }
    override fun onCreate() { super.onCreate(); app.filehub.web.WebEngine.warmUp(this) }
    override fun newImageLoader() = ImageLoader.Builder(this)
        .components { add(VideoFrameDecoder.Factory()) }
        .crossfade(true).build()
}
