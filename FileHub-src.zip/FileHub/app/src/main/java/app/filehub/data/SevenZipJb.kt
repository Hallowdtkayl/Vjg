package app.filehub.data

import net.sf.sevenzipjbinding.*
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile

/** 7-Zip عبر JNI: يفتح RAR5 (وأي صيغة يدعمها 7-Zip) بكلمة مرور أو بدونها */
object SevenZipJb {
    fun isRar5(f: File): Boolean = runCatching {
        f.inputStream().use {
            val b = ByteArray(8)
            it.read(b) == 8 && b.contentEquals(byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00))
        }
    }.getOrDefault(false)

    private fun <T> withArchive(f: File, pw: String?, block: (IInArchive) -> T): T =
        RandomAccessFile(f, "r").use { raf ->
            val stream = RandomAccessFileInStream(raf)
            val ar = try {
                if (pw != null) SevenZip.openInArchive(null, stream, pw) else SevenZip.openInArchive(null, stream)
            } catch (e: SevenZipException) {
                if (pw == null && (e.message ?: "").contains("assword", true)) throw Archives.NeedPassword() else throw e
            }
            try { block(ar) } finally { ar.close() }
        }

    private fun norm(p: String) = p.replace('\\', '/').removePrefix("./").trimStart('/').trimEnd('/')

    fun list(f: File, pw: String?): List<ArchiveEntry> = withArchive(f, pw) { ar ->
        (0 until ar.numberOfItems).map { i ->
            if (pw == null && (ar.getProperty(i, PropID.ENCRYPTED) as? Boolean) == true) throw Archives.NeedPassword()
            val path = norm(ar.getStringProperty(i, PropID.PATH) ?: "")
            ArchiveEntry(path, path.substringAfterLast('/'),
                (ar.getProperty(i, PropID.IS_FOLDER) as? Boolean) == true,
                (ar.getProperty(i, PropID.SIZE) as? Number)?.toLong() ?: 0L,
                (ar.getProperty(i, PropID.LAST_MODIFICATION_TIME) as? java.util.Date)?.time ?: 0L)
        }
    }

    fun extract(f: File, dest: File, sel: Set<String>?, pw: String?, progress: (Int, Int) -> Unit) = withArchive(f, pw) { ar ->
        val paths = (0 until ar.numberOfItems).map { norm(ar.getStringProperty(it, PropID.PATH) ?: "") }
        val isDir = (0 until ar.numberOfItems).map { (ar.getProperty(it, PropID.IS_FOLDER) as? Boolean) == true }
        fun wanted(p: String) = p.isNotEmpty() && (sel == null || sel.any { p == it || p.startsWith("$it/") })
        fun target(p: String): File {
            val t = File(dest, p)
            if (!t.canonicalPath.startsWith(dest.canonicalPath + File.separator)) throw IOException("مسار غير آمن داخل الأرشيف")
            return t
        }
        val idx = ArrayList<Int>()
        paths.forEachIndexed { i, p -> if (wanted(p)) { if (isDir[i]) target(p).mkdirs() else idx.add(i) } }
        if (idx.isEmpty()) return@withArchive
        var done = 0; var wrong = false; var bad: String? = null

        ar.extract(idx.toIntArray(), false, object : IArchiveExtractCallback, ICryptoGetTextPassword {
            var out: FileOutputStream? = null
            override fun getStream(index: Int, mode: ExtractAskMode): ISequentialOutStream? {
                out?.close(); out = null
                if (mode != ExtractAskMode.EXTRACT) return null
                val t = target(paths[index]); t.parentFile?.mkdirs()
                val o = FileOutputStream(t); out = o
                return ISequentialOutStream { data -> o.write(data); data.size }
            }
            override fun prepareOperation(mode: ExtractAskMode) {}
            override fun setOperationResult(r: ExtractOperationResult) {
                out?.close(); out = null
                if (r.name == "WRONG_PASSWORD") wrong = true else if (r != ExtractOperationResult.OK && bad == null) bad = r.name
                progress(++done, idx.size)
            }
            override fun setTotal(total: Long) {}
            override fun setCompleted(complete: Long) {}
            override fun cryptoGetTextPassword(): String = pw ?: ""
        })
        if (wrong) throw Archives.NeedPassword(true)
        bad?.let { throw IOException("خطأ أثناء الفك: $it") }
    }
}
