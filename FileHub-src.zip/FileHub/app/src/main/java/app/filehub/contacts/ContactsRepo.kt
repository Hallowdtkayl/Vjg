package app.filehub.contacts

import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.*
import android.provider.ContactsContract.Data
import android.provider.ContactsContract.RawContacts
import java.io.ByteArrayOutputStream
import java.io.OutputStream

data class ContactRow(val id: Long, val lookup: String, val name: String, val photo: String?, val starred: Boolean)
data class Labeled(val value: String, val label: String, val type: Int)
data class ContactDetail(val id: Long, val lookup: String, val name: String, val photo: String?, val starred: Boolean,
                         val phones: List<Labeled>, val emails: List<Labeled>, val org: String, val title: String,
                         val note: String, val addresses: List<Labeled>, val birthday: String?)

/** نموذج التحرير: يُكتب على جهة اتصال خام واحدة (rawId < 0 = جهة جديدة) */
class ContactForm(
    var rawId: Long = -1, var accountType: String? = null, var accountName: String? = null,
    var name: String = "", val phones: MutableList<Pair<String, Int>> = mutableListOf(),
    val emails: MutableList<Pair<String, Int>> = mutableListOf(),
    var org: String = "", var title: String = "", var note: String = "",
    var photo: ByteArray? = null, var photoChanged: Boolean = false
)

object ContactsRepo {
    private val C = ContactsContract.Contacts
    private val PROJ = arrayOf(C._ID, C.LOOKUP_KEY, C.DISPLAY_NAME_PRIMARY, C.STARRED, C.PHOTO_THUMBNAIL_URI)

    fun list(ctx: Context, query: String? = null): List<ContactRow> {
        val uri = if (query.isNullOrBlank()) C.CONTENT_URI else Uri.withAppendedPath(C.CONTENT_FILTER_URI, Uri.encode(query))
        return ctx.contentResolver.query(uri, PROJ, null, null, "${C.DISPLAY_NAME_PRIMARY} COLLATE LOCALIZED ASC")?.use { c ->
            generateSequence { if (c.moveToNext()) ContactRow(c.getLong(0), c.getString(1).orEmpty(), c.getString(2).orEmpty().ifBlank { "بدون اسم" }, c.getString(4), c.getInt(3) == 1) else null }.toList()
        } ?: emptyList()
    }

    fun detail(ctx: Context, id: Long): ContactDetail? {
        val cr = ctx.contentResolver
        val head = cr.query(Uri.withAppendedPath(C.CONTENT_URI, "$id"), arrayOf(C.LOOKUP_KEY, C.DISPLAY_NAME_PRIMARY, C.STARRED, C.PHOTO_URI), null, null, null)
            ?.use { if (it.moveToFirst()) listOf(it.getString(0).orEmpty(), it.getString(1).orEmpty(), it.getInt(2).toString(), it.getString(3).orEmpty()) else null } ?: return null
        val res = ctx.resources
        val phones = ArrayList<Labeled>(); val emails = ArrayList<Labeled>(); val addrs = ArrayList<Labeled>()
        var org = ""; var title = ""; var note = ""; var bday: String? = null
        cr.query(Data.CONTENT_URI, arrayOf(Data.MIMETYPE, Data.DATA1, Data.DATA2, Data.DATA3, Data.DATA4), "${Data.CONTACT_ID}=?", arrayOf("$id"), null)?.use { c ->
            while (c.moveToNext()) {
                val v = c.getString(1).orEmpty(); val t = c.getInt(2); val l = c.getString(3)
                when (c.getString(0)) {
                    Phone.CONTENT_ITEM_TYPE -> if (v.isNotBlank() && phones.none { it.value.filter(Char::isDigit).takeLast(9) == v.filter(Char::isDigit).takeLast(9) })
                        phones.add(Labeled(v, Phone.getTypeLabel(res, t, l).toString(), t))
                    Email.CONTENT_ITEM_TYPE -> if (v.isNotBlank() && emails.none { it.value.equals(v, true) }) emails.add(Labeled(v, Email.getTypeLabel(res, t, l).toString(), t))
                    Organization.CONTENT_ITEM_TYPE -> { if (org.isBlank()) org = v; if (title.isBlank()) title = c.getString(4).orEmpty() }
                    Note.CONTENT_ITEM_TYPE -> if (note.isBlank()) note = v
                    StructuredPostal.CONTENT_ITEM_TYPE -> if (v.isNotBlank()) addrs.add(Labeled(v, StructuredPostal.getTypeLabel(res, t, l).toString(), t))
                    Event.CONTENT_ITEM_TYPE -> if (t == Event.TYPE_BIRTHDAY && v.isNotBlank()) bday = v
                }
            }
        }
        return ContactDetail(id, head[0], head[1].ifBlank { "بدون اسم" }, head[3].ifBlank { null }, head[2] == "1", phones, emails, org, title, note, addrs, bday)
    }

    fun setStarred(ctx: Context, id: Long, v: Boolean) {
        ctx.contentResolver.update(Uri.withAppendedPath(C.CONTENT_URI, "$id"), ContentValues().apply { put(C.STARRED, if (v) 1 else 0) }, null, null)
    }

    fun delete(ctx: Context, rows: List<ContactRow>) {
        rows.forEach { runCatching { ctx.contentResolver.delete(C.getLookupUri(it.id, it.lookup), null, null) } }
    }

    // ───── حسابات الجهات ─────
    fun accounts(ctx: Context): List<Pair<String?, String?>> {
        val set = LinkedHashSet<Pair<String?, String?>>()
        runCatching {
            ctx.contentResolver.query(RawContacts.CONTENT_URI, arrayOf(RawContacts.ACCOUNT_TYPE, RawContacts.ACCOUNT_NAME), "deleted=0", null, null)?.use { c ->
                while (c.moveToNext()) set.add(c.getString(0) to c.getString(1))
            }
        }
        if (set.none { it.first == null }) set.add(null to null)
        return set.sortedBy { if (it.first == "com.google") 0 else if (it.first == null) 2 else 1 }
    }
    fun accountLabel(a: Pair<String?, String?>) = when (a.first) { null -> "الجهاز فقط (بدون مزامنة)"; "com.google" -> "Google: ${a.second}"; else -> "${a.first}: ${a.second}" }

    // ───── تحميل نموذج التحرير ─────
    fun loadForm(ctx: Context, contactId: Long): ContactForm? {
        val cr = ctx.contentResolver
        val f = ContactForm()
        cr.query(RawContacts.CONTENT_URI, arrayOf(RawContacts._ID, RawContacts.ACCOUNT_TYPE, RawContacts.ACCOUNT_NAME), "contact_id=? AND deleted=0", arrayOf("$contactId"), "${RawContacts._ID} ASC")
            ?.use { if (it.moveToFirst()) { f.rawId = it.getLong(0); f.accountType = it.getString(1); f.accountName = it.getString(2) } }
        if (f.rawId < 0) return null
        cr.query(Data.CONTENT_URI, arrayOf(Data.MIMETYPE, Data.DATA1, Data.DATA2, Data.DATA4), "${Data.RAW_CONTACT_ID}=?", arrayOf("${f.rawId}"), null)?.use { c ->
            while (c.moveToNext()) {
                val v = c.getString(1).orEmpty()
                when (c.getString(0)) {
                    StructuredName.CONTENT_ITEM_TYPE -> if (f.name.isBlank()) f.name = v
                    Phone.CONTENT_ITEM_TYPE -> if (v.isNotBlank()) f.phones.add(v to c.getInt(2))
                    Email.CONTENT_ITEM_TYPE -> if (v.isNotBlank()) f.emails.add(v to c.getInt(2))
                    Organization.CONTENT_ITEM_TYPE -> { f.org = v; f.title = c.getString(3).orEmpty() }
                    Note.CONTENT_ITEM_TYPE -> f.note = v
                }
            }
        }
        return f
    }

    /** يحفظ (جديد أو تعديل) ويرجع معرّف الجهة. التعديل يستبدل الحقول التي نديرها فقط ويترك الباقي كما هو */
    fun save(ctx: Context, f: ContactForm): Long {
        val ops = ArrayList<ContentProviderOperation>()
        val isNew = f.rawId < 0
        if (isNew) ops.add(ContentProviderOperation.newInsert(RawContacts.CONTENT_URI)
            .withValue(RawContacts.ACCOUNT_TYPE, f.accountType).withValue(RawContacts.ACCOUNT_NAME, f.accountName).build())
        else {
            val mimes = mutableListOf(StructuredName.CONTENT_ITEM_TYPE, Phone.CONTENT_ITEM_TYPE, Email.CONTENT_ITEM_TYPE, Organization.CONTENT_ITEM_TYPE, Note.CONTENT_ITEM_TYPE)
            if (f.photoChanged) mimes.add(Photo.CONTENT_ITEM_TYPE)
            ops.add(ContentProviderOperation.newDelete(Data.CONTENT_URI)
                .withSelection("${Data.RAW_CONTACT_ID}=? AND ${Data.MIMETYPE} IN (${mimes.joinToString(",") { "?" }})", arrayOf("${f.rawId}") + mimes).build())
        }
        fun row(mime: String): ContentProviderOperation.Builder {
            val b = ContentProviderOperation.newInsert(Data.CONTENT_URI)
            if (isNew) b.withValueBackReference(Data.RAW_CONTACT_ID, 0) else b.withValue(Data.RAW_CONTACT_ID, f.rawId)
            return b.withValue(Data.MIMETYPE, mime)
        }
        if (f.name.isNotBlank()) ops.add(row(StructuredName.CONTENT_ITEM_TYPE).withValue(StructuredName.DISPLAY_NAME, f.name.trim()).build())
        f.phones.filter { it.first.isNotBlank() }.forEach { ops.add(row(Phone.CONTENT_ITEM_TYPE).withValue(Phone.NUMBER, it.first.trim()).withValue(Phone.TYPE, it.second).build()) }
        f.emails.filter { it.first.isNotBlank() }.forEach { ops.add(row(Email.CONTENT_ITEM_TYPE).withValue(Email.ADDRESS, it.first.trim()).withValue(Email.TYPE, it.second).build()) }
        if (f.org.isNotBlank() || f.title.isNotBlank()) ops.add(row(Organization.CONTENT_ITEM_TYPE).withValue(Organization.COMPANY, f.org.trim()).withValue(Organization.TITLE, f.title.trim()).build())
        if (f.note.isNotBlank()) ops.add(row(Note.CONTENT_ITEM_TYPE).withValue(Note.NOTE, f.note.trim()).build())
        if (f.photoChanged && f.photo != null) ops.add(row(Photo.CONTENT_ITEM_TYPE).withValue(Photo.PHOTO, f.photo).build())

        val res = ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
        val rawId = if (isNew) ContentUris.parseId(res[0].uri!!) else f.rawId
        return ctx.contentResolver.query(ContentUris.withAppendedId(RawContacts.CONTENT_URI, rawId), arrayOf(RawContacts.CONTACT_ID), null, null, null)
            ?.use { if (it.moveToFirst()) it.getLong(0) else -1L } ?: -1L
    }

    /** صورة من المعرض → JPEG بحد أقصى 720px (حجم مناسب لمزوّد الجهات) */
    fun loadPhoto(ctx: Context, uri: Uri, max: Int = 720): ByteArray? = runCatching {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
        val bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
        val k = max.toFloat() / maxOf(bmp.width, bmp.height)
        val out = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
        ByteArrayOutputStream().also { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
    }.getOrNull()

    // ───── vCard ─────
    fun exportVcf(ctx: Context, lookups: List<String>, out: OutputStream): Int {
        var n = 0
        lookups.chunked(80).forEach { chunk ->      // أجزاء حتى لا يطول الـ URI
            val uri = Uri.withAppendedPath(C.CONTENT_MULTI_VCARD_URI, Uri.encode(chunk.joinToString(":")))
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd -> afd.createInputStream().use { it.copyTo(out) } }
            n += chunk.size
        }
        return n
    }

    /** يستورد جهات من نص vCard ويتخطى من يوجد بنفس الاسم. يرجع (المستورد، المتخطّى) */
    fun importVcf(ctx: Context, text: String): Pair<Int, Int> {
        val existing = list(ctx).map { it.name.lowercase() }.toHashSet()
        val acc = accounts(ctx).first()
        var ok = 0; var skip = 0
        for (f in VCard.parse(text)) {
            val key = f.name.lowercase()
            if (key.isNotBlank() && !existing.add(key)) { skip++; continue }
            f.accountType = acc.first; f.accountName = acc.second
            runCatching { save(ctx, f); ok++ }
        }
        return ok to skip
    }
}

/** محلّل vCard 2.1/3.0/4.0 أساسي: الاسم، الهاتف، البريد، الشركة، المسمّى، الملاحظة (بدون الصور) */
object VCard {
    private fun unescape(s: String) = s.replace("\\n", "\n").replace("\\N", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")

    private fun decodeQp(v: String, charset: String): String {
        val out = ByteArrayOutputStream(); var i = 0
        while (i < v.length) {
            val c = v[i]
            if (c == '=' && i + 2 < v.length + 0 && v.substring(i + 1, i + 3).all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }) { out.write(v.substring(i + 1, i + 3).toInt(16)); i += 3 }
            else { out.write(c.code); i++ }
        }
        return runCatching { String(out.toByteArray(), charset(charset)) }.getOrDefault(v)
    }

    private fun phoneType(p: List<String>) = when {
        p.any { "CELL" in it || "MOBILE" in it } -> Phone.TYPE_MOBILE
        p.any { "HOME" in it } -> Phone.TYPE_HOME
        p.any { "WORK" in it } -> Phone.TYPE_WORK
        else -> Phone.TYPE_OTHER
    }
    private fun emailType(p: List<String>) = when { p.any { "HOME" in it } -> Email.TYPE_HOME; p.any { "WORK" in it } -> Email.TYPE_WORK; else -> Email.TYPE_OTHER }

    fun parse(text: String): List<ContactForm> {
        val raw = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val lines = ArrayList<String>()
        var i = 0
        while (i < raw.size) {
            var l = raw[i]; i++
            if ((l.startsWith(" ") || l.startsWith("\t")) && lines.isNotEmpty()) { lines[lines.size - 1] += l.substring(1); continue }
            while (l.endsWith("=") && l.contains("QUOTED-PRINTABLE", true) && i < raw.size) { l = l.dropLast(1) + raw[i]; i++ }
            lines.add(l)
        }
        val out = ArrayList<ContactForm>()
        var cur: ContactForm? = null
        for (line in lines) {
            val u = line.trim().uppercase()
            if (u == "BEGIN:VCARD") { cur = ContactForm(); continue }
            if (u == "END:VCARD") { cur?.let { if (it.name.isNotBlank() || it.phones.isNotEmpty()) out.add(it) }; cur = null; continue }
            val f = cur ?: continue
            val colon = line.indexOf(':'); if (colon < 0) continue
            val parts = line.substring(0, colon).split(';')
            val prop = parts[0].substringAfterLast('.').uppercase()
            val params = parts.drop(1).map { it.uppercase() }
            var value = line.substring(colon + 1)
            if (params.any { "QUOTED-PRINTABLE" in it }) value = decodeQp(value, params.firstOrNull { it.startsWith("CHARSET=") }?.substringAfter('=') ?: "UTF-8")
            when (prop) {
                "FN" -> f.name = unescape(value).trim()
                "N" -> if (f.name.isBlank()) { val p = value.split(';'); f.name = listOf(p.getOrNull(1), p.getOrNull(0)).filter { !it.isNullOrBlank() }.joinToString(" ") }
                "TEL" -> value.trim().takeIf { it.isNotEmpty() }?.let { f.phones.add(it to phoneType(params)) }
                "EMAIL" -> value.trim().takeIf { it.isNotEmpty() }?.let { f.emails.add(it to emailType(params)) }
                "ORG" -> f.org = unescape(value.split(';').first())
                "TITLE" -> f.title = unescape(value)
                "NOTE" -> f.note = unescape(value)
            }
        }
        return out
    }
}
