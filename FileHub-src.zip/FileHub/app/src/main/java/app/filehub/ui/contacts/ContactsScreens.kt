package app.filehub.ui.contacts

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.telephony.PhoneNumberUtils
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Message
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import app.filehub.contacts.*
import app.filehub.phone.Blocklist
import app.filehub.phone.CallLogRepo
import app.filehub.phone.DialerUtil
import app.filehub.sms.SmsRepo
import app.filehub.ui.components.RequirePerms
import app.filehub.ui.phone.Avatar
import app.filehub.ui.readableDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CONTACT_PERMS = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)
private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

// ───────────────────────── القائمة ─────────────────────────
class ContactsViewModel(app: Application) : AndroidViewModel(app) {
    var all by mutableStateOf<List<ContactRow>>(emptyList()); private set
    var loading by mutableStateOf(true); private set
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(s: Boolean) { reload() } }
    init { app.contentResolver.registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, obs); reload() }
    fun reload() {
        viewModelScope.launch {
            all = withContext(Dispatchers.IO) { runCatching { ContactsRepo.list(getApplication()) }.getOrDefault(emptyList()) }
            loading = false
        }
    }
    fun delete(rows: List<ContactRow>) { viewModelScope.launch(Dispatchers.IO) { ContactsRepo.delete(getApplication(), rows); reload() } }
    fun star(rows: List<ContactRow>, v: Boolean) { viewModelScope.launch(Dispatchers.IO) { rows.forEach { runCatching { ContactsRepo.setStarred(getApplication(), it.id, v) } }; reload() } }
    override fun onCleared() { getApplication<Application>().contentResolver.unregisterContentObserver(obs) }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ContactsScreen(onBack: () -> Unit, onOpen: (Long) -> Unit, onNew: () -> Unit) {
    RequirePerms(CONTACT_PERMS, "صلاحيات جهات الاتصال", "لعرض جهات الاتصال وإنشائها وتعديلها.", Icons.Rounded.Contacts) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val vm: ContactsViewModel = viewModel()
        var query by remember { mutableStateOf("") }
        var searching by remember { mutableStateOf(false) }
        var selected by remember { mutableStateOf(setOf<Long>()) }
        var menu by remember { mutableStateOf(false) }
        var confirmDelete by remember { mutableStateOf(false) }
        val selecting = selected.isNotEmpty()

        val byNumber by produceState<List<ContactRow>?>(null, query) {
            delay(200); value = if (query.count { it.isDigit() } >= 3) withContext(Dispatchers.IO) { runCatching { ContactsRepo.list(ctx, query) }.getOrNull() } else null
        }
        val shown = remember(vm.all, query, byNumber) {
            if (query.isBlank()) vm.all else byNumber ?: vm.all.filter { it.name.contains(query, true) }
        }
        val favorites = remember(shown) { shown.filter { it.starred } }
        val groups = remember(shown) { shown.groupBy { it.name.firstOrNull { c -> c.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "#" } }

        val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-vcard")) { uri ->
            if (uri != null) scope.launch {
                val keys = (if (selecting) vm.all.filter { it.id in selected } else vm.all).map { it.lookup }
                val r = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { ContactsRepo.exportVcf(ctx, keys, it) } } }
                toast(ctx, r.fold({ "تم تصدير $it جهة" }, { "تعذّر التصدير: ${it.message}" })); selected = emptySet()
            }
        }
        val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) scope.launch {
                toast(ctx, "جارٍ الاستيراد…")
                val r = withContext(Dispatchers.IO) { runCatching { ContactsRepo.importVcf(ctx, ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }) } }
                toast(ctx, r.fold({ "استُوردت ${it.first} جهة، وتُخطّيت ${it.second} موجودة" }, { "فشل الاستيراد: ${it.message}" })); vm.reload()
            }
        }
        BackHandler(selecting) { selected = emptySet() }

        Scaffold(
            topBar = {
                if (selecting) TopAppBar(title = { Text("${selected.size} محدد") },
                    navigationIcon = { IconButton({ selected = emptySet() }) { Icon(Icons.Rounded.Close, "إلغاء") } },
                    actions = {
                        IconButton({ vm.star(vm.all.filter { it.id in selected }, true); selected = emptySet() }) { Icon(Icons.Rounded.Star, "للمفضلة") }
                        IconButton({ exporter.launch("contacts.vcf") }) { Icon(Icons.Rounded.IosShare, "تصدير") }
                        IconButton({ confirmDelete = true }) { Icon(Icons.Rounded.Delete, "حذف") }
                    })
                else TopAppBar(
                    title = { if (searching) TextField(query, { query = it }, singleLine = true, placeholder = { Text("بحث بالاسم أو الرقم") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)) else Text("جهات الاتصال (${vm.all.size})") },
                    navigationIcon = { IconButton({ if (searching) { searching = false; query = "" } else onBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                    actions = {
                        if (!searching) IconButton({ searching = true }) { Icon(Icons.Rounded.Search, "بحث") }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "المزيد") }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text("تصدير الكل (VCF)") }, { menu = false; exporter.launch("contacts-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".vcf") })
                                DropdownMenuItem({ Text("استيراد (VCF)") }, { menu = false; importer.launch(arrayOf("text/x-vcard", "text/vcard", "*/*")) })
                            }
                        }
                    })
            },
            floatingActionButton = { FloatingActionButton(onNew) { Icon(Icons.Rounded.PersonAdd, "جهة جديدة") } }
        ) { pad ->
            LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                if (vm.loading) item { Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { CircularProgressIndicator() } }
                else if (shown.isEmpty()) item { Text("لا توجد جهات اتصال", Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                if (favorites.isNotEmpty() && query.isBlank()) {
                    stickyHeader(key = "hf") { Header("المفضلة ★") }
                    items(favorites, key = { "f${it.id}" }) { r -> ContactItem(r, r.id in selected, selecting, onOpen, { selected = if (r.id in selected) selected - r.id else selected + r.id }) }
                }
                groups.forEach { (letter, rows) ->
                    stickyHeader(key = "h$letter") { Header(letter) }
                    items(rows, key = { "c${it.id}" }) { r -> ContactItem(r, r.id in selected, selecting, onOpen, { selected = if (r.id in selected) selected - r.id else selected + r.id }) }
                }
            }
        }
        if (confirmDelete) AlertDialog({ confirmDelete = false }, title = { Text("حذف ${selected.size} جهة؟") }, text = { Text("تُحذف من كل الحسابات المزامَنة. لا يمكن التراجع.") },
            confirmButton = { TextButton({ vm.delete(vm.all.filter { it.id in selected }); selected = emptySet(); confirmDelete = false }) { Text("حذف") } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("إلغاء") } })
    }
}


@Composable
private fun Header(t: String) = Text(t, Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).padding(20.dp, 8.dp),
    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ContactItem(r: ContactRow, selected: Boolean, selecting: Boolean, onOpen: (Long) -> Unit, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
        .combinedClickable(onClick = { if (selecting) onToggle() else onOpen(r.id) }, onLongClick = onToggle)
        .padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(r.name, r.photo, 44)
        Spacer(Modifier.width(14.dp))
        Text(r.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
        if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
        else if (r.starred) Icon(Icons.Rounded.Star, null, Modifier.size(18.dp), tint = Color(0xFFFFB300))
    }
}

// ───────────────────────── التفاصيل ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactDetailScreen(id: Long, onBack: () -> Unit, onEdit: () -> Unit, onSms: (String) -> Unit, onHistory: (String) -> Unit) {
    RequirePerms(CONTACT_PERMS, "صلاحيات جهات الاتصال", "لعرض جهات الاتصال.", Icons.Rounded.Contacts) {
        val ctx = LocalContext.current
        var tick by remember { mutableIntStateOf(0) }
        LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
        val d by produceState<ContactDetail?>(null, id, tick) { value = withContext(Dispatchers.IO) { runCatching { ContactsRepo.detail(ctx, id) }.getOrNull() } }
        val calls by produceState(emptyList<app.filehub.phone.LogEntry>(), d?.id, tick) {
            val c = d ?: return@produceState
            value = withContext(Dispatchers.IO) { runCatching { CallLogRepo.load(ctx, 800).filter { e -> c.phones.any { PhoneNumberUtils.compare(ctx, e.number, it.value) } }.take(8) }.getOrDefault(emptyList()) }
        }
        val thread by produceState<app.filehub.sms.SmsThread?>(null, d?.id, tick) {
            val c = d ?: return@produceState
            value = withContext(Dispatchers.IO) { runCatching { SmsRepo.threads(ctx).firstOrNull { t -> c.phones.any { PhoneNumberUtils.compare(ctx, t.address, it.value) } } }.getOrNull() }
        }
        var confirmDelete by remember { mutableStateOf(false) }

        Scaffold(topBar = {
            TopAppBar(title = { Text("") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                actions = {
                    d?.let { c ->
                        IconButton({ ContactsRepo.setStarred(ctx, c.id, !c.starred); tick++ }) { Icon(if (c.starred) Icons.Rounded.Star else Icons.Rounded.StarBorder, "مفضلة", tint = if (c.starred) Color(0xFFFFB300) else LocalContentColor.current) }
                        IconButton(onEdit) { Icon(Icons.Rounded.Edit, "تعديل") }
                        IconButton({
                            runCatching {
                                val f = File(ctx.cacheDir, "share/${c.name.replace(Regex("[^\\p{L}\\p{N}_-]"), "_")}.vcf").also { it.parentFile?.mkdirs() }
                                f.outputStream().use { ContactsRepo.exportVcf(ctx, listOf(c.lookup), it) }
                                val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/x-vcard").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "مشاركة الجهة"))
                            }.onFailure { toast(ctx, "تعذّرت المشاركة") }
                        }) { Icon(Icons.Rounded.Share, "مشاركة") }
                        IconButton({ confirmDelete = true }) { Icon(Icons.Rounded.Delete, "حذف") }
                    }
                })
        }) { pad ->
            val c = d
            if (c == null) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator() }
            else LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
                item {
                    Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Avatar(c.name, c.photo, 112)
                        Text(c.name, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp), textAlign = TextAlign.Center)
                        if (c.org.isNotBlank() || c.title.isNotBlank()) Text(listOf(c.title, c.org).filter { it.isNotBlank() }.joinToString(" • "), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        c.phones.firstOrNull()?.let { p ->
                            Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                                FilledTonalIconButton({ DialerUtil.call(ctx, p.value) }, Modifier.size(52.dp)) { Icon(Icons.Rounded.Call, "اتصال") }
                                FilledTonalIconButton({ onSms(p.value) }, Modifier.size(52.dp)) { Icon(Icons.AutoMirrored.Rounded.Message, "رسالة") }
                                c.emails.firstOrNull()?.let { e -> FilledTonalIconButton({ ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${e.value}"))) }, Modifier.size(52.dp)) { Icon(Icons.Rounded.Email, "بريد") } }
                                FilledTonalIconButton({
                                    val n = c.phones.count { Blocklist.block(ctx, it.value) }
                                    toast(ctx, if (n > 0) "تم حظر $n رقم" else "الحظر يتطلب جعل التطبيق الهاتف الافتراضي")
                                }, Modifier.size(52.dp)) { Icon(Icons.Rounded.Block, "حظر") }
                            }
                        }
                    }
                }
                items(c.phones, key = { "p" + it.value }) { p ->
                    ListItem({ CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(p.value) } }, supportingContent = { Text(p.label) },
                        leadingContent = { Icon(Icons.Rounded.Call, null, tint = MaterialTheme.colorScheme.primary) },
                        trailingContent = { Row { IconButton({ onSms(p.value) }) { Icon(Icons.AutoMirrored.Rounded.Message, "رسالة") }; IconButton({ onHistory(p.value) }) { Icon(Icons.Rounded.History, "السجل") } } },
                        modifier = Modifier.clickable { DialerUtil.call(ctx, p.value) })
                }
                items(c.emails, key = { "e" + it.value }) { e ->
                    ListItem({ Text(e.value) }, supportingContent = { Text(e.label) }, leadingContent = { Icon(Icons.Rounded.Email, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${e.value}"))) } })
                }
                items(c.addresses, key = { "a" + it.value }) { a ->
                    ListItem({ Text(a.value) }, supportingContent = { Text(a.label) }, leadingContent = { Icon(Icons.Rounded.Place, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(a.value)}"))) } })
                }
                c.birthday?.let { b -> item { ListItem({ Text(b) }, supportingContent = { Text("تاريخ الميلاد") }, leadingContent = { Icon(Icons.Rounded.Cake, null, tint = MaterialTheme.colorScheme.primary) }) } }
                if (c.note.isNotBlank()) item { ListItem({ Text(c.note) }, supportingContent = { Text("ملاحظة") }, leadingContent = { Icon(Icons.Rounded.Notes, null, tint = MaterialTheme.colorScheme.primary) }) }

                item { HorizontalDivider(Modifier.padding(vertical = 8.dp)) }
                item { Text("آخر المكالمات", Modifier.padding(20.dp, 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                if (calls.isEmpty()) item { Text("لا توجد مكالمات", Modifier.padding(20.dp, 4.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(calls, key = { "l${it.id}" }) { e ->
                    val label = when (e.type) { CallLog.Calls.INCOMING_TYPE -> "واردة"; CallLog.Calls.OUTGOING_TYPE -> "صادرة"; CallLog.Calls.MISSED_TYPE -> "فائتة"; CallLog.Calls.REJECTED_TYPE -> "مرفوضة"; CallLog.Calls.BLOCKED_TYPE -> "محجوبة"; else -> "مكالمة" }
                    ListItem({ Text(label, color = if (e.type == CallLog.Calls.MISSED_TYPE || e.type == CallLog.Calls.BLOCKED_TYPE) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) },
                        supportingContent = { Text(e.date.readableDate() + " • " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(e.date)) + if (e.duration > 0) " • ${e.duration / 60}:${"%02d".format(e.duration % 60)}" else "") })
                }
                item { Text("الرسائل", Modifier.padding(20.dp, 12.dp, 20.dp, 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                item {
                    val t = thread
                    ListItem({ Text(t?.snippet ?: "لا توجد رسائل", maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(if (t != null) "${t.count} رسالة • ${t.date.readableDate()}" else "ابدأ محادثة") },
                        leadingContent = { Icon(Icons.AutoMirrored.Rounded.Message, null) },
                        modifier = Modifier.clickable { c.phones.firstOrNull()?.let { onSms(it.value) } })
                }
            }
        }
        if (confirmDelete) AlertDialog({ confirmDelete = false }, title = { Text("حذف الجهة؟") }, text = { Text("تُحذف من كل الحسابات المزامَنة. لا يمكن التراجع.") },
            confirmButton = { TextButton({
                confirmDelete = false
                d?.let { c -> ContactsRepo.delete(ctx, listOf(ContactRow(c.id, c.lookup, c.name, null, c.starred))) }
                onBack()
            }) { Text("حذف") } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("إلغاء") } })
    }
}

// ───────────────────────── الإنشاء والتعديل ─────────────────────────
private class Field(n: String, t: Int) { var value by mutableStateOf(n); var type by mutableIntStateOf(t) }
private val PHONE_TYPES = listOf(2 to "موبايل", 1 to "منزل", 3 to "عمل", 7 to "أخرى")
private val EMAIL_TYPES = listOf(1 to "منزل", 2 to "عمل", 3 to "أخرى")
private fun next(types: List<Pair<Int, String>>, cur: Int) = types[(types.indexOfFirst { it.first == cur }.coerceAtLeast(0) + 1) % types.size].first

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactEditScreen(id: Long, number: String, name0: String, email0: String, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    RequirePerms(CONTACT_PERMS, "صلاحيات جهات الاتصال", "لإنشاء الجهات وتعديلها.", Icons.Rounded.Contacts) {
        val ctx = LocalContext.current
        val scope = rememberCoroutineScope()
        val phones = remember { mutableStateListOf<Field>() }
        val emails = remember { mutableStateListOf<Field>() }
        var name by remember { mutableStateOf("") }
        var org by remember { mutableStateOf("") }
        var title by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var photo by remember { mutableStateOf<ByteArray?>(null) }
        var photoChanged by remember { mutableStateOf(false) }
        var rawId by remember { mutableLongStateOf(-1L) }
        var account by remember { mutableStateOf<Pair<String?, String?>?>(null) }
        var accounts by remember { mutableStateOf(emptyList<Pair<String?, String?>>()) }
        var accMenu by remember { mutableStateOf(false) }
        var loaded by remember { mutableStateOf(false) }
        var saving by remember { mutableStateOf(false) }

        LaunchedEffect(id) {
            withContext(Dispatchers.IO) {
                if (id >= 0) ContactsRepo.loadForm(ctx, id) else ContactForm().also { it.name = name0; if (number.isNotBlank()) it.phones.add(number to 2); if (email0.isNotBlank()) it.emails.add(email0 to 1) }
            }?.let { f ->
                rawId = f.rawId; name = f.name; org = f.org; title = f.title; note = f.note
                phones.clear(); f.phones.forEach { phones.add(Field(it.first, it.second)) }; if (phones.isEmpty()) phones.add(Field("", 2))
                emails.clear(); f.emails.forEach { emails.add(Field(it.first, it.second)) }
                if (id < 0) { accounts = withContext(Dispatchers.IO) { ContactsRepo.accounts(ctx) }; account = accounts.firstOrNull() }
                else account = f.accountType to f.accountName
            }
            loaded = true
        }
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) scope.launch { withContext(Dispatchers.IO) { ContactsRepo.loadPhoto(ctx, uri) }?.let { photo = it; photoChanged = true } ?: toast(ctx, "تعذّر قراءة الصورة") }
        }
        val preview = remember(photo) { photo?.let { runCatching { android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull() } }

        fun save() {
            if (saving) return
            if (name.isBlank() && phones.none { it.value.isNotBlank() }) { toast(ctx, "أدخل اسماً أو رقماً"); return }
            saving = true
            val f = ContactForm(rawId = rawId, accountType = account?.first, accountName = account?.second, name = name, org = org, title = title, note = note, photo = photo, photoChanged = photoChanged)
            phones.forEach { f.phones.add(it.value to it.type) }; emails.forEach { f.emails.add(it.value to it.type) }
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { ContactsRepo.save(ctx, f) } }
                saving = false
                r.onSuccess { onSaved(it) }.onFailure { toast(ctx, "تعذّر الحفظ: ${it.message}") }
            }
        }

        Scaffold(topBar = {
            TopAppBar(title = { Text(if (id < 0) "جهة جديدة" else "تعديل الجهة") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.Close, "إغلاق") } },
                actions = { TextButton(::save, enabled = loaded && !saving) { Text("حفظ") } })
        }) { pad ->
            if (!loaded) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator() }
            else Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(96.dp).clip(CircleShape).clickable { pick.launch("image/*") }, Alignment.Center) {
                        if (preview != null) androidx.compose.foundation.Image(preview, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        else Avatar(name.ifBlank { "؟" }, null, 96)
                        Icon(Icons.Rounded.PhotoCamera, null, Modifier.align(Alignment.BottomEnd).size(26.dp).background(MaterialTheme.colorScheme.primary, CircleShape).padding(5.dp), tint = Color.White)
                    }
                }
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("الاسم") }, singleLine = true, leadingIcon = { Icon(Icons.Rounded.Person, null) })
                phones.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            OutlinedTextField(p.value, { p.value = it.filter { c -> c.isDigit() || c in "+*#- ()" } }, Modifier.weight(1f), label = { Text("الهاتف") }, singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone), leadingIcon = { Icon(Icons.Rounded.Call, null) })
                        }
                        AssistChip({ p.type = next(PHONE_TYPES, p.type) }, { Text(PHONE_TYPES.firstOrNull { it.first == p.type }?.second ?: "أخرى") }, Modifier.padding(start = 6.dp))
                        if (phones.size > 1) IconButton({ phones.removeAt(i) }) { Icon(Icons.Rounded.RemoveCircleOutline, "إزالة") }
                    }
                }
                TextButton({ phones.add(Field("", 2)) }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة رقم") }
                emails.forEachIndexed { i, e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(e.value, { e.value = it }, Modifier.weight(1f), label = { Text("البريد") }, singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Email), leadingIcon = { Icon(Icons.Rounded.Email, null) })
                        AssistChip({ e.type = next(EMAIL_TYPES, e.type) }, { Text(EMAIL_TYPES.firstOrNull { it.first == e.type }?.second ?: "أخرى") }, Modifier.padding(start = 6.dp))
                        IconButton({ emails.removeAt(i) }) { Icon(Icons.Rounded.RemoveCircleOutline, "إزالة") }
                    }
                }
                TextButton({ emails.add(Field("", 1)) }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة بريد") }
                OutlinedTextField(org, { org = it }, Modifier.fillMaxWidth(), label = { Text("الشركة") }, singleLine = true, leadingIcon = { Icon(Icons.Rounded.Business, null) })
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("المسمّى الوظيفي") }, singleLine = true)
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("ملاحظة") }, minLines = 2, leadingIcon = { Icon(Icons.Rounded.Notes, null) })
                if (id < 0 && accounts.size > 1) Box {
                    OutlinedButton({ accMenu = true }, Modifier.fillMaxWidth()) { Icon(Icons.Rounded.CloudQueue, null); Spacer(Modifier.width(8.dp)); Text(account?.let { ContactsRepo.accountLabel(it) } ?: "") }
                    DropdownMenu(accMenu, { accMenu = false }) { accounts.forEach { a -> DropdownMenuItem({ Text(ContactsRepo.accountLabel(a)) }, { account = a; accMenu = false }) } }
                }
                if (id >= 0 && photo != null) TextButton({ photo = null; photoChanged = false }) { Text("إلغاء الصورة الجديدة") }
            }
        }
    }
}
