package app.filehub.ui.screens

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.filehub.FileApp
import app.filehub.model.*
import kotlinx.coroutines.launch
import java.io.File

data class Clipboard(val paths: List<String>, val cut: Boolean)

data class BrowserState(
    val loading: Boolean = true,
    val items: List<FileItem> = emptyList(),
    val title: String = "",
    val subtitle: String? = null,
    val prefs: ViewPrefs = ViewPrefs(),
    val selection: Set<String> = emptySet(),
    val query: String = "",
    val clipboard: Clipboard? = null,
    val showHidden: Boolean = false,
    val message: String? = null
)

fun sortAndFilter(items: List<FileItem>, p: ViewPrefs, q: String): List<FileItem> {
    val f = if (q.isBlank()) items else items.filter { it.name.contains(q, true) }
    val cmp: Comparator<FileItem> = when (p.sortBy) {
        SortBy.Name -> compareBy<FileItem> { it.name.lowercase() }
        SortBy.Date -> compareBy<FileItem> { it.modified }
        SortBy.Size -> compareBy<FileItem> { it.size }
        SortBy.Type -> compareBy<FileItem> { it.ext }
    }
    return f.sortedWith(compareByDescending<FileItem> { it.isDir }.then(if (p.ascending) cmp else cmp.reversed()))
}

/** catId == null → تصفح مجلد حقيقي يبدأ من startPath، وإلا تصنيف ذكي */
class BrowserViewModel(app: Application, catId: String?, startPath: String?) : AndroidViewModel(app) {
    private val fapp = app as FileApp
    private val repo = fapp.repo
    private val store = fapp.prefs
    val category: Category? = Category.byId(catId)
    private val scope = category?.id ?: "folder"
    private val stack = ArrayDeque<String>()      // مسارات التصفح الحقيقي
    private var drill: String? = null             // مجلد مفتوح داخل تصنيف (عرض بالمجلدات)

    var state by mutableStateOf(BrowserState(prefs = store.load(scope, defaultPrefs()), showHidden = store.showHidden))
        private set

    private fun defaultPrefs(): ViewPrefs = when (category) {
        null -> ViewPrefs(SortBy.Name, true, DisplayStyle.List, BrowseMode.Folders)
        Category.Large -> ViewPrefs(SortBy.Size, false, DisplayStyle.List, BrowseMode.Flat)
        Category.Images, Category.Videos -> ViewPrefs(SortBy.Date, false, DisplayStyle.Grid, BrowseMode.Flat)
        else -> ViewPrefs(SortBy.Date, false, DisplayStyle.List, BrowseMode.Flat)
    }

    private fun foldersView() = category != null && category.allowsFolders && state.prefs.mode == BrowseMode.Folders
    /** المجلدات الافتراضية في التصنيفات لا يجوز تحديدها (حذفها قد يحذف مجلداً كاملاً) */
    private fun selectable() = !(foldersView() && drill == null)

    init { startPath?.let { stack.addLast(it) }; load() }

    fun load() {
        viewModelScope.launch {
            state = state.copy(loading = true)
            val s = state
            var title = category?.title ?: ""
            var sub: String? = null
            val items: List<FileItem>
            when {
                category == null -> {
                    val cur = stack.last()
                    items = repo.list(File(cur), s.showHidden)
                    title = File(cur).name.ifEmpty { "الذاكرة" }; sub = cur
                }
                category == Category.Trash -> items = repo.listTrash()
                else -> {
                    val now = System.currentTimeMillis()
                    val matching = repo.scan(showHidden = s.showHidden).filter { category.matches(it, now) }
                    if (!foldersView()) items = matching
                    else if (drill == null) items = matching.groupBy { File(it.path).parent.orEmpty() }.map { (p, l) ->
                        FileItem(File(p).name, p, true, l.sumOf { it.size }, l.maxOf { it.modified }, "", l.size)
                    } else {
                        items = matching.filter { File(it.path).parent == drill }
                        title = File(drill!!).name; sub = drill
                    }
                }
            }
            state = state.copy(loading = false, items = items, title = title, subtitle = sub, selection = emptySet())
        }
    }

    fun canHandleBack() = state.selection.isNotEmpty() || state.query.isNotEmpty() ||
        (category == null && stack.size > 1) || drill != null

    fun handleBack(): Boolean {
        when {
            state.selection.isNotEmpty() -> clearSelection()
            state.query.isNotEmpty() -> setQuery("")
            category == null && stack.size > 1 -> { stack.removeLast(); load() }
            drill != null -> { drill = null; load() }
            else -> return false
        }
        return true
    }

    fun openDir(f: FileItem) { if (category == null) stack.addLast(f.path) else drill = f.path; state = state.copy(query = ""); load() }
    fun setQuery(q: String) { state = state.copy(query = q) }
    fun post(m: String) { state = state.copy(message = m) }
    fun messageShown() { state = state.copy(message = null) }

    // التحديد
    fun toggle(path: String) { if (!selectable()) return
        val s = state.selection; state = state.copy(selection = if (path in s) s - path else s + path) }
    fun selectAll(paths: List<String>) { if (selectable()) state = state.copy(selection = paths.toSet()) }
    fun clearSelection() { state = state.copy(selection = emptySet()) }

    // الإعدادات
    fun setPrefs(p: ViewPrefs) {
        val modeChanged = p.mode != state.prefs.mode
        store.save(scope, p); state = state.copy(prefs = p)
        if (modeChanged) { drill = null; load() }
    }
    fun toggleHidden() {
        val v = !state.showHidden; store.showHidden = v; repo.invalidate()
        state = state.copy(showHidden = v); load()
    }

    private fun op(ok: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block(); repo.invalidate(); post(ok) } catch (e: Exception) { post("تعذّرت العملية: ${e.message}") }
            load()
        }
    }

    private fun selectedItems() = state.items.filter { it.path in state.selection }

    fun copy() = clip(false)
    fun cut() = clip(true)
    private fun clip(cut: Boolean) {
        state = state.copy(clipboard = Clipboard(state.selection.toList(), cut), selection = emptySet(),
            message = if (cut) "تم القص — انتقل إلى المجلد الهدف والصق" else "تم النسخ — انتقل إلى المجلد الهدف والصق")
    }
    fun cancelClipboard() { state = state.copy(clipboard = null) }
    fun paste() {
        val c = state.clipboard ?: return
        val dest = File(stack.lastOrNull() ?: return)
        state = state.copy(clipboard = null)
        op(if (c.cut) "تم النقل" else "تم اللصق") { repo.paste(c.paths, dest, c.cut) }
    }
    fun trashSelected() { val f = state.selection.map(::File); op("نُقل إلى سلة المحذوفات") { repo.moveToTrash(f) } }
    fun restoreSelected() { val i = selectedItems(); op("تمت الاستعادة") { repo.restore(i) } }
    fun deleteForever() { val i = selectedItems(); op("حُذف نهائياً") { repo.deleteForever(i) } }
    fun emptyTrash() = op("أُفرغت السلة") { repo.emptyTrash() }
    fun rename(newName: String) { val f = File(state.selection.first()); op("تمت إعادة التسمية") { repo.rename(f, newName.trim()) } }
    fun newFile(name: String) {
        val d = File(stack.last()); val n = name.trim().let { if ('.' in it) it else "$it.txt" }
        op("أُنشئ الملف") { repo.mkfile(d, n) }
    }
    fun newFolder(name: String) { val d = File(stack.last()); op("أُنشئ المجلد") { repo.mkdir(d, name.trim()) } }
}
