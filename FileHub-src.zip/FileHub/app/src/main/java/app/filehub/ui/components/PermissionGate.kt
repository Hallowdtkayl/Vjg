package app.filehub.ui.components

import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

private fun has(c: Context, p: Array<String>) = p.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

/** يعرض المحتوى فقط بعد منح الصلاحيات، وإلا شاشة شرح + زر طلب */
@Composable
fun RequirePerms(perms: Array<String>, title: String, text: String, icon: ImageVector, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(has(ctx, perms)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = has(ctx, perms) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { ok = has(ctx, perms) }
    if (ok) content() else Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
        Button({ launcher.launch(perms) }) { Text("منح الصلاحيات") }
    }
}
