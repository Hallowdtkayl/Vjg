package app.filehub.sms

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telephony.PhoneNumberUtils
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import app.filehub.phone.ContactInfo
import app.filehub.phone.ContactsLookup

data class SmsThread(val id: Long, val address: String, val name: String?, val photo: String?, val snippet: String,
                     val date: Long, val unread: Int, val count: Int, val lastType: Int)
data class SmsMsg(val id: Long, val threadId: Long, val address: String, val body: String, val date: Long, val type: Int, val read: Boolean)

/** كل الوصول إلى مزوّد الرسائل. الكتابة فيه تتطلب أن يكون التطبيق هو تطبيق الرسائل الافتراضي */
object SmsRepo {
    private val PROJ = arrayOf(Telephony.Sms._ID, Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY,
        Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ)

    fun isDefault(ctx: Context) = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun requestIntent(ctx: Context): Intent =
        if (Build.VERSION.SDK_INT >= 29) ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
        else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, ctx.packageName)

    private fun limitArgs(limit: Int, desc: Boolean) = Bundle().apply {
        putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(Telephony.Sms.DATE))
        putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION,
            if (desc) ContentResolver.QUERY_SORT_DIRECTION_DESCENDING else ContentResolver.QUERY_SORT_DIRECTION_ASCENDING)
    }

    private fun read(c: android.database.Cursor) = SmsMsg(c.getLong(0), c.getLong(1), c.getString(2).orEmpty(),
        c.getString(3).orEmpty(), c.getLong(4), c.getInt(5), c.getInt(6) == 1)

    /** المحادثات: آخر رسالة في كل thread مع عدد غير المقروء (رسائل SMS فقط، لا MMS) */
    fun threads(ctx: Context, limit: Int = 8000): List<SmsThread> {
        class Acc(val id: Long, val address: String, val snippet: String, val date: Long, val type: Int) { var count = 0; var unread = 0 }
        val map = LinkedHashMap<Long, Acc>()
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, PROJ, limitArgs(limit, true), null)?.use { c ->
            while (c.moveToNext()) {
                val a = map.getOrPut(c.getLong(1)) { Acc(c.getLong(1), c.getString(2).orEmpty(), c.getString(3).orEmpty(), c.getLong(4), c.getInt(5)) }
                a.count++
                if (c.getInt(6) == 0 && c.getInt(5) == Telephony.Sms.MESSAGE_TYPE_INBOX) a.unread++
            }
        }
        val cache = HashMap<String, ContactInfo?>()
        return map.values.map { a ->
            val info = cache.getOrPut(a.address) { ContactsLookup.lookup(ctx, a.address) }
            SmsThread(a.id, a.address, info?.name, info?.photo, a.snippet, a.date, a.unread, a.count, a.type)
        }
    }

    fun messages(ctx: Context, threadId: Long): List<SmsMsg> =
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, PROJ, "thread_id=?", arrayOf("$threadId"), "date ASC")?.use { c ->
            generateSequence { if (c.moveToNext()) read(c) else null }.toList()
        } ?: emptyList()

    fun search(ctx: Context, q: String, limit: Int = 60): List<SmsMsg> {
        val esc = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        return ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, PROJ, "body LIKE ? ESCAPE '\\'", arrayOf("%$esc%"), "date DESC")?.use { c ->
            generateSequence { if (c.moveToNext() && c.position < limit) read(c) else null }.toList()
        } ?: emptyList()
    }

    fun unreadCount(ctx: Context): Int = runCatching {
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms._ID),
            "read=0 AND type=${Telephony.Sms.MESSAGE_TYPE_INBOX}", null, null)?.use { it.count } ?: 0
    }.getOrDefault(0)

    fun threadForAddress(ctx: Context, address: String): Long? = runCatching {
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS), null, null, "date DESC")?.use { c ->
            var n = 0
            while (c.moveToNext() && n++ < 4000) if (PhoneNumberUtils.compare(ctx, c.getString(1) ?: "", address)) return@use c.getLong(0)
            null
        }
    }.getOrNull()

    fun markThreadRead(ctx: Context, threadId: Long) {
        runCatching {
            ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put("read", 1); put("seen", 1) },
                "thread_id=? AND read=0", arrayOf("$threadId"))
        }
    }
    fun markAllRead(ctx: Context) {
        runCatching { ctx.contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put("read", 1); put("seen", 1) }, "read=0", null) }
    }
    fun deleteThread(ctx: Context, threadId: Long) {
        ctx.contentResolver.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf("$threadId"))
    }
    fun deleteMessages(ctx: Context, ids: List<Long>) {
        if (ids.isNotEmpty()) ctx.contentResolver.delete(Telephony.Sms.CONTENT_URI, "_id IN (${ids.joinToString(",")})", null)
    }

    fun insertInbox(ctx: Context, address: String, body: String, date: Long, dateSent: Long, subId: Int): Uri? =
        ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
            put(Telephony.Sms.ADDRESS, address); put(Telephony.Sms.BODY, body); put(Telephony.Sms.DATE, date)
            put(Telephony.Sms.DATE_SENT, dateSent); put(Telephony.Sms.READ, 0); put(Telephony.Sms.SEEN, 0)
            put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX); if (subId >= 0) put(Telephony.Sms.SUBSCRIPTION_ID, subId)
        })

    fun threadIdOf(ctx: Context, uri: Uri): Long = ctx.contentResolver.query(uri, arrayOf(Telephony.Sms.THREAD_ID), null, null, null)
        ?.use { if (it.moveToFirst()) it.getLong(0) else -1L } ?: -1L

    private fun insertOutgoing(ctx: Context, address: String, body: String, subId: Int): Uri? =
        ctx.contentResolver.insert(Telephony.Sms.CONTENT_URI, ContentValues().apply {
            put(Telephony.Sms.ADDRESS, address); put(Telephony.Sms.BODY, body); put(Telephony.Sms.DATE, System.currentTimeMillis())
            put(Telephony.Sms.READ, 1); put(Telephony.Sms.SEEN, 1); put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
            if (subId >= 0) put(Telephony.Sms.SUBSCRIPTION_ID, subId)
        })

    fun updateType(ctx: Context, uri: Uri, type: Int) {
        runCatching { ctx.contentResolver.update(uri, ContentValues().apply { put(Telephony.Sms.TYPE, type) }, null, null) }
    }

    @SuppressLint("MissingPermission")
    fun sims(ctx: Context): List<Pair<Int, String>> = runCatching {
        ctx.getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList
            ?.map { it.subscriptionId to "${it.displayName} (${it.simSlotIndex + 1})" } ?: emptyList()
    }.getOrDefault(emptyList())

    private fun manager(ctx: Context, subId: Int): SmsManager {
        val id = if (subId >= 0) subId else SubscriptionManager.getDefaultSmsSubscriptionId()
        @Suppress("DEPRECATION")
        return if (id < 0) SmsManager.getDefault()
        else if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(id)
        else SmsManager.getSmsManagerForSubscriptionId(id)
    }

    /** يرسل (متعدد الأجزاء تلقائياً) ويسجّل الرسالة في المزوّد ثم تحدّث الحالة عند النتيجة */
    fun send(ctx: Context, address: String, body: String, subId: Int = -1): Boolean = runCatching {
        val sm = manager(ctx, subId)
        val parts = sm.divideMessage(body)
        val uri = if (isDefault(ctx)) insertOutgoing(ctx, address, body, subId) else null
        val base = uri?.lastPathSegment?.toIntOrNull() ?: 0
        val sent = ArrayList<PendingIntent>()
        parts.indices.forEach { i ->
            sent.add(PendingIntent.getBroadcast(ctx, base * 31 + i,
                Intent(ctx, SmsSentReceiver::class.java).setAction(SmsSentReceiver.ACTION)
                    .putExtra("uri", uri?.toString()).putExtra("i", i).putExtra("n", parts.size),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        sm.sendMultipartTextMessage(address, null, parts, sent, null)
        true
    }.getOrDefault(false)

    fun segments(ctx: Context, body: String): Int = runCatching { manager(ctx, -1).divideMessage(body).size }.getOrDefault(1)
}
