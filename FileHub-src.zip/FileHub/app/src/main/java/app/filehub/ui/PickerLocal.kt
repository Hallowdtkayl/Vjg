package app.filehub.ui

import androidx.compose.runtime.staticCompositionLocalOf

/** طلب اختيار ملف من تطبيق آخر (GET_CONTENT / OPEN_DOCUMENT / PICK). null = وضع التصفح العادي */
class PickRequest(val multiple: Boolean, val mimes: List<String>, val deliver: (List<String>) -> Unit)

val LocalPicker = staticCompositionLocalOf<PickRequest?> { null }
