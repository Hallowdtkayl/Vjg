package app.filehub.ui.viewers

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import app.filehub.ui.screens.openExternal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val MAX_EDIT = 1_000_000L      // أكبر ملف يُحرَّر (1 م.ب)
private const val MAX_VIEW = 2 * 1024 * 1024 // أكبر ما يُعرض للقراءة فقط
private const val HIGHLIGHT_LIMIT = 300_000  // تلوين الأكواد حتى هذا الحجم

// ───────────────────────── تلوين الصياغة ─────────────────────────
private class Lang(val regex: Regex)
private class Palette(val comment: Color, val string: Color, val number: Color, val keyword: Color)

private const val DQ = "\"(?:\\\\.|[^\"\\\\\\n])*\""
private const val SQ = "'(?:\\\\.|[^'\\\\\\n])*'"
private const val BT = "`(?:\\\\.|[^`\\\\])*`"
private const val NUM = "\\b0[xX][0-9a-fA-F]+\\b|\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b"
private const val C_COMMENT = "//[^\\n]*|/\\*[\\s\\S]*?\\*/"
private const val NEVER = "(?!)"

private fun kw(words: String) = "\\b(?:" + words.trim().split(Regex("\\s+")).joinToString("|") + ")\\b"
private fun lang(comment: String, str: String, keywords: String) = Lang(Regex("($comment)|($str)|($NUM)|($keywords)"))

private val C_LIKE = "if else for while do switch case break continue return class struct enum interface new this super import export from package " +
    "static final const let var val fun function void int long float double char bool boolean string byte short public private protected " +
    "try catch finally throw throws async await null true false undefined typeof instanceof extends implements override when in is as object " +
    "namespace using template typename virtual abstract default lambda"

private fun langFor(ext: String): Lang? = when (ext) {
    "kt", "kts", "java", "js", "jsx", "tsx", "c", "cpp", "h", "hpp", "cs", "go", "rs", "php", "swift", "dart", "vue", "gradle" ->
        lang(C_COMMENT, "$DQ|$SQ|$BT", kw(C_LIKE))
    "py" -> lang("#[^\\n]*", "$DQ|$SQ", kw("def class if elif else for while return import from as try except finally raise with lambda None True False and or not in is pass break continue yield async await global self"))
    "sh", "bat", "env", "properties", "ini", "conf", "cfg", "toml", "yml", "yaml" ->
        lang("#[^\\n]*", "$DQ|$SQ", kw("if then else elif fi for while do done case esac function return export local echo true false null"))
    "json" -> lang(NEVER, DQ, kw("true false null"))
    "css", "scss" -> lang("/\\*[\\s\\S]*?\\*/", "$DQ|$SQ", "[.#]?[A-Za-z-]+(?=\\s*[:{])")
    "html", "htm", "xml" -> lang("<!--[\\s\\S]*?-->", "$DQ|$SQ", "</?[A-Za-z][\\w:.-]*|/?>")
    "sql" -> lang("--[^\\n]*|/\\*[\\s\\S]*?\\*/", SQ, "(?i)\\b(?:select|from|where|insert|into|update|delete|create|table|drop|alter|join|left|right|inner|on|group|by|order|having|limit|and|or|not|null|values|set|as|distinct|union|index|primary|key)\\b")
    else -> null
}

private fun highlight(src: String, l: Lang, p: Palette): AnnotatedString = buildAnnotatedString {
    append(src)
    for (m in l.regex.findAll(src)) {
        val style = when {
            m.groups[1] != null -> SpanStyle(color = p.comment, fontStyle = FontStyle.Italic)
            m.groups[2] != null -> SpanStyle(color = p.string)
            m.groups[3] != null -> SpanStyle(color = p.number)
            else -> SpanStyle(color = p.keyword)
        }
        addStyle(style, m.range.first, m.range.last + 1)
    }
}

// ───────────────────────── نقطة الدخول ─────────────────────────
@Composable
fun TextFileViewer(path: String, onBack: () -> Unit) {
    val f = File(path)
    if (f.length() > MAX_EDIT) LargeTextViewer(f, onBack) else CodeEditor(f, onBack)
}

// ───────────────────────── المحرر ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CodeEditor(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val density = LocalDensity.current
    val ext = file.extension.lowercase()
    val lang = remember(ext) { langFor(ext) }
    val prose = ext in setOf("txt", "note", "md", "srt", "tex")
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val pal = remember(dark) {
        if (dark) Palette(Color(0xFF9E9E9E), Color(0xFFA5D6A7), Color(0xFF90CAF9), Color(0xFFCE93D8))
        else Palette(Color(0xFF757575), Color(0xFF2E7D32), Color(0xFF1565C0), Color(0xFF7B1FA2))
    }

    var loaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var original by remember { mutableStateOf("") }
    var tf by remember { mutableStateOf(TextFieldValue("")) }
    var crlf by remember { mutableStateOf(false) }
    var bom by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var fontSize by remember { mutableIntStateOf(14) }
    var wrap by remember { mutableStateOf(prose) }
    var gutterPref by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var showExit by remember { mutableStateOf(false) }
    var showGoto by remember { mutableStateOf(false) }
    var finding by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var rep by remember { mutableStateOf("") }
    var lastPush by remember { mutableLongStateOf(0L) }
    val undo = remember { ArrayDeque<TextFieldValue>() }
    val redo = remember { ArrayDeque<TextFieldValue>() }
    val scroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val focus = remember { FocusRequester() }

    LaunchedEffect(file) {
        withContext(Dispatchers.IO) {
            runCatching {
                val b = file.readBytes()
                if (b.take(4096).any { it == 0.toByte() }) throw IllegalStateException("يبدو أن الملف ثنائي وليس نصياً")
                val hasBom = b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()
                val raw = String(b, if (hasBom) 3 else 0, b.size - if (hasBom) 3 else 0, Charsets.UTF_8)
                Triple(hasBom, raw.contains("\r\n"), raw.replace("\r\n", "\n"))
            }
        }.onSuccess { (hasBom, isCrlf, text) ->
            bom = hasBom; crlf = isCrlf; original = text; tf = TextFieldValue(text)
            editing = text.isEmpty(); loaded = true
        }.onFailure { error = it.message ?: "تعذّرت القراءة" }
    }

    val dirty = loaded && tf.text != original
    val mono = !prose
    val lh = fontSize * 1.45f
    val showGutter = !wrap && gutterPref
    val highlightOn = lang != null && tf.text.length < HIGHLIGHT_LIMIT

    fun change(v: TextFieldValue) {
        if (v.text != tf.text) {
            val now = System.currentTimeMillis()
            if (undo.isEmpty() || now - lastPush > 700) { undo.addLast(tf); if (undo.size > 200) undo.removeFirst() }
            lastPush = now; redo.clear()
        }
        tf = v
    }
    fun doUndo() { if (undo.isNotEmpty()) { redo.addLast(tf); tf = undo.removeLast(); lastPush = 0 } }
    fun doRedo() { if (redo.isNotEmpty()) { undo.addLast(tf); tf = redo.removeLast(); lastPush = 0 } }

    fun save(then: (() -> Unit)? = null) {
        val text = tf.text
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val body = (if (crlf) text.replace("\n", "\r\n") else text).toByteArray(Charsets.UTF_8)
                    val tmp = File(file.parentFile, ".${file.name}.tmp")
                    tmp.outputStream().use { if (bom) it.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())); it.write(body) }
                    if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
                }
            }
            r.onSuccess { original = text; snack.showSnackbar("تم الحفظ"); then?.invoke() }
                .onFailure { snack.showSnackbar("تعذّر الحفظ: ${it.message}") }
        }
    }

    fun scrollToIndex(i: Int, viewportPx: Int) {
        val line = tf.text.take(i).count { it == '\n' }
        val y = with(density) { (line * lh).sp.toPx() }
        scope.launch { scroll.animateScrollTo((y - viewportPx / 3f).toInt().coerceAtLeast(0)) }
    }

    var viewportPx by remember { mutableIntStateOf(1000) }
    fun select(i: Int, len: Int) {
        tf = tf.copy(selection = TextRange(i, i + len))
        scrollToIndex(i, viewportPx)
        runCatching { focus.requestFocus() }
    }
    fun findNext(forward: Boolean) {
        if (q.isEmpty()) return
        val t = tf.text
        val i = if (forward) t.indexOf(q, tf.selection.max, true).takeIf { it >= 0 } ?: t.indexOf(q, 0, true)
        else t.lastIndexOf(q, (tf.selection.min - 1).coerceAtLeast(0), true).takeIf { it >= 0 && it < tf.selection.min } ?: t.lastIndexOf(q, t.length, true)
        if (i >= 0) select(i, q.length) else scope.launch { snack.showSnackbar("لا توجد نتائج") }
    }
    fun replaceOne() {
        if (q.isEmpty() || !editing) return
        val a = tf.selection.min; val b = tf.selection.max
        if (b > a && tf.text.substring(a, b).equals(q, true))
            change(TextFieldValue(tf.text.replaceRange(a, b, rep), TextRange(a + rep.length)))
        findNext(true)
    }
    fun replaceAll() {
        if (q.isEmpty() || !editing) return
        val n = Regex(Regex.escape(q), RegexOption.IGNORE_CASE).findAll(tf.text).count()
        change(TextFieldValue(tf.text.replace(q, rep, ignoreCase = true)))
        scope.launch { snack.showSnackbar("تم استبدال $n") }
    }

    BackHandler(enabled = dirty) { showExit = true }
    BackHandler(enabled = finding) { finding = false }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text(file.name + if (dirty) " •" else "", maxLines = 1) },
                navigationIcon = { IconButton({ if (dirty) showExit = true else onBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                actions = {
                    if (editing) {
                        IconButton(::doUndo, enabled = undo.isNotEmpty()) { Icon(Icons.AutoMirrored.Rounded.Undo, "تراجع") }
                        IconButton(::doRedo, enabled = redo.isNotEmpty()) { Icon(Icons.AutoMirrored.Rounded.Redo, "إعادة") }
                        IconButton({ save() }, enabled = dirty) { Icon(Icons.Rounded.Save, "حفظ") }
                    }
                    IconButton({ finding = !finding }) { Icon(Icons.Rounded.Search, "بحث") }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "المزيد") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("تكبير الخط") }, { if (fontSize < 32) fontSize += 2 })
                            DropdownMenuItem({ Text("تصغير الخط") }, { if (fontSize > 10) fontSize -= 2 })
                            DropdownMenuItem({ Text("التفاف الأسطر") }, { wrap = !wrap; menu = false }, trailingIcon = { if (wrap) Icon(Icons.Rounded.Check, null) })
                            DropdownMenuItem({ Text("أرقام الأسطر") }, { gutterPref = !gutterPref; menu = false }, trailingIcon = { if (gutterPref) Icon(Icons.Rounded.Check, null) })
                            DropdownMenuItem({ Text("الانتقال إلى سطر…") }, { showGoto = true; menu = false })
                            if (editing && !dirty) DropdownMenuItem({ Text("إنهاء التعديل") }, { editing = false; menu = false })
                            DropdownMenuItem({ Text("فتح بتطبيق آخر") }, { openExternal(ctx, file.path) {}; menu = false })
                        }
                    }
                })
        },
        floatingActionButton = { if (loaded && !editing && error == null) FloatingActionButton({ editing = true }) { Icon(Icons.Rounded.Edit, "تعديل") } }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).imePadding()) {
            if (finding) Surface(tonalElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("بحث") })
                        IconButton({ findNext(false) }) { Icon(Icons.Rounded.KeyboardArrowUp, "السابق") }
                        IconButton({ findNext(true) }) { Icon(Icons.Rounded.KeyboardArrowDown, "التالي") }
                        IconButton({ finding = false }) { Icon(Icons.Rounded.Close, "إغلاق") }
                    }
                    if (editing) Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(rep, { rep = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("استبدال بـ") })
                        TextButton(::replaceOne) { Text("استبدال") }
                        TextButton(::replaceAll) { Text("الكل") }
                    }
                }
            }
            when {
                error != null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text(error!!, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button({ openExternal(ctx, file.path) {} }) { Text("فتح بتطبيق آخر") }
                }
                !loaded -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                else -> BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    viewportPx = constraints.maxHeight
                    val vt = remember(lang, highlightOn, pal) {
                        object : VisualTransformation {
                            override fun filter(text: AnnotatedString) = TransformedText(
                                if (lang != null && highlightOn) highlight(text.text, lang, pal) else text, OffsetMapping.Identity)
                        }
                    }
                    val style = TextStyle(
                        fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, fontSize = fontSize.sp,
                        lineHeight = lh.sp, color = MaterialTheme.colorScheme.onSurface,
                        textDirection = if (mono) TextDirection.Ltr else TextDirection.Content)
                    val field: @Composable (Modifier) -> Unit = { m ->
                        BasicTextField(tf, { change(it) }, m.focusRequester(focus), readOnly = !editing, textStyle = style,
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary), visualTransformation = vt)
                    }
                    // الأكواد تُعرض LTR دائماً حتى مع واجهة عربية
                    CompositionLocalProvider(LocalLayoutDirection provides if (wrap) LocalLayoutDirection.current else LayoutDirection.Ltr) {
                        Row(Modifier.fillMaxSize().verticalScroll(scroll)) {
                            if (showGutter) {
                                val lines = remember(tf.text) { tf.text.count { it == '\n' } + 1 }
                                val nums = remember(lines) { (1..lines).joinToString("\n") }
                                Text(nums, Modifier.background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 8.dp).widthIn(min = 36.dp),
                                    fontFamily = FontFamily.Monospace, fontSize = fontSize.sp, lineHeight = lh.sp,
                                    textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (wrap) field(Modifier.weight(1f).padding(horizontal = 10.dp))
                            else Box(Modifier.weight(1f).horizontalScroll(hScroll)) { field(Modifier.padding(horizontal = 8.dp).widthIn(min = 240.dp)) }
                        }
                    }
                }
            }
        }
    }

    if (showExit) AlertDialog({ showExit = false }, title = { Text("حفظ التغييرات؟") },
        text = { Text("توجد تعديلات لم تُحفظ.") },
        confirmButton = { TextButton({ showExit = false; save { onBack() } }) { Text("حفظ") } },
        dismissButton = { Row { TextButton({ showExit = false }) { Text("إلغاء") }; TextButton({ showExit = false; onBack() }) { Text("تجاهل") } } })
    if (showGoto) {
        var n by remember { mutableStateOf("") }
        AlertDialog({ showGoto = false }, title = { Text("الانتقال إلى سطر") },
            text = { OutlinedTextField(n, { n = it.filter(Char::isDigit) }, singleLine = true) },
            confirmButton = { TextButton({
                val line = (n.toIntOrNull() ?: 1).coerceAtLeast(1)
                var idx = 0; var cur = 1
                while (cur < line) { val nx = tf.text.indexOf('\n', idx); if (nx < 0) break; idx = nx + 1; cur++ }
                select(idx, 0); showGoto = false
            }) { Text("انتقال") } },
            dismissButton = { TextButton({ showGoto = false }) { Text("إلغاء") } })
    }
}

// ───────────────────────── ملفات كبيرة: قراءة فقط ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LargeTextViewer(f: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val text by produceState<String?>(null, f) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val len = minOf(f.length(), MAX_VIEW.toLong()).toInt()
                val buf = ByteArray(len); var r = 0
                f.inputStream().use { while (r < len) { val n = it.read(buf, r, len - r); if (n < 0) break; r += n } }
                String(buf, 0, r, Charsets.UTF_8) + if (f.length() > MAX_VIEW) "\n\n… اقتُطع العرض عند 2 م.ب" else ""
            }.getOrElse { "تعذّرت القراءة: ${it.message}" }
        }
    }
    val lines = remember(text) { text?.split('\n').orEmpty() }
    Scaffold(topBar = {
        TopAppBar(title = { Column { Text(f.name, maxLines = 1); Text("ملف كبير — قراءة فقط (التحرير حتى 1 م.ب)", style = MaterialTheme.typography.labelSmall) } },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
            actions = { TextButton({ openExternal(ctx, f.path) {} }) { Text("فتح خارجياً") } })
    }) { pad ->
        if (text == null) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator() }
        else LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(12.dp)) {
            itemsIndexed(lines) { _, l -> Text(l.ifEmpty { " " }, fontFamily = FontFamily.Monospace, fontSize = 13.sp) }
        }
    }
}
