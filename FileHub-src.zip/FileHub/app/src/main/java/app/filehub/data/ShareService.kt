package app.filehub.data

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import app.filehub.FileApp
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.IOException
import java.security.SecureRandom

class ShareService : Service() {
    companion object {
        const val ACTION_STOP = "app.filehub.STOP_SHARE"
        private const val CHANNEL = "share"
        private const val ID = 42
    }

    private var server: ShareServer? = null
    private var lock: WifiManager.WifiLock? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (server != null) return START_NOT_STICKY
        val app = application as FileApp
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "المشاركة", NotificationManager.IMPORTANCE_LOW))
        val n = notification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(ID, n)

        val token = newToken()
        val srv = startServer(app.prefs.port, token)
        if (srv == null) { ShareHub.addLog("تعذّر تشغيل الخادم"); stopSelf(); return START_NOT_STICKY }
        server = srv
        ShareHub.running.value = RunInfo(srv.listeningPort, token)
        ShareHub.addLog("بدأت المشاركة")
        lock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "filehub:share").apply { acquire() }
        app.prefs.autoStopMin.takeIf { it > 0 }?.let { min ->
            handler.postDelayed({ ShareHub.addLog("إيقاف تلقائي"); stopSelf() }, min * 60_000L)
        }
        return START_NOT_STICKY
    }

    private fun startServer(port: Int, token: String): ShareServer? {
        for (p in listOf(port, 0)) {   // إن كان المنفذ مشغولاً نختار منفذاً حراً
            try {
                val s = ShareServer(p, token, { ShareHub.files.value.map(::File) }, ShareHub::addLog)
                s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                return s
            } catch (_: IOException) { }
        }
        return null
    }

    private fun newToken(): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val r = SecureRandom()
        return (1..8).map { chars[r.nextInt(chars.length)] }.joinToString("")
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, ShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, packageManager.getLaunchIntentForPackage(packageName), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("المشاركة نشطة")
            .setContentText("${ShareHub.files.value.size} عنصر متاح للتنزيل على الشبكة")
            .setContentIntent(open).setOngoing(true)
            .addAction(0, "إيقاف", stop).build()
    }

    override fun onDestroy() {
        server?.stop(); server = null
        lock?.let { if (it.isHeld) it.release() }
        handler.removeCallbacksAndMessages(null)
        ShareHub.running.value = null
        ShareHub.addLog("تم إيقاف المشاركة")
        super.onDestroy()
    }
}
