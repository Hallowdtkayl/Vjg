package app.filehub

import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.content.FileProvider
import app.filehub.ui.AppRoot
import app.filehub.ui.LocalPicker
import app.filehub.ui.PickRequest
import app.filehub.ui.theme.FileHubTheme
import java.io.File

/**
 * منتقي الملفات للتطبيقات الأخرى. نشاط مستقل بوضع تشغيل عادي لأن النتيجة (setResult)
 * لا تُسلَّم من نشاط singleTask بدأه تطبيق آخر.
 */
class PickerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val i = intent
        val mimes = i.getStringArrayExtra(Intent.EXTRA_MIME_TYPES)?.toList() ?: listOfNotNull(i.type)
        val req = PickRequest(i.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false), mimes, ::deliver)
        setContent {
            val st = (application as FileApp).settings
            val sys = isSystemInDarkTheme()
            FileHubTheme(when (st.theme) { 1 -> false; 2 -> true; else -> sys }) {
                CompositionLocalProvider(LocalPicker provides req) { AppRoot(null) {} }
            }
        }
    }

    private fun deliver(paths: List<String>) {
        val uris = paths.map { FileProvider.getUriForFile(this, "$packageName.files", File(it)) }
        if (uris.isEmpty()) { setResult(RESULT_CANCELED); finish(); return }
        val r = Intent().setData(uris.first()).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        r.clipData = ClipData.newRawUri("files", uris.first()).also { c -> uris.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
        setResult(RESULT_OK, r)
        finish()
    }
}
