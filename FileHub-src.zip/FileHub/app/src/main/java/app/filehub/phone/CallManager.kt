package app.filehub.phone

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import app.filehub.FileApp
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

data class CallUi(
    val id: Int, val number: String, val name: String?, val photo: String?, val state: Int, val connectMs: Long,
    val incoming: Boolean, val ignored: Boolean, val canHold: Boolean, val recording: Boolean, val bothSides: Boolean, val sim: String?
) {
    val ringing get() = state == Call.STATE_RINGING
    val title get() = name ?: number.ifEmpty { "رقم مجهول" }
}

/** حالة المكالمات الحالية + أوامر التحكم. تُحدَّث من FileHubInCallService */
object CallManager {
    private class Entry(val call: Call, val incoming: Boolean) {
        var info: ContactInfo? = null
        var ignored = false
        var rec: CallRecorder.Session? = null
        var cb: Call.Callback? = null
    }

    private val entries = CopyOnWriteArrayList<Entry>()
    private val bg = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    val ui = MutableStateFlow<List<CallUi>>(emptyList())
    val muted = MutableStateFlow(false)
    val speaker = MutableStateFlow(false)
    var service: InCallService? = null
    var onChanged: (() -> Unit)? = null
    private lateinit var app: Context

    fun hasRinging() = entries.any { it.call.state == Call.STATE_RINGING && !it.ignored }

    fun add(ctx: Context, call: Call) {
        app = ctx.applicationContext
        val e = Entry(call, call.state == Call.STATE_RINGING)
        val cb = object : Call.Callback() {
            override fun onStateChanged(c: Call, state: Int) { onState(e, state); refresh() }
            override fun onDetailsChanged(c: Call, details: Call.Details) { refresh() }
        }
        e.cb = cb; call.registerCallback(cb); entries.add(e)
        bg.execute {   // البحث عن الجهة خارج الخيط الرئيسي
            e.info = ContactsLookup.lookup(app, number(call))
            handler.post { refresh() }
        }
        refresh()
    }

    fun remove(call: Call) {
        entries.firstOrNull { it.call === call }?.let { e ->
            e.cb?.let { call.unregisterCallback(it) }
            e.rec?.let { CallRecorder.stop(it) }
            entries.remove(e)
        }
        refresh()
    }

    private fun onState(e: Entry, state: Int) {
        if (state != Call.STATE_RINGING) e.ignored = false
        if (state == Call.STATE_ACTIVE && e.rec == null) {
            val mode = (app as FileApp).prefs.autoRecord
            if (mode == 1 || (mode == 2 && e.info == null)) startRecording(e)
        }
        if (state == Call.STATE_DISCONNECTED) { e.rec?.let { CallRecorder.stop(it) }; e.rec = null }
    }

    private fun number(c: Call) = c.details.handle?.schemeSpecificPart.orEmpty()

    private fun startRecording(e: Entry) {
        val n = number(e.call)
        e.rec = CallRecorder.start(app, e.info?.name ?: n.ifEmpty { "unknown" })
    }

    fun refresh() {
        val tm = runCatching { app.getSystemService(TelecomManager::class.java) }.getOrNull()
        ui.value = entries.map { e ->
            val d = e.call.details
            val sim = d.accountHandle?.let { h -> runCatching { tm?.getPhoneAccount(h)?.label?.toString() }.getOrNull() }
            CallUi(System.identityHashCode(e.call), number(e.call), e.info?.name ?: d.callerDisplayName?.takeIf { it.isNotBlank() },
                e.info?.photo, e.call.state, d.connectTimeMillis, e.incoming, e.ignored, d.can(Call.Details.CAPABILITY_HOLD),
                e.rec != null, e.rec?.bothSides == true, sim)
        }
        onChanged?.invoke()
    }

    private fun find(id: Int) = entries.firstOrNull { System.identityHashCode(it.call) == id }
    private fun ringing() = entries.firstOrNull { it.call.state == Call.STATE_RINGING && !it.ignored }

    // ───── الأوامر ─────
    fun answer(id: Int) { find(id)?.call?.answer(0) }
    fun reject(id: Int) { find(id)?.call?.reject(false, null) }
    /** يرفض ويرسل رداً نصياً عبر تطبيق الرسائل الافتراضي (QuickReplyService) */
    fun rejectWithMessage(id: Int, text: String) { find(id)?.call?.reject(true, text) }
    fun hangup(id: Int) { find(id)?.call?.disconnect() }
    fun answerRinging() { ringing()?.call?.answer(0) }
    fun rejectRinging() { ringing()?.call?.reject(false, null) }
    fun hangupAll() { entries.forEach { it.call.disconnect() } }

    /** تجاهل: نوقف الرنين عندنا فقط، والمتصل يسمع الرنين كالمعتاد (لا رد ولا رفض) */
    fun ignore(id: Int) { find(id)?.ignored = true; Ringer.stop(); refresh() }

    fun hold(id: Int, on: Boolean) { find(id)?.call?.let { if (on) it.hold() else it.unhold() } }
    fun swap() {
        val active = entries.firstOrNull { it.call.state == Call.STATE_ACTIVE }
        val held = entries.firstOrNull { it.call.state == Call.STATE_HOLDING }
        active?.call?.hold(); held?.call?.unhold()
    }
    fun setMuted(on: Boolean) { service?.setMuted(on) }
    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE)
    }
    fun dtmf(id: Int, ch: Char) {
        val c = find(id)?.call ?: return
        c.playDtmfTone(ch); handler.postDelayed({ c.stopDtmfTone() }, 150)
    }
    fun toggleRecording(id: Int) {
        val e = find(id) ?: return
        val r = e.rec
        if (r != null) { CallRecorder.stop(r); e.rec = null } else startRecording(e)
        refresh()
    }
}

/** الرنين والاهتزاز، يحترمان وضع الصامت/الاهتزاز في الجهاز */
object Ringer {
    private var ringtone: Ringtone? = null
    private var vib: Vibrator? = null

    fun start(ctx: Context) {
        stop()
        val prefs = (ctx.applicationContext as FileApp).prefs
        val am = ctx.getSystemService(AudioManager::class.java)
        val mode = am.ringerMode
        if (mode == AudioManager.RINGER_MODE_NORMAL) {
            val uri = prefs.ringtone?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(ctx, uri)?.apply {
                audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                if (Build.VERSION.SDK_INT >= 28) isLooping = true
                play()
            }
        }
        if (prefs.vibrate && mode != AudioManager.RINGER_MODE_SILENT) {
            vib = ctx.getSystemService(Vibrator::class.java)?.also {
                it.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 800), 0))
            }
        }
    }

    fun stop() {
        runCatching { ringtone?.stop() }; ringtone = null
        runCatching { vib?.cancel() }; vib = null
    }
}

/**
 * تسجيل المكالمات. تحذير: أندرويد 9+ يمنع التطبيقات العادية من التقاط صوت الطرف الآخر،
 * فنجرّب VOICE_CALL (ينجح مع الروت/التطبيقات المميّزة) ثم نرجع للميكروفون (صوتك + ما يخرج من المكبّر).
 */
object CallRecorder {
    class Session(val file: File, val recorder: MediaRecorder, val bothSides: Boolean)

    fun dir(ctx: Context): File {
        val pub = File(Environment.getExternalStorageDirectory(), "FileHub/CallRecordings")
        if ((pub.isDirectory || pub.mkdirs()) && pub.canWrite()) return pub
        return File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "CallRecordings").also { it.mkdirs() }
    }

    private fun make(ctx: Context, f: File, src: Int): MediaRecorder? {
        @Suppress("DEPRECATION")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        return try {
            r.setAudioSource(src); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(96_000); r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath); r.prepare(); r.start(); r
        } catch (e: Exception) { runCatching { r.release() }; f.delete(); null }
    }

    fun start(ctx: Context, label: String): Session? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return null
        val safe = label.replace(Regex("[^\\p{L}\\p{N}+_-]"), "_")
        val f = File(dir(ctx), "${safe}_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.m4a")
        make(ctx, f, MediaRecorder.AudioSource.VOICE_CALL)?.let { return Session(f, it, true) }
        return make(ctx, f, MediaRecorder.AudioSource.MIC)?.let { Session(f, it, false) }
    }

    fun stop(s: Session) { runCatching { s.recorder.stop() }; runCatching { s.recorder.release() } }

    fun list(ctx: Context): List<File> = dir(ctx).listFiles { f -> f.isFile && f.extension == "m4a" }
        ?.sortedByDescending { it.lastModified() }.orEmpty()
}
