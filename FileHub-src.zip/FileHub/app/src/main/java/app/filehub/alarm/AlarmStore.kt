package app.filehub.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** days: قناع بتات؛ البت (dayOfWeek-1) حيث الأحد=1. days=0 تعني مرة واحدة */
data class Alarm(
    val id: Int, val hour: Int, val minute: Int, val days: Int = 0, val label: String = "", val enabled: Boolean = true,
    val ringtone: String? = null, val vibrate: Boolean = true, val snoozeMin: Int = 9, val gradual: Boolean = true
)

/** state: 0 جاهز، 1 يعمل، 2 متوقف مؤقتاً، 3 انتهى */
data class TimerItem(val id: Int, val label: String, val totalMs: Long, val state: Int, val endsAt: Long, val remainingMs: Long)

data class StopwatchState(val running: Boolean = false, val startWall: Long = 0, val accum: Long = 0, val laps: List<Long> = emptyList()) {
    fun elapsed(now: Long) = accum + if (running) now - startWall else 0
}

/** كل البيانات تُحفظ في نفس ملف الإعدادات، فتدخل في النسخة الاحتياطية تلقائياً */
object AlarmStore {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("view_prefs", Context.MODE_PRIVATE)

    // ───── المنبهات ─────
    fun alarms(c: Context): List<Alarm> = runCatching {
        val a = JSONArray(sp(c).getString("alarms_json", "[]"))
        (0 until a.length()).map { i ->
            a.getJSONObject(i).let { Alarm(it.getInt("id"), it.getInt("h"), it.getInt("m"), it.optInt("d"), it.optString("l"), it.optBoolean("on", true),
                it.optString("r").ifEmpty { null }, it.optBoolean("v", true), it.optInt("s", 9), it.optBoolean("g", true)) }
        }
    }.getOrDefault(emptyList())

    private fun saveAlarms(c: Context, l: List<Alarm>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute).put("d", it.days).put("l", it.label)
            .put("on", it.enabled).put("r", it.ringtone ?: "").put("v", it.vibrate).put("s", it.snoozeMin).put("g", it.gradual)) }
        sp(c).edit().putString("alarms_json", a.toString()).apply()
    }

    fun upsert(c: Context, a: Alarm): Alarm {
        val l = alarms(c).toMutableList()
        val saved = if (a.id == 0) a.copy(id = (l.maxOfOrNull { it.id } ?: 0) + 1) else a
        val i = l.indexOfFirst { it.id == saved.id }
        if (i >= 0) l[i] = saved else l.add(saved)
        saveAlarms(c, l.sortedWith(compareBy({ it.hour }, { it.minute })))
        return saved
    }
    fun delete(c: Context, id: Int) { saveAlarms(c, alarms(c).filter { it.id != id }) }

    // ───── المؤقتات ─────
    fun timers(c: Context): List<TimerItem> = runCatching {
        val a = JSONArray(sp(c).getString("timers_json", "[]"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { TimerItem(it.getInt("id"), it.optString("l"), it.getLong("t"), it.optInt("s"), it.optLong("e"), it.optLong("r")) } }
    }.getOrDefault(emptyList())

    fun saveTimers(c: Context, l: List<TimerItem>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("l", it.label).put("t", it.totalMs).put("s", it.state).put("e", it.endsAt).put("r", it.remainingMs)) }
        sp(c).edit().putString("timers_json", a.toString()).apply()
    }
    fun updateTimer(c: Context, id: Int, f: (TimerItem) -> TimerItem): TimerItem? {
        val l = timers(c).toMutableList(); val i = l.indexOfFirst { it.id == id }
        if (i < 0) return null
        l[i] = f(l[i]); saveTimers(c, l); return l[i]
    }

    // ───── ساعة الإيقاف ─────
    fun stopwatch(c: Context): StopwatchState = runCatching {
        val o = JSONObject(sp(c).getString("stopwatch_json", "{}")); val l = o.optJSONArray("laps") ?: JSONArray()
        StopwatchState(o.optBoolean("run"), o.optLong("start"), o.optLong("acc"), (0 until l.length()).map { l.getLong(it) })
    }.getOrDefault(StopwatchState())
    fun saveStopwatch(c: Context, s: StopwatchState) {
        sp(c).edit().putString("stopwatch_json", JSONObject().put("run", s.running).put("start", s.startWall).put("acc", s.accum).put("laps", JSONArray(s.laps)).toString()).apply()
    }

    // ───── الساعة العالمية ─────
    fun zones(c: Context): List<String> = (sp(c).getString("world_zones", "") ?: "").split(',').filter { it.isNotBlank() }
    fun saveZones(c: Context, z: List<String>) { sp(c).edit().putString("world_zones", z.joinToString(",")).apply() }
}

/** موعد الرنين التالي بالمللي ثانية */
fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance().apply {
        timeInMillis = from; set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    if (a.days == 0) { if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1); return c.timeInMillis }
    repeat(8) {
        if ((a.days and (1 shl (c.get(Calendar.DAY_OF_WEEK) - 1))) != 0 && c.timeInMillis > from) return c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, 1)
    }
    return c.timeInMillis
}
