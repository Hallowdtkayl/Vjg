package app.filehub.web

/** نماذج بيانات المتصفح (الهيكل) */
data class HistoryEntry(val id: Long, val url: String, val title: String, val time: Long)
data class Bookmark(val id: Long, val url: String, val title: String, val time: Long)

/** موقع مثبّت يعمل كتطبيق مستقل: نافذة بلا شريط عنوان، بنفس ملفات الكوكيز */
data class PinnedSite(val id: Long, val name: String, val url: String, val scope: String, val iconPath: String?, val themeColor: Int?)

enum class DlState { QUEUED, RUNNING, PAUSED, FAILED, DONE, CANCELED, WAITING_NETWORK }

/** تنزيل: يحتفظ بالمصدر الأصلي والصفحة والكوكيز ليتمكن من تحديث الرابط المنتهي */
data class DownloadItem(
    val id: Long, val url: String, val originalUrl: String, val pageUrl: String?, val fileName: String, val mime: String?,
    val dir: String, val total: Long, val done: Long, val state: DlState, val segments: Int,
    val userAgent: String?, val cookies: String?, val resumable: Boolean, val etag: String?, val createdAt: Long, val error: String? = null
)

/** قطعة تنزيل: [start, end] شاملة، وpos = أول بايت لم يُكتب بعد */
data class Segment(val index: Int, val start: Long, val end: Long, val pos: Long) {
    val remaining get() = (end - pos + 1).coerceAtLeast(0)
}

/** ما يصل من WebView عند طلب تنزيل */
data class DownloadRequest(val url: String, val userAgent: String?, val contentDisposition: String?, val mime: String?, val length: Long, val pageUrl: String?)

/** وسيط يُلتقط من الصفحة (صورة/فيديو/صوت) ليُعرض في «محتوى الصفحة» */
data class SniffedMedia(val url: String, val kind: String, val pageUrl: String?)

object SearchEngines {
    val all = listOf("Google" to "https://www.google.com/search?q=", "DuckDuckGo" to "https://duckduckgo.com/?q=",
        "Bing" to "https://www.bing.com/search?q=", "Brave" to "https://search.brave.com/search?q=")
    const val DEFAULT_HOME = "about:blank"
}
