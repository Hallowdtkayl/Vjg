package app.filehub.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/** التصنيفات الذكية — كل تصنيف يحدد أساليب العرض المسموحة له */
enum class Category(
    val id: String, val title: String, val icon: ImageVector, val color: Color,
    val allowsFolders: Boolean, val defaultFlat: Boolean
) {
    Images("images", "الصور", Icons.Rounded.Image, Color(0xFFE91E63), true, true),
    Videos("videos", "الفيديو", Icons.Rounded.VideoLibrary, Color(0xFF7C4DFF), true, true),
    Audio("audio", "الصوتيات", Icons.Rounded.AudioFile, Color(0xFFFF9800), true, true),
    Documents("docs", "المستندات", Icons.Rounded.Description, Color(0xFF2196F3), true, true),
    Archives("archives", "المضغوطات", Icons.Rounded.FolderZip, Color(0xFF795548), false, true),
    Apps("apps", "التطبيقات", Icons.Rounded.Android, Color(0xFF4CAF50), false, true),
    Recent("recent", "المضافة حديثاً", Icons.Rounded.Schedule, Color(0xFF00BCD4), false, true),
    Large("large", "الملفات الكبيرة", Icons.Rounded.DataUsage, Color(0xFFF44336), false, true),
    Trash("trash", "سلة المحذوفات", Icons.Rounded.Delete, Color(0xFF607D8B), false, true);
    companion object { fun byId(id: String?) = entries.firstOrNull { it.id == id } }
}

enum class SortBy(val label: String) { Name("الاسم"), Date("التاريخ"), Size("الحجم"), Type("النوع") }
enum class DisplayStyle(val label: String) { List("قائمة"), Detailed("تفصيلي"), Grid("شبكة") }
/** بالمجلدات (هرمي) أو حر (كل الملفات في قائمة واحدة) */
enum class BrowseMode { Folders, Flat }

data class ViewPrefs(
    val sortBy: SortBy = SortBy.Date,
    val ascending: Boolean = false,
    val style: DisplayStyle = DisplayStyle.List,
    val mode: BrowseMode = BrowseMode.Folders
)

data class FileItem(
    val name: String, val path: String, val isDir: Boolean,
    val size: Long = 0, val modified: Long = 0, val ext: String = "",
    val count: Int = 0,            // عدد الملفات داخل مجلد افتراضي (عرض التصنيف بالمجلدات)
    val original: String? = null   // المسار الأصلي للعناصر داخل السلة
)

data class StorageVolume(
    val name: String, val kind: Kind, val root: String, val used: Long, val total: Long
) { enum class Kind { Internal, SdCard, Usb } }
