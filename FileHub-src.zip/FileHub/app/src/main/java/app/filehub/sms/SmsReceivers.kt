package app.filehub.sms

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import app.filehub.MainActivity
import app.filehub.phone.Blocklist
import app.filehub.phone.ContactsLookup
import kotlin.concurrent.thread

/** نتيجة الإرسال: نحدّث نوع الرسالة (مرسلة/فاشلة) */
class SmsSentReceiver : BroadcastReceiver() {
    companion object { const val ACTION = "app.filehub.SMS_SENT" }
    override fun onReceive(ctx: Context, i: Intent) {
        val uri = i.getStringExtra("uri")?.let(Uri::parse) ?: return
        val last = i.getIntExtra("i", 0) == i.getIntExtra("n", 1) - 1
        if (resultCode != Activity.RESULT_OK) SmsRepo.updateType(ctx, uri, Telephony.Sms.MESSAGE_TYPE_FAILED)
        else if (last) SmsRepo.updateType(ctx, uri, Telephony.Sms.MESSAGE_TYPE_SENT)
    }
}

/** استقبال SMS: لأننا التطبيق الافتراضي، علينا نحن كتابتها في المزوّد وإظهار الإشعار */
class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)?.takeIf { it.isNotEmpty() } ?: return
        val address = msgs[0].displayOriginatingAddress ?: return
        val body = msgs.joinToString("") { it.displayMessageBody ?: "" }
        val sub = i.getIntExtra("subscription", -1)
        val pending = goAsync()
        thread {
            try {
                if (!Blocklist.isBlocked(ctx, address)) {      // المحظور يُسقط بصمت
                    val now = System.currentTimeMillis()
                    val uri = SmsRepo.insertInbox(ctx, address, body, now, msgs[0].timestampMillis, sub)
                    val tid = uri?.let { SmsRepo.threadIdOf(ctx, it) } ?: -1L
                    MessageNotifier.incoming(ctx, address, body, tid, now)
                }
            } finally { pending.finish() }
        }
    }
}

/** MMS غير مدعومة بعد: ننبّه المستخدم فقط (مطلوب وجود المستقبِل ليصلح التطبيق كافتراضي) */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        MessageNotifier.simple(ctx, "رسالة وسائط (MMS) واردة", "هذا الإصدار لا يستقبل MMS. افتحها من تطبيق الرسائل الأصلي إن كان مثبتاً.")
    }
}

class ReplyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString()?.trim().orEmpty()
        val address = i.getStringExtra("address") ?: return
        val tid = i.getLongExtra("thread", -1)
        if (text.isNotEmpty()) SmsRepo.send(ctx, address, text)
        if (tid >= 0) SmsRepo.markThreadRead(ctx, tid)
        MessageNotifier.cancel(ctx, tid)
    }
}

class ReadReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val tid = i.getLongExtra("thread", -1)
        if (tid >= 0) { SmsRepo.markThreadRead(ctx, tid); MessageNotifier.cancel(ctx, tid) }
    }
}

/** «الرد برسالة» من شاشة المكالمة: النظام يستدعي هذه الخدمة لدى تطبيق الرسائل الافتراضي */
class QuickReplyService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val to = intent?.data?.schemeSpecificPart?.substringBefore(',')?.substringBefore(';')
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
        if (!to.isNullOrBlank() && !text.isNullOrBlank()) SmsRepo.send(this, to, text)
        stopSelf(startId)
        return START_NOT_STICKY
    }
}

object MessageNotifier {
    private const val CH = "messages"
    private val recent = HashMap<Long, MutableList<Pair<String, Long>>>()

    private fun ensure(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "الرسائل", NotificationManager.IMPORTANCE_HIGH))
    }

    fun incoming(ctx: Context, address: String, body: String, threadId: Long, date: Long) {
        ensure(ctx)
        val name = ContactsLookup.lookup(ctx, address)?.name ?: address
        val id = if (threadId >= 0) threadId.toInt() else address.hashCode()
        val list = synchronized(recent) { recent.getOrPut(threadId) { mutableListOf() }.also { it.add(body to date); while (it.size > 6) it.removeAt(0) }.toList() }
        val style = NotificationCompat.MessagingStyle(Person.Builder().setName("أنا").build())
        val them = Person.Builder().setName(name).build()
        list.forEach { style.addMessage(it.first, it.second, them) }

        val open = PendingIntent.getActivity(ctx, id, Intent(ctx, MainActivity::class.java).setAction("app.filehub.OPEN_THREAD")
            .putExtra("thread", threadId).putExtra("address", address).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val replyPi = PendingIntent.getBroadcast(ctx, id, Intent(ctx, ReplyReceiver::class.java).putExtra("address", address).putExtra("thread", threadId),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)       // RemoteInput يتطلب MUTABLE
        val readPi = PendingIntent.getBroadcast(ctx, id, Intent(ctx, ReadReceiver::class.java).putExtra("thread", threadId),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val reply = NotificationCompat.Action.Builder(0, "رد", replyPi)
            .addRemoteInput(RemoteInput.Builder("reply").setLabel("اكتب ردّك").build())
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY).build()
        val n = NotificationCompat.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_notify_chat).setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true)
            .setContentIntent(open).addAction(reply).addAction(0, "تمّت القراءة", readPi).build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(id, n) }
    }

    fun simple(ctx: Context, title: String, text: String) {
        ensure(ctx)
        val n = NotificationCompat.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(System.currentTimeMillis().toInt(), n) }
    }

    fun cancel(ctx: Context, threadId: Long) {
        synchronized(recent) { recent.remove(threadId) }
        ctx.getSystemService(NotificationManager::class.java).cancel(if (threadId >= 0) threadId.toInt() else 0)
    }
}
