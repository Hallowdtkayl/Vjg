package app.filehub.ui.screens

import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.filehub.data.ShareHub
import app.filehub.incoming.IncomingHub
import app.filehub.incoming.IncomingResolver
import app.filehub.ui.viewers.routeFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يستقبل ملفاً من تطبيق آخر ويوجّهه إلى القارئ المناسب (صور، فيديو، PDF، ضغط، نص…) */
@Composable
fun IncomingViewScreen(onRoute: (String) -> Unit, onShare: (File) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf<String?>(null) }
    var unsupported by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(Unit) {
        IncomingHub.text?.let { text ->          // نص مُشارَك → ملاحظة جديدة في المحرر
            IncomingHub.text = null
            val f = withContext(Dispatchers.IO) {
                runCatching {
                    val dir = File(Environment.getExternalStorageDirectory(), "FileHub/Notes").also { it.mkdirs() }
                    File(dir, "نص-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt").also { it.writeText(text) }
                }.getOrNull()
            }
            if (f != null) routeFor(f.path)?.let(onRoute) else msg = "تعذّر حفظ النص"
            return@LaunchedEffect
        }
        val uri = IncomingHub.uris.firstOrNull() ?: run { msg = "لا يوجد ملف"; return@LaunchedEffect }
        val f = withContext(Dispatchers.IO) { runCatching { IncomingResolver.resolve(ctx, uri, IncomingHub.mime) }.getOrNull() }
        when {
            f == null -> msg = "تعذّر فتح الملف"
            f.isDirectory -> onRoute("folder?path=${Uri.encode(f.path)}")
            else -> routeFor(f.path)?.let(onRoute) ?: run { unsupported = f }
        }
    }

    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        val f = unsupported
        when {
            f != null -> {
                Icon(Icons.Rounded.InsertDriveFile, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
                Text(f.name, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
                Text("نوع غير مدعوم داخلياً", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Button({ onRoute("view/text?path=${Uri.encode(f.path)}") }) { Text("عرض كنص") }
                OutlinedButton({ onShare(f) }) { Text("مشاركة عبر QR") }
                TextButton({ openExternal(ctx, f.path) { msg = it } }) { Text("فتح بتطبيق آخر") }
            }
            msg != null -> { Text(msg!!, textAlign = TextAlign.Center); TextButton(onClose) { Text("إغلاق") } }
            else -> { CircularProgressIndicator(); Text("جارٍ التحضير…", Modifier.padding(top = 12.dp)) }
        }
    }
}

/** ملفات مُشارَكة إلى «ملفاتي»: نجهّزها ونضيفها لنقطة المشاركة بـ QR */
@Composable
fun ShareInScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        val paths = withContext(Dispatchers.IO) {
            IncomingHub.uris.mapNotNull { runCatching { IncomingResolver.resolve(ctx, it, null) }.getOrNull() }.filter { it.exists() }.map { it.path }
        }
        ShareHub.add(paths)
        onDone()
    }
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        CircularProgressIndicator(); Text("جارٍ تجهيز الملفات للمشاركة…", Modifier.padding(top = 12.dp))
    }
}
