package app.filehub.phone

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telecom.Call
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Message
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.filehub.ui.phone.Avatar
import app.filehub.ui.theme.FileHubTheme
import kotlinx.coroutines.delay

class InCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // تظهر فوق شاشة القفل وتوقظ الشاشة
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else @Suppress("DEPRECATION") window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { FileHubTheme(dark = true) { InCallScreen { finish() } } }
    }
}

private val Green = Color(0xFF2E7D32)
private val Red = Color(0xFFD32F2F)

@Composable
private fun RoundBtn(icon: ImageVector, label: String?, color: Color, size: Int = 68, onClick: () -> Unit, enabled: Boolean = true) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(onClick, Modifier.size(size.dp), enabled = enabled, colors = IconButtonDefaults.filledIconButtonColors(containerColor = color)) {
            Icon(icon, label, Modifier.size((size * .42f).dp), tint = Color.White)
        }
        if (label != null) Text(label, Modifier.padding(top = 6.dp), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
    }
}

@Composable
private fun InCallScreen(onFinish: () -> Unit) {
    val calls by CallManager.ui.collectAsState()
    var seen by remember { mutableStateOf(false) }
    LaunchedEffect(calls) {
        if (calls.isNotEmpty()) seen = true
        val onlyIgnored = calls.isNotEmpty() && calls.all { it.ringing && it.ignored }
        when {
            onlyIgnored -> onFinish()                             // تجاهلها: نغلق الشاشة وتبقى تدق عند المتصل
            calls.isEmpty() -> { delay(if (seen) 900 else 2500); if (CallManager.ui.value.isEmpty()) onFinish() }
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B2250), Color(0xFF0B0D17))))) {
        val ringing = calls.firstOrNull { it.ringing && !it.ignored }
        when {
            ringing != null -> Ringing(ringing, calls.size > 1)
            calls.isNotEmpty() -> Active(calls)
            else -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(if (seen) "انتهت المكالمة" else "…", color = Color.White, fontSize = 22.sp) }
        }
    }
}

@Composable
private fun Header(c: CallUi, status: String) {
    Column(Modifier.fillMaxWidth().padding(top = 72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(status, color = Color.White.copy(alpha = .75f), fontSize = 15.sp)
        c.sim?.let { Text(it, color = Color.White.copy(alpha = .55f), fontSize = 12.sp) }
        Spacer(Modifier.height(28.dp))
        Avatar(c.title, c.photo, 128)
        Spacer(Modifier.height(20.dp))
        Text(c.title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
        if (c.name != null) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(c.number, color = Color.White.copy(alpha = .7f), fontSize = 16.sp)
        }
    }
}

@Composable
private fun Ringing(c: CallUi, waiting: Boolean) {
    val ctx = LocalContext.current
    var showReplies by remember { mutableStateOf(false) }
    if (showReplies) {
        val replies = remember { (ctx.applicationContext as app.filehub.FileApp).prefs.quickReplies.lines().map { it.trim() }.filter { it.isNotEmpty() } }
        AlertDialog({ showReplies = false }, title = { Text("رفض مع رسالة") },
            text = { Column { replies.forEach { r -> TextButton({ CallManager.rejectWithMessage(c.id, r); showReplies = false }) { Text(r, textAlign = TextAlign.Start) } } } },
            confirmButton = { TextButton({ showReplies = false }) { Text("إلغاء") } })
    }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, 1.14f,
        infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    Column(Modifier.fillMaxSize().padding(bottom = 56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Header(c, if (waiting) "مكالمة أخرى واردة" else "مكالمة واردة")
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(bottom = 36.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundBtn(Icons.Rounded.NotificationsOff, "تجاهل", Color(0xFF455A64), 56, { CallManager.ignore(c.id) })
            RoundBtn(Icons.AutoMirrored.Rounded.Message, "رسالة", Color(0xFF455A64), 56,
                { showReplies = true })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundBtn(Icons.Rounded.CallEnd, "رفض", Red, 76, { CallManager.reject(c.id) })
            Box(Modifier.scale(pulse)) { RoundBtn(Icons.Rounded.Call, "رد", Green, 76, { CallManager.answer(c.id) }) }
        }
    }
}

@Composable
private fun Active(calls: List<CallUi>) {
    val ctx = LocalContext.current
    val muted by CallManager.muted.collectAsState()
    val speaker by CallManager.speaker.collectAsState()
    val c = calls.firstOrNull { it.state == Call.STATE_ACTIVE || it.state == Call.STATE_DIALING || it.state == Call.STATE_CONNECTING }
        ?: calls.firstOrNull { it.state == Call.STATE_HOLDING } ?: calls.first()
    val other = calls.firstOrNull { it.id != c.id }
    var pad by remember { mutableStateOf(false) }
    val seconds by produceState(0L, c.connectMs, c.state) {
        while (true) { value = if (c.connectMs > 0) (System.currentTimeMillis() - c.connectMs) / 1000 else 0; delay(500) }
    }
    val status = when (c.state) {
        Call.STATE_DIALING, Call.STATE_CONNECTING -> "جارٍ الاتصال…"
        Call.STATE_HOLDING -> "معلّقة"
        Call.STATE_DISCONNECTED -> "انتهت المكالمة"
        else -> "%02d:%02d".format(seconds / 60, seconds % 60)
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) CallManager.toggleRecording(c.id) else Toast.makeText(ctx, "إذن الميكروفون مطلوب للتسجيل", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().padding(bottom = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Header(c, status)
        if (c.recording) Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(Red)); Spacer(Modifier.width(6.dp))
            Text(if (c.bothSides) "جارٍ التسجيل" else "جارٍ التسجيل (صوتك فقط — فعّل المكبّر لالتقاط الطرف الآخر)",
                color = Color.White.copy(alpha = .8f), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
        }
        other?.let { o ->
            AssistChip({ CallManager.swap() }, { Text("${o.title} — ${if (o.state == Call.STATE_HOLDING) "معلّقة، اضغط للتبديل" else "نشطة"}") },
                Modifier.padding(top = 14.dp), leadingIcon = { Icon(Icons.Rounded.SwapCalls, null) })
        }
        Spacer(Modifier.weight(1f))
        if (pad) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("123", "456", "789", "*0#").forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        row.forEach { ch ->
                            FilledTonalButton({ CallManager.dtmf(c.id, ch) }, Modifier.size(64.dp), shape = CircleShape, contentPadding = PaddingValues(0.dp)) {
                                Text(ch.toString(), fontSize = 24.sp)
                            }
                        }
                    }
                }
                TextButton({ pad = false }) { Text("إخفاء", color = Color.White) }
            }
        } else Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundBtn(if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic, "كتم", if (muted) Color(0xFF3949D6) else Color(0xFF37474F), 62, { CallManager.setMuted(!muted) })
                RoundBtn(Icons.Rounded.Dialpad, "لوحة", Color(0xFF37474F), 62, { pad = true })
                RoundBtn(Icons.AutoMirrored.Rounded.VolumeUp, "مكبّر", if (speaker) Color(0xFF3949D6) else Color(0xFF37474F), 62, { CallManager.setSpeaker(!speaker) })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RoundBtn(Icons.Rounded.FiberManualRecord, if (c.recording) "إيقاف" else "تسجيل", if (c.recording) Red else Color(0xFF37474F), 62, {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) CallManager.toggleRecording(c.id)
                    else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                })
                RoundBtn(Icons.Rounded.Pause, if (c.state == Call.STATE_HOLDING) "استئناف" else "انتظار",
                    if (c.state == Call.STATE_HOLDING) Color(0xFF3949D6) else Color(0xFF37474F), 62,
                    { CallManager.hold(c.id, c.state != Call.STATE_HOLDING) }, enabled = c.canHold)
                RoundBtn(Icons.Rounded.PersonAdd, "إضافة", Color(0xFF37474F), 62, {
                    ctx.startActivity(Intent(Intent.ACTION_DIAL).setPackage(ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            }
        }
        Spacer(Modifier.height(28.dp))
        RoundBtn(Icons.Rounded.CallEnd, null, Red, 72, { CallManager.hangup(c.id) })
    }
}
