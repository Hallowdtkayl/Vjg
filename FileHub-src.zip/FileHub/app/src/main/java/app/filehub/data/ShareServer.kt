package app.filehub.data

import android.os.Build
import android.webkit.MimeTypeMap
import app.filehub.model.FileTypes
import app.filehub.ui.readableSize
import fi.iki.elonen.NanoHTTPD
import java.io.*
import java.net.URLEncoder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.concurrent.thread

/**
 * خادم HTTP محلي. كل المسارات تحت /<token>/ ، وأي مسار آخر يرجع 404.
 *  /<token>/          صفحة التنزيل
 *  /<token>/f/<i>     ملف (يدعم Range للاستئناف والتقديم في الفيديو)
 *  /<token>/z/<i>     مجلد كملف zip
 *  /<token>/all       كل العناصر في zip
 */
class ShareServer(
    port: Int, private val token: String,
    private val items: () -> List<File>, private val log: (String) -> Unit
) : NanoHTTPD(port) {

    private fun plain(st: Response.IStatus, msg: String) = newFixedLengthResponse(st, "text/plain; charset=utf-8", msg)

    override fun serve(s: IHTTPSession): Response {
        val parts = s.uri.trim('/').split('/')
        if (parts[0] != token) return plain(Response.Status.NOT_FOUND, "الرابط غير صالح")
        val list = items().filter { it.exists() }
        return try {
            val idx = parts.getOrNull(2)?.toIntOrNull() ?: -1
            when (parts.getOrNull(1)) {
                null, "" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", page(list))
                "f" -> list.getOrNull(idx)?.takeIf { it.isFile }?.let { sendFile(it, s) } ?: plain(Response.Status.NOT_FOUND, "غير موجود")
                "z" -> list.getOrNull(idx)?.takeIf { it.isDirectory }?.let { log("${s.remoteIpAddress} ← ${it.name}.zip"); zip("${it.name}.zip", listOf(it)) }
                    ?: plain(Response.Status.NOT_FOUND, "غير موجود")
                "all" -> { log("${s.remoteIpAddress} ← تنزيل الكل"); zip("FileHub.zip", list) }
                else -> plain(Response.Status.NOT_FOUND, "غير موجود")
            }
        } catch (e: Exception) { plain(Response.Status.INTERNAL_ERROR, "خطأ داخلي") }
    }

    private fun mimeOf(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"

    private fun disposition(name: String, inline: Boolean): String {
        val ascii = name.map { if (it.code in 32..126 && it != '"') it else '_' }.joinToString("")
        val enc = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
        return "${if (inline) "inline" else "attachment"}; filename=\"$ascii\"; filename*=UTF-8''$enc"
    }

    private fun sendFile(f: File, s: IHTTPSession): Response {
        val len = f.length()
        val inline = s.parameters["inline"] != null
        var start = 0L; var end = len - 1; var partial = false
        s.headers["range"]?.takeIf { it.startsWith("bytes=") }?.let { h ->
            val r = h.removePrefix("bytes=").split("-")
            if (r[0].isEmpty()) { start = maxOf(0, len - (r.getOrNull(1)?.toLongOrNull() ?: 0)) }
            else { start = r[0].toLongOrNull() ?: 0; end = r.getOrNull(1)?.toLongOrNull()?.coerceAtMost(len - 1) ?: (len - 1) }
            partial = true
        }
        if (len == 0L || start >= len || end < start) {
            return plain(Response.Status.RANGE_NOT_SATISFIABLE, "").also { it.addHeader("Content-Range", "bytes */$len") }
        }
        if (start == 0L && !inline) log("${s.remoteIpAddress} ← ${f.name}")
        val ins = FileInputStream(f).also { it.channel.position(start) }
        val n = end - start + 1
        return newFixedLengthResponse(if (partial) Response.Status.PARTIAL_CONTENT else Response.Status.OK, mimeOf(f), ins, n).also {
            it.addHeader("Accept-Ranges", "bytes")
            it.addHeader("Content-Disposition", disposition(f.name, inline))
            if (partial) it.addHeader("Content-Range", "bytes $start-$end/$len")
        }
    }

    /** ضغط متدفق: لا يُنشأ ملف مؤقت على الجهاز */
    private fun zip(name: String, list: List<File>): Response {
        val pin = PipedInputStream(512 * 1024)
        val pout = PipedOutputStream(pin)
        thread(isDaemon = true) {
            try {
                ZipOutputStream(BufferedOutputStream(pout, 64 * 1024)).use { z ->
                    z.setLevel(1)
                    val used = HashSet<String>()
                    fun add(f: File, entry: String) {
                        var e = entry; var i = 1
                        while (!used.add(e)) e = "${i++}_$entry"
                        z.putNextEntry(ZipEntry(e).apply { time = f.lastModified() })
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                    list.forEach { f ->
                        if (f.isFile) add(f, f.name)
                        else f.walkTopDown().filter { it.isFile }.forEach { add(it, f.name + "/" + it.relativeTo(f).path.replace('\\', '/')) }
                    }
                }
            } catch (_: IOException) { } finally { runCatching { pout.close() } }
        }
        return newChunkedResponse(Response.Status.OK, "application/zip", pin).also {
            it.addHeader("Content-Disposition", disposition(name, false))
        }
    }

    // ───── صفحة التنزيل ─────
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun iconOf(f: File): String = if (f.isDirectory) "📁" else when (f.extension.lowercase()) {
        in FileTypes.images -> "🖼️"; in FileTypes.videos -> "🎬"; in FileTypes.audio -> "🎵"
        in FileTypes.archives -> "📦"; in FileTypes.docs -> "📄"; in FileTypes.apps -> "🤖"; else -> "📎"
    }

    private fun folderSize(f: File) = f.walkTopDown().sumOf { if (it.isFile) it.length() else 0L }

    private fun page(list: List<File>): String = buildString {
        val base = "/$token"
        append("""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>ملفاتي</title><style>
:root{--bg:#f5f6fb;--card:#fff;--text:#1b1e2b;--muted:#6b7090;--p:#3949d6;--soft:#e8eaff}
@media(prefers-color-scheme:dark){:root{--bg:#0f1118;--card:#181b26;--text:#eceefb;--muted:#9aa0c3;--p:#9fa8ff;--soft:#262b44}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,"Segoe UI",Tahoma,sans-serif}
header{padding:28px 20px 22px;background:linear-gradient(135deg,#3949d6,#00a8a8);color:#fff;border-radius:0 0 28px 28px}
header h1{margin:0 0 6px;font-size:22px}header p{margin:0;opacity:.9;font-size:14px}
main{max-width:720px;margin:0 auto;padding:18px 14px 40px}
.card{display:flex;align-items:center;gap:14px;background:var(--card);border-radius:18px;padding:12px 14px;margin-bottom:10px;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.ic{width:56px;height:56px;border-radius:14px;background:var(--soft);display:flex;align-items:center;justify-content:center;font-size:28px;overflow:hidden;flex:none}
.ic img{width:100%;height:100%;object-fit:cover}
.info{flex:1;min-width:0}.name{font-weight:600;word-break:break-word}.meta{color:var(--muted);font-size:13px;margin-top:2px}
.btn{display:inline-block;background:var(--p);color:#fff;text-decoration:none;padding:9px 16px;border-radius:12px;font-weight:600;font-size:14px;white-space:nowrap}
.btn.ghost{background:var(--soft);color:var(--p);margin-inline-end:6px}
.all{display:block;text-align:center;margin:6px 0 16px;padding:14px;font-size:16px}
.row{display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end}
</style></head><body><header><h1>📂 ملفات مشتركة</h1><p>""")
        append(esc(Build.MODEL)); append(" • ${list.size} عنصر</p></header><main>")
        if (list.size > 1) append("""<a class="btn all" href="$base/all">⬇️ تنزيل الكل (ملف ZIP)</a>""")
        list.forEachIndexed { i, f ->
            val ext = f.extension.lowercase()
            val thumb = if (f.isFile && ext in FileTypes.images && ext != "svg" && f.length() < 3_000_000)
                """<img loading="lazy" src="$base/f/$i?inline=1" alt="">""" else iconOf(f)
            val size = (if (f.isDirectory) folderSize(f) else f.length()).readableSize()
            val previewable = f.isFile && (ext in FileTypes.videos || ext in FileTypes.audio || ext == "pdf" || ext in FileTypes.images)
            append("""<div class="card"><div class="ic">$thumb</div><div class="info"><div class="name">${esc(f.name)}</div><div class="meta">${if (f.isDirectory) "مجلد • " else ""}$size</div></div><div class="row">""")
            if (previewable) append("""<a class="btn ghost" target="_blank" href="$base/f/$i?inline=1">معاينة</a>""")
            append(if (f.isDirectory) """<a class="btn" href="$base/z/$i">تنزيل ZIP</a>""" else """<a class="btn" href="$base/f/$i" download>تنزيل</a>""")
            append("</div></div>")
        }
        append("</main></body></html>")
    }
}
