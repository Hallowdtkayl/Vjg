package app.filehub.ui.screens

import android.app.Application
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.rounded.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import app.filehub.FileApp
import app.filehub.model.*
import app.filehub.ui.components.*
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import kotlinx.coroutines.launch

data class HomeState(val volumes: List<StorageVolume> = emptyList(), val counts: Map<Category, Int> = emptyMap(), val missed: Int = 0, val unread: Int = 0)

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as FileApp).repo
    var state by mutableStateOf(HomeState()); private set

    fun refresh() = viewModelScope.launch {
        state = state.copy(volumes = repo.volumes())
        val all = repo.scan(force = true, showHidden = (getApplication<FileApp>()).prefs.showHidden)
        val now = System.currentTimeMillis()
        val counts = Category.entries.filter { it != Category.Trash }
            .associateWith { c -> all.count { c.matches(it, now) } }.toMutableMap<Category, Int>()
        counts[Category.Trash] = repo.listTrash().size
        val missed = app.filehub.phone.CallLogRepo.missedUnread(getApplication())
        val unread = runCatching { app.filehub.sms.SmsRepo.unreadCount(getApplication()) }.getOrDefault(0)
        state = state.copy(volumes = repo.volumes(), counts = counts, missed = missed, unread = unread)
    }
}

@Composable
fun HomeScreen(onVolume: (String) -> Unit, onCategory: (String) -> Unit, onPhone: () -> Unit, onMessages: () -> Unit, onContacts: () -> Unit, onClock: () -> Unit, onEditor: () -> Unit, onCalc: () -> Unit, onWeb: () -> Unit, onWebDownloads: () -> Unit, onWebBookmarks: () -> Unit, pad: PaddingValues) {
    val pick = app.filehub.ui.LocalPicker.current
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val vm: HomeViewModel = viewModel()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }
    val st = vm.state
    LazyColumn(Modifier.padding(pad)) {
        if (pick != null) item {
            androidx.compose.material3.Card(Modifier.padding(12.dp).fillMaxWidth(), colors = androidx.compose.material3.CardDefaults.cardColors(androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer)) {
                Text("اختر الملف الذي تريد إرساله إلى التطبيق الطالب", Modifier.padding(16.dp))
            }
        }
        item { SectionTitle("وحدات التخزين") }
        items(st.volumes) { v ->
            StorageCard(v, { onVolume(v.root) }, Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth())
        }
        item { SectionTitle("التصنيفات") }
        Category.entries.chunked(3).forEach { row ->
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    row.forEach { c -> CategoryTile(c, st.counts[c], { onCategory(c.id) }, Modifier.weight(1f)) }
                }
            }
        }
        item { SectionTitle("التواصل") }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                CommTile(androidx.compose.material.icons.Icons.Rounded.Call, "هاتف", Color(0xFF2E7D32), st.missed, onPhone, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.Sms, "رسائل", Color(0xFF1E88E5), st.unread, onMessages, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.Contacts, "جهات الاتصال", Color(0xFFF57C00), 0, onContacts, Modifier.weight(1f))
            }
        }
        item { SectionTitle("الأدوات") }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                // التقويم يُبنى في التحديث القادم (مؤقتاً نفتح تقويم النظام إن وُجد)
                CommTile(androidx.compose.material.icons.Icons.Rounded.CalendarMonth, "التقويم", Color(0xFFE53935), 0, {
                    runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("content://com.android.calendar/time/${System.currentTimeMillis()}")).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        .onFailure { android.widget.Toast.makeText(ctx, "التقويم يُبنى في تحديث قادم", android.widget.Toast.LENGTH_SHORT).show() }
                }, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.Alarm, "المنبه", Color(0xFF8E24AA), 0, onClock, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.Calculate, "الحاسبة", Color(0xFF00897B), 0, onCalc, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.EditNote, "المحرر", Color(0xFF546E7A), 0, onEditor, Modifier.weight(1f))
            }
        }
        item { SectionTitle("الويب") }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                CommTile(androidx.compose.material.icons.Icons.Rounded.Language, "المتصفح", Color(0xFF1E88E5), 0, onWeb, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.Download, "التنزيلات", Color(0xFF43A047), 0, onWebDownloads, Modifier.weight(1f))
                CommTile(androidx.compose.material.icons.Icons.Rounded.Bookmarks, "العلامات", Color(0xFFFFB300), 0, onWebBookmarks, Modifier.weight(1f))
            }
        }
        item { PinnedSitesStrip() }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun CommTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, badge: Int, onClick: () -> Unit, modifier: Modifier) {
    Card(onClick, modifier.padding(4.dp), shape = androidx.compose.material3.MaterialTheme.shapes.large) {
        Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
            BadgedBox({ if (badge > 0) Badge { Text(badge.toString()) } }) { IconBadge(icon, color, 56) }
            Spacer(Modifier.height(8.dp))
            Text(label, style = androidx.compose.material3.MaterialTheme.typography.labelLarge)
        }
    }
}

/** المواقع المثبّتة: تظهر هنا كاختصارات تفتح نافذة مستقلة كأنها تطبيقات */
@Composable
private fun PinnedSitesStrip() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val sites = remember { runCatching { app.filehub.web.WebDb.get(ctx).pinned() }.getOrDefault(emptyList()) }
    if (sites.isEmpty()) return
    SectionTitle("مواقعي المثبّتة")
    androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items(sites.size) { i ->
            val s = sites[i]
            Column(Modifier.clickable { app.filehub.web.PwaInstaller.launch(ctx, s) }.width(68.dp), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                app.filehub.ui.phone.Avatar(s.name, null, 52)
                Text(s.name, style = androidx.compose.material3.MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        }
    }
}
