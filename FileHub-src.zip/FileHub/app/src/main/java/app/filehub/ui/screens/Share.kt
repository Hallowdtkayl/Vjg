package app.filehub.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.filehub.data.*
import app.filehub.ui.components.SectionTitle
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.delay
import java.io.File

/** رمز QR يُرسم مباشرة على Canvas: أسود على أبيض دائماً ليقرأه أي ماسح حتى في الوضع الداكن */
@Composable
fun QrCode(text: String, size: Dp = 220.dp) {
    val matrix = remember(text) {
        QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0,
            mapOf(EncodeHintType.MARGIN to 0, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.CHARACTER_SET to "UTF-8"))
    }
    Box(Modifier.background(Color.White, MaterialTheme.shapes.medium).padding(14.dp)) {
        Canvas(Modifier.size(size)) {
            val cell = this.size.width / matrix.width
            for (y in 0 until matrix.height) for (x in 0 until matrix.width)
                if (matrix.get(x, y)) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
        }
    }
}

private fun wifiEsc(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")

private fun startShare(ctx: Context) =
    ContextCompat.startForegroundService(ctx, Intent(ctx, ShareService::class.java))

@Composable
fun ShareScreen(pad: PaddingValues, onPick: () -> Unit) {
    val ctx = LocalContext.current
    val files by ShareHub.files.collectAsState()
    val run by ShareHub.running.collectAsState()
    val hs by ShareHub.hotspot.collectAsState()
    val log by ShareHub.log.collectAsState()
    var ips by remember { mutableStateOf(NetUtil.candidates()) }
    var chosen by remember { mutableStateOf<String?>(null) }
    var hsMsg by remember { mutableStateOf<String?>(null) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { ips = NetUtil.candidates() }
    LaunchedEffect(hs) { delay(1500); ips = NetUtil.candidates() }
    val ip = ips.firstOrNull { it.ip == chosen }?.ip ?: ips.firstOrNull()?.ip
    val url = run?.let { r -> ip?.let { "http://$it:${r.port}/${r.token}/" } }

    fun startHotspot() = Hotspot.start(ctx) { r ->
        r.onSuccess { ShareHub.hotspot.value = it; hsMsg = null }.onFailure { hsMsg = it.message }
    }
    val hsPerms = remember { buildList { add(Manifest.permission.ACCESS_FINE_LOCATION); if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES) }.toTypedArray() }
    val hsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) startHotspot() else hsMsg = "الصلاحية مطلوبة لإنشاء نقطة الاتصال"
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startShare(ctx) }

    LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 24.dp)) {
        // ── 1. الملفات
        item { SectionTitle("١. الملفات المشتركة") }
        item {
            ElevatedCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    if (files.isEmpty()) Text("لم تختر شيئاً بعد. حدّد ملفات أو مجلدات في المتصفح بالضغط المطوّل ثم اضغط زر المشاركة.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    files.forEach { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (File(p).isDirectory) Icons.Rounded.Folder else Icons.Rounded.InsertDriveFile, null,
                                tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(File(p).name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            IconButton({ ShareHub.remove(p) }) { Icon(Icons.Rounded.Close, "إزالة") }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onPick) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("اختيار ملفات") }
                        if (files.isNotEmpty()) TextButton({ ShareHub.clear() }) { Text("مسح الكل") }
                    }
                }
            }
        }

        // ── 2. الشبكة
        item { SectionTitle("٢. الشبكة") }
        item {
            ElevatedCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (ips.isEmpty()) Text("لا توجد شبكة متاحة. اتصل بشبكة Wi-Fi مشتركة مع الجهاز الآخر، أو أنشئ نقطة اتصال وأعطِ الجهاز الآخر بياناتها.",
                        color = MaterialTheme.colorScheme.error)
                    else {
                        Text("عنوان هذا الجهاز", style = MaterialTheme.typography.labelLarge)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ips.forEach { c ->
                                FilterChip(c.ip == ip, { chosen = c.ip }, { Text("${c.ip}  •  ${c.label}") })
                            }
                        }
                    }
                    HorizontalDivider()
                    Text("هل الجهازان ليسا على شبكة واحدة؟", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (hs == null) FilledTonalButton({
                            if (hsPerms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }) startHotspot()
                            else hsLauncher.launch(hsPerms)
                        }) { Icon(Icons.Rounded.WifiTethering, null); Spacer(Modifier.width(6.dp)); Text("إنشاء نقطة اتصال") }
                        else OutlinedButton({ Hotspot.stop() }) { Text("إيقاف نقطة الاتصال") }
                        TextButton({
                            val i = Intent("android.settings.TETHER_SETTINGS")
                            runCatching { ctx.startActivity(i) }.onFailure { ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                        }) { Text("إعدادات النظام") }
                    }
                    hsMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    hs?.let { h ->
                        HorizontalDivider()
                        Text("نقطة الاتصال تعمل (بدون إنترنت)", fontFamily = FontFamily.Default, style = MaterialTheme.typography.titleSmall)
                        Text("على الجهاز الآخر: امسح هذا الرمز للاتصال بالشبكة، ثم امسح رمز الرابط أدناه.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            QrCode("WIFI:T:WPA;S:${wifiEsc(h.ssid)};P:${wifiEsc(h.password)};;", 180.dp)
                            Spacer(Modifier.height(8.dp))
                            Text("${h.ssid}", style = MaterialTheme.typography.titleSmall)
                            Text(h.password, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // ── 3. البدء
        item { SectionTitle("٣. ابدأ المشاركة") }
        item {
            Column(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Button({
                    if (run != null) ctx.stopService(Intent(ctx, ShareService::class.java))
                    else if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else startShare(ctx)
                }, Modifier.fillMaxWidth().height(52.dp), enabled = run != null || (files.isNotEmpty() && ip != null)) {
                    Icon(if (run != null) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (run != null) "إيقاف المشاركة" else "بدء المشاركة")
                }
                if (url != null) ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("امسح الرمز من الجهاز الآخر (الكاميرا)", style = MaterialTheme.typography.titleSmall)
                        QrCode(url, 230.dp)
                        Text(url, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton({
                                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", url))
                                Toast.makeText(ctx, "تم نسخ الرابط", Toast.LENGTH_SHORT).show()
                            }) { Icon(Icons.Rounded.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("نسخ") }
                            OutlinedButton({
                                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url), "مشاركة الرابط"))
                            }) { Icon(Icons.Rounded.Share, null); Spacer(Modifier.width(6.dp)); Text("إرسال") }
                        }
                        Text("يفتح الرابط في أي متصفح على نفس الشبكة. أوقف المشاركة عند الانتهاء.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        // ── 4. السجل
        if (log.isNotEmpty()) {
            item { SectionTitle("النشاط") }
            item {
                Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    log.take(12).forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}
