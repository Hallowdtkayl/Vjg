package app.filehub.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color(0xFF3949D6), onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E3FF), secondary = Color(0xFF00A8A8),
    background = Color(0xFFF7F8FC), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFEDEFF7)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFB9C0FF), onPrimary = Color(0xFF14197A),
    primaryContainer = Color(0xFF2A33B0), secondary = Color(0xFF4DD9D9),
    background = Color(0xFF0F1118), surface = Color(0xFF171A24), surfaceVariant = Color(0xFF232736)
)
private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(28.dp)
)

@Composable
fun FileHubTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = if (dark) Dark else Light, shapes = AppShapes, content = content)
