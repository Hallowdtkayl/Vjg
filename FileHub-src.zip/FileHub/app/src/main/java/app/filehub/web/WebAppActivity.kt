package app.filehub.web

import android.app.ActivityManager
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth

/**
 * نافذة الموقع المثبّت: واجهة كاملة بلا شريط عنوان، تشارك الكوكيز مع المتصفح فيبقى تسجيل الدخول.
 * الروابط خارج نطاق الموقع تُفتح في المتصفح بدل هذه النافذة.
 */
class WebAppActivity : ComponentActivity() {
    private var web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val url = intent.data?.toString() ?: run { finish(); return }
        val scope = intent.getStringExtra("scope") ?: url
        val name = intent.getStringExtra("name") ?: Uri.parse(url).host.orEmpty()
        setTaskDescription(ActivityManager.TaskDescription(name))
        setContent {
            var progress by remember { mutableIntStateOf(0) }
            var canBack by remember { mutableStateOf(false) }
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                AndroidView(factory = { ctx ->
                    WebEngine.create(ctx, false, object : WebCallbacks {
                        override fun onProgress(p: Int) { progress = p }
                        override fun onNav(canBack0: Boolean, canForward: Boolean) { canBack = canBack0 }
                        override fun onNewWindow(u: String) { openExternalOrBrowser(u) }
                    }).also { w ->
                        (w.context as? MutableContextWrapper)?.baseContext = this@WebAppActivity
                        // أي تنقّل خارج النطاق يذهب للمتصفح
                        val inner = w.webViewClient
                        w.webViewClient = object : android.webkit.WebViewClient() {
                            override fun shouldOverrideUrlLoading(v: WebView, r: android.webkit.WebResourceRequest): Boolean {
                                val u = r.url.toString()
                                if (u.startsWith("http") && !u.startsWith(scope.substringBeforeLast('/'))) { openExternalOrBrowser(u); return true }
                                return inner.shouldOverrideUrlLoading(v, r)
                            }
                            override fun onPageFinished(v: WebView, u: String) { inner.onPageFinished(v, u) }
                            override fun doUpdateVisitedHistory(v: WebView, u: String, r: Boolean) { inner.doUpdateVisitedHistory(v, u, r) }
                        }
                        web = w; w.loadUrl(url)
                    }
                }, modifier = Modifier.fillMaxSize())
            }
            BackHandler(canBack) { web?.goBack() }
        }
    }

    private fun openExternalOrBrowser(u: String) {
        startActivity(Intent(this, app.filehub.MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onPause() { WebEngine.flushCookies(); super.onPause() }
    override fun onDestroy() { web?.destroy(); web = null; super.onDestroy() }
}
