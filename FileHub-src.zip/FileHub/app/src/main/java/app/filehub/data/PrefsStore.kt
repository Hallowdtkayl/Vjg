package app.filehub.data

import android.content.Context
import androidx.compose.runtime.*
import app.filehub.model.*

/** يحفظ أسلوب الترتيب والعرض لكل تصنيف على حدة */
class PrefsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("view_prefs", Context.MODE_PRIVATE)

    var showHidden: Boolean
        get() = sp.getBoolean("hidden", false)
        set(v) { sp.edit().putBoolean("hidden", v).apply() }

    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var port: Int
        get() = sp.getInt("port", 8080)
        set(v) { sp.edit().putInt("port", v).apply() }
    var autoStopMin: Int
        get() = sp.getInt("autostop", 30)
        set(v) { sp.edit().putInt("autostop", v).apply() }
    var trashDays: Int
        get() = sp.getInt("trashdays", 30)
        set(v) { sp.edit().putInt("trashdays", v).apply() }

    /** نسخة احتياطية JSON لكل الإعدادات وتفضيلات العرض لكل تصنيف */
    fun exportJson(): String {
        val data = org.json.JSONObject()
        loop@ for ((k, v) in sp.all) {
            val o = org.json.JSONObject()
            when (v) {
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is String -> o.put("t", "s").put("v", v)
                else -> continue@loop
            }
            data.put(k, o)
        }
        return org.json.JSONObject().put("app", "filehub").put("version", 1).put("data", data).toString(2)
    }

    /** يعيد الإعدادات من JSON؛ يتحقق من الصيغة كاملةً قبل مسح أي شيء. يرجع عدد العناصر */
    fun importJson(text: String): Int {
        val root = org.json.JSONObject(text)
        require(root.optString("app") == "filehub") { "ليست نسخة احتياطية من ملفاتي" }
        val data = root.getJSONObject("data")
        val items = data.keys().asSequence().map { k -> val o = data.getJSONObject(k); Triple(k, o.getString("t"), o.get("v")) }.toList()
        val e = sp.edit().clear()
        for ((k, t, v) in items) when (t) {
            "b" -> e.putBoolean(k, v as Boolean)
            "i" -> e.putInt(k, (v as Number).toInt())
            "l" -> e.putLong(k, (v as Number).toLong())
            "f" -> e.putFloat(k, (v as Number).toFloat())
            "s" -> e.putString(k, v as String)
        }
        e.apply()
        return items.size
    }

    /** تخزين خام لبيانات التطبيقات المدمجة (منبهات، مؤقّتات…) — تدخل ضمن النسخ الاحتياطي تلقائياً */
    fun rawGet(k: String): String? = sp.getString(k, null)
    fun rawPut(k: String, v: String) { sp.edit().putString(k, v).apply() }

    // ───── الردود السريعة على المكالمات (سطر لكل رد) ─────
    var quickReplies: String
        get() = sp.getString("quick_replies", "لا أستطيع الرد الآن، سأتصل بك لاحقاً.\nأنا في اجتماع، هل الأمر عاجل؟\nهل يمكنك مراسلتي برسالة؟") ?: ""
        set(v) { sp.edit().putString("quick_replies", v).apply() }

    // ───── الهاتف ─────
    var dndMode: Int                       // 0 إيقاف، 1 غير المعروفة، 2 الكل عدا المفضلة
        get() = sp.getInt("dnd_mode", 0)
        set(v) { sp.edit().putInt("dnd_mode", v).apply() }
    var dndRepeat: Boolean                 // السماح للمتصل المتكرر خلال 3 دقائق
        get() = sp.getBoolean("dnd_repeat", true)
        set(v) { sp.edit().putBoolean("dnd_repeat", v).apply() }
    var autoRecord: Int                    // 0 إيقاف، 1 الكل، 2 غير المعروفة
        get() = sp.getInt("auto_record", 0)
        set(v) { sp.edit().putInt("auto_record", v).apply() }
    var ringtone: String?
        get() = sp.getString("ringtone", null)
        set(v) { sp.edit().putString("ringtone", v).apply() }
    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) { sp.edit().putBoolean("vibrate", v).apply() }

    private fun recent(): List<Pair<String, Long>> = (sp.getString("dnd_recent", "") ?: "").split(';').mapNotNull {
        val p = it.split('|'); if (p.size == 2) p[1].toLongOrNull()?.let { t -> p[0] to t } else null
    }
    fun noteRejected(key: String) {
        val now = System.currentTimeMillis()
        val l = recent().filter { now - it.second < 600_000 && it.first != key } + (key to now)
        sp.edit().putString("dnd_recent", l.joinToString(";") { "${it.first}|${it.second}" }).apply()
    }
    fun rejectedRecently(key: String, windowMs: Long) =
        recent().any { it.first == key && System.currentTimeMillis() - it.second <= windowMs }

    fun load(scope: String, def: ViewPrefs) = runCatching {
        ViewPrefs(
            SortBy.valueOf(sp.getString("$scope.sort", def.sortBy.name)!!),
            sp.getBoolean("$scope.asc", def.ascending),
            DisplayStyle.valueOf(sp.getString("$scope.style", def.style.name)!!),
            BrowseMode.valueOf(sp.getString("$scope.mode", def.mode.name)!!)
        )
    }.getOrDefault(def)

    fun save(scope: String, p: ViewPrefs) = sp.edit()
        .putString("$scope.sort", p.sortBy.name).putBoolean("$scope.asc", p.ascending)
        .putString("$scope.style", p.style.name).putString("$scope.mode", p.mode.name).apply()
}

/** إعدادات عامة (الثيم، الخادم، السلة) */
class SettingsState(private val p: PrefsStore) {
    var theme by mutableIntStateOf(p.themeMode)          // 0 تلقائي، 1 فاتح، 2 داكن
    var port by mutableIntStateOf(p.port)
    var autoStop by mutableIntStateOf(p.autoStopMin)     // بالدقائق، 0 = بلا إيقاف
    var trashDays by mutableIntStateOf(p.trashDays)
    var showHidden by mutableStateOf(p.showHidden)
    fun reload() {
        theme = p.themeMode; port = p.port; autoStop = p.autoStopMin
        trashDays = p.trashDays; showHidden = p.showHidden
    }
    fun save() {
        p.themeMode = theme; p.port = port; p.autoStopMin = autoStop
        p.trashDays = trashDays; p.showHidden = showHidden
    }
}
