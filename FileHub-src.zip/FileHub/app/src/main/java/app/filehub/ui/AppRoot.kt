package app.filehub.ui

import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import app.filehub.ui.screens.*
import app.filehub.ui.phone.*
import app.filehub.ui.sms.*
import app.filehub.ui.contacts.*
import app.filehub.ui.clock.*
import app.filehub.ui.calc.*
import app.filehub.ui.web.*
import app.filehub.ui.viewers.*

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "الرئيسية", Icons.Rounded.Home),
    Share("share", "مشاركة", Icons.Rounded.QrCode2),
    Settings("settings", "الإعدادات", Icons.Rounded.Settings)
}

@Composable
fun AppRoot(deepLink: String?, onDeepLinkConsumed: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAccess(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = hasAccess(ctx) }
    if (!granted) { PermissionScreen(); return }

    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val goTab: (String) -> Unit = { r ->
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true; restoreState = true
        }
    }
    LaunchedEffect(deepLink) { deepLink?.let { runCatching { nav.navigate(it) }; onDeepLinkConsumed() } }
    val addContact: (String) -> Unit = { n -> nav.navigate("contactedit?id=-1&number=${Uri.encode(n)}") }
    val openSms: (String) -> Unit = { n -> nav.navigate("thread?id=-1&address=${Uri.encode(n)}") }
    Scaffold(bottomBar = {
        if (Tab.entries.any { it.route == route }) NavigationBar {
            Tab.entries.forEach { t ->
                NavigationBarItem(route == t.route, {
                    nav.navigate(t.route) {
                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true; restoreState = true
                    }
                }, { Icon(t.icon, t.label) }, label = { Text(t.label) })
            }
        }
    }) { pad ->
        NavHost(nav, "home") {
            composable("home") {
                HomeScreen({ nav.navigate("folder?path=${Uri.encode(it)}") }, { nav.navigate("cat/$it") }, { nav.navigate("phone") }, { nav.navigate("messages") }, { nav.navigate("contacts") }, { nav.navigate("clock") }, { nav.navigate("editor") }, { nav.navigate("calculator") }, { nav.navigate("web") }, { nav.navigate("web/downloads") }, { nav.navigate("web/bookmarks") }, pad)
            }
            composable("phone") {
                PhoneScreen({ nav.popBackStack() }, { n -> nav.navigate("dialer?number=${Uri.encode(n)}") },
                    { n -> nav.navigate("history?number=${Uri.encode(n)}") }, { nav.navigate("phone/settings") },
                    { f -> routeFor(f)?.let { nav.navigate(it) } }, addContact, openSms)
            }
            composable("dialer?number={number}", listOf(navArgument("number") { type = NavType.StringType; defaultValue = "" })) {
                DialerScreen(it.arguments?.getString("number").orEmpty(), { nav.popBackStack() }, { n -> nav.navigate("history?number=${Uri.encode(n)}") }, addContact, openSms)
            }
            composable("history?number={number}", listOf(navArgument("number") { type = NavType.StringType; defaultValue = "" })) {
                HistoryScreen(it.arguments?.getString("number").orEmpty(), { nav.popBackStack() }, addContact, openSms)
            }
            composable("incoming") {
                IncomingViewScreen(
                    { r -> nav.navigate(r) { popUpTo("incoming") { inclusive = true } } },
                    { f -> app.filehub.data.ShareHub.add(listOf(f.path)); nav.navigate("share") { popUpTo("incoming") { inclusive = true } } },
                    { nav.popBackStack() })
            }
            composable("sharein") { ShareInScreen { nav.navigate("share") { popUpTo("sharein") { inclusive = true } } } }
            composable("calculator") { CalculatorScreen { nav.popBackStack() } }
            composable("web?url={url}", listOf(navArgument("url") { type = NavType.StringType; defaultValue = "" })) {
                BrowserScreen(it.arguments?.getString("url").orEmpty(), { nav.popBackStack() }, { r -> nav.navigate(r) })
            }
            composable("web") { BrowserScreen("", { nav.popBackStack() }, { r -> nav.navigate(r) }) }
            composable("web/tabs") { TabsScreen { nav.popBackStack() } }
            composable("web/history") { WebHistoryScreen({ nav.popBackStack() }) { u -> app.filehub.web.TabManager.pendingUrl = u; nav.navigate("web") { popUpTo("web/history") { inclusive = true } } } }
            composable("web/bookmarks") { WebBookmarksScreen({ nav.popBackStack() }) { u -> app.filehub.web.TabManager.pendingUrl = u; nav.navigate("web") { popUpTo("web/bookmarks") { inclusive = true } } } }
            composable("web/downloads") { WebDownloadsScreen { nav.popBackStack() } }
            composable("web/settings") { WebSettingsScreen { nav.popBackStack() } }
            composable("clock") { ClockScreen { nav.popBackStack() } }
            composable("editor") {
                EditorHubScreen({ nav.popBackStack() }, { p -> routeFor(p)?.let { nav.navigate(it) } }, { nav.navigate("cat/docs") })
            }
            composable("contacts") {
                ContactsScreen({ nav.popBackStack() }, { cid -> nav.navigate("contact?id=$cid") }, { nav.navigate("contactedit?id=-1") })
            }
            composable("contact?id={id}", listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L })) {
                val cid = it.arguments?.getLong("id") ?: -1L
                ContactDetailScreen(cid, { nav.popBackStack() }, { nav.navigate("contactedit?id=$cid") }, openSms, { n -> nav.navigate("history?number=${Uri.encode(n)}") })
            }
            composable("contactedit?id={id}&number={number}&name={name}&email={email}", listOf(
                navArgument("id") { type = NavType.LongType; defaultValue = -1L },
                navArgument("number") { type = NavType.StringType; defaultValue = "" },
                navArgument("name") { type = NavType.StringType; defaultValue = "" },
                navArgument("email") { type = NavType.StringType; defaultValue = "" })) {
                val cid = it.arguments?.getLong("id") ?: -1L
                ContactEditScreen(cid, it.arguments?.getString("number").orEmpty(), it.arguments?.getString("name").orEmpty(), it.arguments?.getString("email").orEmpty(), { nav.popBackStack() }) { saved ->
                    nav.popBackStack()
                    if (cid < 0 && saved >= 0) nav.navigate("contact?id=$saved")
                }
            }
            composable("messages") {
                MessagesScreen({ nav.popBackStack() }, { id, addr -> nav.navigate("thread?id=$id&address=${Uri.encode(addr)}") }, { nav.navigate("thread?id=-1") })
            }
            composable("thread?id={id}&address={address}&body={body}", listOf(
                navArgument("id") { type = NavType.LongType; defaultValue = -1L },
                navArgument("address") { type = NavType.StringType; defaultValue = "" },
                navArgument("body") { type = NavType.StringType; defaultValue = "" })) {
                ThreadScreen(it.arguments?.getLong("id") ?: -1L, it.arguments?.getString("address").orEmpty(), it.arguments?.getString("body").orEmpty(),
                    { nav.popBackStack() }, { n -> nav.navigate("history?number=${Uri.encode(n)}") }, { b -> nav.navigate("thread?id=-1&body=${Uri.encode(b)}") })
            }
            composable("phone/settings") { PhoneSettingsScreen { nav.popBackStack() } }
            composable("share") { ShareScreen(pad) { goTab("home") } }
            composable("settings") { SettingsScreen(pad) }
            composable("cat/{id}") {
                BrowserScreen(it.arguments?.getString("id"), null, { nav.popBackStack() }, { r -> nav.navigate(r) }, { goTab("share") })
            }
            composable("folder?path={path}", listOf(navArgument("path") { type = NavType.StringType })) {
                BrowserScreen(null, it.arguments?.getString("path"), { nav.popBackStack() }, { r -> nav.navigate(r) }, { goTab("share") })
            }
            composable("view/{kind}?path={path}", listOf(navArgument("path") { type = NavType.StringType })) { e ->
                val p = e.arguments?.getString("path").orEmpty()
                val back = { nav.popBackStack(); Unit }
                when (e.arguments?.getString("kind")) {
                    "image" -> ImageViewer(p, back)
                    "media" -> MediaViewer(p, back)
                    "pdf" -> PdfViewer(p, back)
                    else -> TextFileViewer(p, back)
                }
            }
            composable("archive?path={path}", listOf(navArgument("path") { type = NavType.StringType })) {
                ArchiveScreen(it.arguments?.getString("path").orEmpty(), { nav.popBackStack() }, { r -> nav.navigate(r) },
                    { dir -> nav.navigate("folder?path=${Uri.encode(dir)}") })
            }
        }
    }
}
