package app.filehub.phone

import android.annotation.SuppressLint
import android.app.role.RoleManager
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.BlockedNumberContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone as P
import android.provider.CallLog.Calls as C
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import app.filehub.data.PrefsStore

data class ContactInfo(val id: Long, val name: String, val photo: String?, val starred: Boolean)
data class ContactHit(val id: Long, val name: String, val number: String, val photo: String?)
data class LogEntry(val id: Long, val number: String, val name: String?, val type: Int, val date: Long,
                    val duration: Long, val photo: String?, val simId: String?)

object ContactsLookup {
    fun lookup(ctx: Context, number: String?): ContactInfo? {
        if (number.isNullOrBlank()) return null
        return runCatching {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID, ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI, ContactsContract.PhoneLookup.STARRED), null, null, null)?.use { c ->
                if (c.moveToFirst()) ContactInfo(c.getLong(0), c.getString(1) ?: number, c.getString(2), c.getInt(3) == 1) else null
            }
        }.getOrNull()
    }

    /** بحث بالاسم أو الرقم */
    fun search(ctx: Context, q: String, limit: Int = 10): List<ContactHit> {
        if (q.isBlank()) return emptyList()
        return runCatching {
            ctx.contentResolver.query(Uri.withAppendedPath(P.CONTENT_FILTER_URI, Uri.encode(q)),
                arrayOf(P.CONTACT_ID, P.DISPLAY_NAME, P.NUMBER, P.PHOTO_THUMBNAIL_URI), null, null, "${P.DISPLAY_NAME} COLLATE LOCALIZED ASC")?.use { c ->
                val out = ArrayList<ContactHit>()
                val seen = HashSet<String>()
                while (c.moveToNext() && out.size < limit) {
                    val n = c.getString(2) ?: continue
                    if (seen.add(n.filter { it.isDigit() }.takeLast(9))) out.add(ContactHit(c.getLong(0), c.getString(1) ?: n, n, c.getString(3)))
                }
                out
            } ?: emptyList()
        }.getOrDefault(emptyList())
    }
}

object CallLogRepo {
    fun load(ctx: Context, limit: Int = 800): List<LogEntry> {
        val args = Bundle().apply {
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(C.DATE))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
        }
        val cache = HashMap<String, ContactInfo?>()
        val out = ArrayList<LogEntry>()
        ctx.contentResolver.query(C.CONTENT_URI, arrayOf(C._ID, C.NUMBER, C.TYPE, C.DATE, C.DURATION, C.CACHED_NAME, C.CACHED_PHOTO_URI, C.PHONE_ACCOUNT_ID), args, null)?.use { c ->
            while (c.moveToNext()) {
                val number = c.getString(1).orEmpty()
                val info = if (number.isEmpty()) null else cache.getOrPut(number) { ContactsLookup.lookup(ctx, number) }
                out.add(LogEntry(c.getLong(0), number, info?.name ?: c.getString(5)?.takeIf { it.isNotBlank() },
                    c.getInt(2), c.getLong(3), c.getLong(4), info?.photo ?: c.getString(6), c.getString(7)))
            }
        }
        return out
    }

    fun delete(ctx: Context, ids: List<Long>) {
        if (ids.isEmpty()) return
        ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "_id IN (${ids.joinToString(",")})", null)
    }
    fun clearAll(ctx: Context) { ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null) }

    fun markRead(ctx: Context) {
        runCatching {
            ctx.contentResolver.update(CallLog.Calls.CONTENT_URI,
                ContentValues().apply { put(CallLog.Calls.IS_READ, 1); put(CallLog.Calls.NEW, 0) },
                "${CallLog.Calls.TYPE}=${CallLog.Calls.MISSED_TYPE} AND ${CallLog.Calls.IS_READ}=0", null)
        }
    }

    fun missedUnread(ctx: Context): Int = runCatching {
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls._ID),
            "${CallLog.Calls.TYPE}=${CallLog.Calls.MISSED_TYPE} AND ${CallLog.Calls.IS_READ}=0", null, null)?.use { it.count } ?: 0
    }.getOrDefault(0)
}

@SuppressLint("MissingPermission")
object DialerUtil {
    fun isDefault(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 29) ctx.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
        else ctx.getSystemService(TelecomManager::class.java).defaultDialerPackage == ctx.packageName

    fun requestIntent(ctx: Context): Intent =
        if (Build.VERSION.SDK_INT >= 29) ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_DIALER)
        else Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, ctx.packageName)

    fun accounts(ctx: Context): List<Pair<PhoneAccountHandle, String>> = runCatching {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.callCapablePhoneAccounts.map { it to (tm.getPhoneAccount(it)?.label?.toString() ?: "SIM") }
    }.getOrDefault(emptyList())

    fun call(ctx: Context, number: String, account: PhoneAccountHandle? = null): Boolean = runCatching {
        val extras = Bundle().apply { account?.let { putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) } }
        ctx.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", number, null), extras)
        true
    }.getOrDefault(false)
}

/** قائمة الحظر المشتركة مع النظام (تعمل فقط للتطبيق الافتراضي للهاتف/الرسائل) */
object Blocklist {
    fun canBlock(ctx: Context) = runCatching { BlockedNumberContract.canCurrentUserBlockNumbers(ctx) }.getOrDefault(false)
    fun isBlocked(ctx: Context, n: String) = runCatching { BlockedNumberContract.isBlocked(ctx, n) }.getOrDefault(false)
    fun block(ctx: Context, n: String) = runCatching {
        ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
            ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n) }) != null
    }.getOrDefault(false)
    fun unblock(ctx: Context, n: String) = runCatching { BlockedNumberContract.unblock(ctx, n) }
    fun list(ctx: Context): List<String> = runCatching {
        ctx.contentResolver.query(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
            arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null)?.use { c ->
            generateSequence { if (c.moveToNext()) c.getString(0) else null }.toList()
        } ?: emptyList()
    }.getOrDefault(emptyList())
}

/** قواعد «عدم الإزعاج»: فصل صامت فور الاستقبال دون إشعار */
object PhoneRules {
    fun shouldReject(ctx: Context, prefs: PrefsStore, number: String?): Boolean {
        val mode = prefs.dndMode
        if (mode == 0) return false
        val key = number?.filter { it.isDigit() }?.takeLast(9)?.takeIf { it.isNotEmpty() }
        if (prefs.dndRepeat && key != null && prefs.rejectedRecently(key, 180_000)) return false   // اتصال متكرر = ربما طارئ
        val c = ContactsLookup.lookup(ctx, number)
        val reject = when (mode) { 1 -> c == null; 2 -> c == null || !c.starred; else -> false }
        if (reject && key != null) prefs.noteRejected(key)
        return reject
    }
}
