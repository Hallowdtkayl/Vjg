package app.filehub.ui.web

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.content.MutableContextWrapper
import app.filehub.web.*

private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

// ───────────────────────── المتصفح ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(initialUrl: String, onBack: () -> Unit, onNav: (String) -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(initialUrl) {
        if (TabManager.tabs.isEmpty()) TabManager.newTab(ctx, initialUrl.ifBlank { null })
        else if (initialUrl.isNotBlank()) TabManager.active?.webView?.loadUrl(initialUrl)
    }
    LaunchedEffect(TabManager.pendingUrl) {
        TabManager.pendingUrl?.let { u -> TabManager.active?.webView?.loadUrl(u) ?: TabManager.newTab(ctx, u); TabManager.pendingUrl = null }
    }
    val tab = TabManager.active
    if (tab == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }; return }
    val wv = TabManager.webViewFor(ctx, tab)
    var editing by remember(tab.id) { mutableStateOf(false) }
    var text by remember(tab.id) { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val bookmarked by produceState(false, tab.url) { value = runCatching { WebDb.get(ctx).isBookmarked(tab.url) }.getOrDefault(false) }
    val isBlank = tab.url.isBlank() || tab.url == "about:blank"

    BackHandler(enabled = tab.canBack) { wv.goBack() }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        // ── شريط العنوان
        Row(Modifier.fillMaxWidth().padding(8.dp, 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "خروج") }
            TextField(
                value = if (editing) text else tab.url.removePrefix("https://").removePrefix("http://").trimEnd('/').ifBlank { "" },
                onValueChange = { text = it }, singleLine = true, modifier = Modifier.weight(1f),
                placeholder = { Text("ابحث أو اكتب عنواناً") }, shape = RoundedCornerShape(24.dp),
                leadingIcon = { Icon(if (tab.url.startsWith("https")) Icons.Rounded.Lock else Icons.Rounded.Language, null, Modifier.size(18.dp)) },
                trailingIcon = { IconButton({ if (tab.progress in 1..99) wv.stopLoading() else wv.reload() }) { Icon(if (tab.progress in 1..99) Icons.Rounded.Close else Icons.Rounded.Refresh, "تحديث") } },
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { wv.loadUrl(WebEngine.resolveInput(text)); editing = false })
            )
        }
        if (tab.progress in 1..99) LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())

        // ── المحتوى
        Box(Modifier.weight(1f).fillMaxWidth()) {
            key(tab.id) {
                AndroidView(factory = { c ->
                    (wv.context as? MutableContextWrapper)?.baseContext = c      // نشاط حقيقي لنوافذ الحوار لاحقاً
                    (wv.parent as? android.view.ViewGroup)?.removeView(wv); wv
                }, modifier = Modifier.fillMaxSize())
            }
            if (isBlank) StartPage(onOpen = { wv.loadUrl(it) })
            tab.error?.let { e -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.CloudOff, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.error); Text("تعذّر فتح الصفحة"); Text(e, style = MaterialTheme.typography.bodySmall)
                Button({ wv.reload() }) { Text("إعادة المحاولة") } } }
        }

        // ── الشريط السفلي: رجوع / تقدّم / رئيسية / تبويبات / قائمة
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ wv.goBack() }, enabled = tab.canBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "للخلف") }
            IconButton({ wv.goForward() }, enabled = tab.canForward) { Icon(Icons.AutoMirrored.Rounded.ArrowForward, "للأمام (تراجع عن الرجوع)") }
            IconButton({ wv.loadUrl("about:blank") }) { Icon(Icons.Rounded.Home, "الرئيسية") }
            IconButton({ onNav("web/tabs") }) { BadgedBox({ Badge { Text(TabManager.tabs.size.toString()) } }) { Icon(Icons.Rounded.Tab, "التبويبات") } }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "القائمة") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("تبويب جديد") }, { menu = false; TabManager.newTab(ctx) }, leadingIcon = { Icon(Icons.Rounded.Add, null) })
                    DropdownMenuItem({ Text("تبويب بلا سجل") }, { menu = false; TabManager.newTab(ctx, noHistory = true) }, leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null) })
                    DropdownMenuItem({ Text(if (bookmarked) "إزالة العلامة" else "إضافة علامة") }, { menu = false; WebDb.get(ctx).toggleBookmark(tab.url, tab.title) },
                        leadingIcon = { Icon(if (bookmarked) Icons.Rounded.Star else Icons.Rounded.StarBorder, null) }, enabled = !isBlank)
                    DropdownMenuItem({ Text("العلامات") }, { menu = false; onNav("web/bookmarks") }, leadingIcon = { Icon(Icons.Rounded.Bookmarks, null) })
                    DropdownMenuItem({ Text("السجل") }, { menu = false; onNav("web/history") }, leadingIcon = { Icon(Icons.Rounded.History, null) })
                    DropdownMenuItem({ Text("التنزيلات") }, { menu = false; onNav("web/downloads") }, leadingIcon = { Icon(Icons.Rounded.Download, null) })
                    DropdownMenuItem({ Text("تثبيت الموقع كتطبيق") }, { menu = false; toast(ctx, "يُفعَّل في المرحلة 2") }, leadingIcon = { Icon(Icons.Rounded.InstallMobile, null) }, enabled = !isBlank)
                    DropdownMenuItem({ Text(if (tab.desktop) "نسخة الجوال" else "نسخة سطح المكتب") }, { menu = false; tab.desktop = !tab.desktop; WebEngine.setDesktop(wv, tab.desktop) },
                        leadingIcon = { Icon(Icons.Rounded.DesktopWindows, null) })
                    DropdownMenuItem({ Text("مشاركة الرابط") }, { menu = false
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, tab.url), "مشاركة")) },
                        leadingIcon = { Icon(Icons.Rounded.Share, null) }, enabled = !isBlank)
                    DropdownMenuItem({ Text("الإعدادات") }, { menu = false; onNav("web/settings") }, leadingIcon = { Icon(Icons.Rounded.Settings, null) })
                }
            }
        }
    }

    // طلب تنزيل: في المرحلة 2 تظهر نافذة كاملة (الاسم، المجلد، عدد القطع)
    TabManager.pendingDownload?.let { req ->
        AlertDialog({ TabManager.pendingDownload = null }, title = { Text("تنزيل ملف") },
            text = { Text(DownloadEngine.guessFileName(req.url, req.contentDisposition, req.mime) + "\n" + req.url, maxLines = 4, overflow = TextOverflow.Ellipsis) },
            confirmButton = { TextButton({ TabManager.pendingDownload = null; toast(ctx, "مدير التنزيلات يُكتمل في المرحلة 2") }) { Text("تنزيل") } },
            dismissButton = { TextButton({ TabManager.pendingDownload = null }) { Text("إلغاء") } })
    }
}

@Composable
private fun StartPage(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val marks = remember { runCatching { WebDb.get(ctx).bookmarks().take(8) }.getOrDefault(emptyList()) }
    val quick = listOf("Google" to "https://www.google.com", "YouTube" to "https://www.youtube.com", "ويكيبيديا" to "https://ar.wikipedia.org", "GitHub" to "https://github.com")
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(48.dp))
        Icon(Icons.Rounded.Public, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Text("متصفح ملفاتي", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(GridCells.Fixed(4), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(quick + marks.map { it.title.ifBlank { it.url } to it.url }) { (name, url) ->
                Column(Modifier.clickable { onOpen(url) }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    app.filehub.ui.phone.Avatar(name, null, 52)
                    Text(name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}


// ───────────────────────── التبويبات ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text("التبويبات (${TabManager.tabs.size})") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
        actions = { IconButton({ TabManager.newTab(ctx); onBack() }) { Icon(Icons.Rounded.Add, "تبويب جديد") } }) }) { pad ->
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(TabManager.tabs.toList(), key = { it.id }) { t ->
                val selected = TabManager.active?.id == t.id
                Card(Modifier.clickable { TabManager.select(TabManager.tabs.indexOf(t)); onBack() }, border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                            IconButton({ TabManager.close(TabManager.tabs.indexOf(t)); if (TabManager.tabs.isEmpty()) { TabManager.newTab(ctx); onBack() } }, Modifier.size(28.dp)) { Icon(Icons.Rounded.Close, "إغلاق") }
                        }
                        Text(t.url.removePrefix("https://").ifBlank { "صفحة فارغة" }, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (t.noHistory) Text("بلا سجل", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        // TODO(phase-2): صورة مصغّرة حيّة للصفحة
                    }
                }
            }
        }
    }
}

// ───────────────────────── السجل ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebHistoryScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    val items by produceState(emptyList<HistoryEntry>(), q, tick) { value = WebDb.get(ctx).history(q) }
    Scaffold(topBar = { TopAppBar(title = { Text("السجل") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
        actions = { IconButton({ WebDb.get(ctx).clearHistory(); tick++ }) { Icon(Icons.Rounded.DeleteSweep, "مسح الكل") } }) }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(12.dp), singleLine = true, placeholder = { Text("بحث في السجل") }, leadingIcon = { Icon(Icons.Rounded.Search, null) })
            LazyColumn {
                items(items, key = { it.id }) { h ->
                    ListItem({ Text(h.title.ifBlank { h.url }, maxLines = 1, overflow = TextOverflow.Ellipsis) }, supportingContent = { Text(h.url, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        leadingContent = { Icon(Icons.Rounded.History, null) },
                        trailingContent = { IconButton({ WebDb.get(ctx).deleteHistory(h.id); tick++ }) { Icon(Icons.Rounded.Close, "حذف") } },
                        modifier = Modifier.clickable { onOpen(h.url) })
                }
            }
        }
    }
}

// ───────────────────────── العلامات ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebBookmarksScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val items by produceState(emptyList<Bookmark>(), tick) { value = WebDb.get(ctx).bookmarks() }
    Scaffold(topBar = { TopAppBar(title = { Text("العلامات") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            if (items.isEmpty()) item { Text("لا توجد علامات بعد", Modifier.padding(32.dp)) }
            items(items, key = { it.id }) { b ->
                ListItem({ Text(b.title.ifBlank { b.url }, maxLines = 1, overflow = TextOverflow.Ellipsis) }, supportingContent = { Text(b.url, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    leadingContent = { Icon(Icons.Rounded.Star, null, tint = Color(0xFFFFB300)) },
                    trailingContent = { IconButton({ WebDb.get(ctx).toggleBookmark(b.url, b.title); tick++ }) { Icon(Icons.Rounded.Close, "إزالة") } },
                    modifier = Modifier.clickable { onOpen(b.url) })
            }
        }
    }
}

// ───────────────────────── التنزيلات (هيكل) ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebDownloadsScreen(onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("التنزيلات") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Download, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Text("مدير التنزيلات", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 12.dp))
            Text("تنزيل مجزّأ بقطع قابلة للزيادة، استئناف، وتحديث الرابط المنتهي تلقائياً أو يدوياً — يُبنى في المرحلة 2.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

// ───────────────────────── إعدادات المتصفح (هيكل) ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text("إعدادات المتصفح") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad)) {
            item { ListItem({ Text("مسح ملفات الكوكيز") }, supportingContent = { Text("يسجّل خروجك من المواقع") }, leadingContent = { Icon(Icons.Rounded.Cookie, null) },
                modifier = Modifier.clickable { android.webkit.CookieManager.getInstance().removeAllCookies { toast(ctx, "تم مسح الكوكيز") } }) }
            item { ListItem({ Text("مسح ذاكرة التخزين المؤقت") }, leadingContent = { Icon(Icons.Rounded.CleaningServices, null) },
                modifier = Modifier.clickable { TabManager.tabs.forEach { it.webView?.clearCache(true) }; toast(ctx, "تم المسح") }) }
            item { ListItem({ Text("محرّك البحث، عدد القطع الافتراضي، المجلدات، حجب الإعلانات…") }, supportingContent = { Text("تُضاف في المرحلة 2") }, leadingContent = { Icon(Icons.Rounded.Tune, null) }) }
        }
    }
}
