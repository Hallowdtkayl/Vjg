package app.filehub.ui.screens

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.filehub.data.ArchiveEntry
import app.filehub.data.Archives
import app.filehub.model.*
import app.filehub.ui.components.FileRow
import app.filehub.ui.viewers.routeFor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ArchiveState(
    val loading: Boolean = true, val all: List<ArchiveEntry> = emptyList(), val prefix: String = "",
    val selection: Set<String> = emptySet(), val askPassword: Boolean = false, val wrongPassword: Boolean = false,
    val error: String? = null, val message: String? = null, val doneFolder: String? = null, val openPath: String? = null
)

/** عناصر المستوى الحالي داخل الأرشيف (مع تركيب المجلدات الضمنية) */
fun childrenOf(all: List<ArchiveEntry>, prefix: String): List<ArchiveEntry> {
    val map = linkedMapOf<String, ArchiveEntry>()
    for (e in all) {
        if (!e.path.startsWith(prefix)) continue
        val rest = e.path.removePrefix(prefix)
        if (rest.isEmpty()) continue
        val seg = rest.substringBefore('/')
        if ('/' in rest || e.isDir) map[seg] = ArchiveEntry(prefix + seg, seg, true, 0, e.modified)
        else map[seg] = e
    }
    return map.values.toList()
}

class ArchiveViewModel(app: Application, val path: String) : AndroidViewModel(app) {
    val file = File(path)
    private var password: String? = null
    private val previewRoot = File(app.cacheDir, "archive_preview")
    var state by mutableStateOf(ArchiveState()); private set
    var progress by mutableStateOf<Float?>(null); private set

    init { previewRoot.deleteRecursively(); open() }
    override fun onCleared() { previewRoot.deleteRecursively() }

    private fun friendly(e: Throwable) =
        if (e.javaClass.simpleName.contains("V5")) "صيغة RAR5 غير مدعومة حالياً. جرّب zip أو 7z أو تطبيقاً آخر."
        else "تعذّرت العملية: ${e.message ?: e.javaClass.simpleName}"

    fun open() {
        viewModelScope.launch {
            state = state.copy(loading = true, askPassword = false, error = null)
            try {
                val l = withContext(Dispatchers.IO) { Archives.list(file, password) }
                state = state.copy(loading = false, all = l)
            } catch (e: Archives.NeedPassword) {
                state = state.copy(loading = false, askPassword = true, wrongPassword = e.wrong)
            } catch (e: Throwable) { state = state.copy(loading = false, error = friendly(e)) }
        }
    }

    fun submitPassword(pw: String) { password = pw; open() }
    fun enter(dir: String) { state = state.copy(prefix = "$dir/", selection = emptySet()) }
    fun up(): Boolean {
        if (state.prefix.isEmpty()) return false
        val p = state.prefix.trimEnd('/').substringBeforeLast('/', "")
        state = state.copy(prefix = if (p.isEmpty()) "" else "$p/", selection = emptySet()); return true
    }
    fun toggle(p: String) { val s = state.selection; state = state.copy(selection = if (p in s) s - p else s + p) }
    fun clearSelection() { state = state.copy(selection = emptySet()) }
    fun post(m: String) { state = state.copy(message = m, doneFolder = null) }
    fun messageShown() { state = state.copy(message = null, doneFolder = null) }
    fun previewHandled() { state = state.copy(openPath = null) }

    private fun uniqueDir(base: File): File {
        if (!base.exists()) return base
        var i = 1
        while (File(base.parentFile, "${base.name} ($i)").exists()) i++
        return File(base.parentFile, "${base.name} ($i)")
    }

    fun extract(selectedOnly: Boolean) {
        val sel = if (selectedOnly) state.selection else null
        viewModelScope.launch {
            progress = 0f
            val inCache = file.absolutePath.startsWith(getApplication<Application>().cacheDir.absolutePath)
            val base = if (inCache) android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS) else file.parentFile
            val dest = uniqueDir(File(base, file.nameWithoutExtension))
            try {
                withContext(Dispatchers.IO) {
                    dest.mkdirs()
                    Archives.extract(file, dest, sel, password) { d, t -> progress = d.toFloat() / maxOf(t, 1) }
                }
                state = state.copy(selection = emptySet(), message = "تم فك الضغط إلى «${dest.name}»", doneFolder = dest.absolutePath)
            } catch (e: Archives.NeedPassword) {
                dest.deleteRecursively()
                state = state.copy(askPassword = true, wrongPassword = e.wrong)
            } catch (e: Throwable) { state = state.copy(message = friendly(e), doneFolder = null) }
            progress = null
        }
    }

    fun preview(e: ArchiveEntry) {
        viewModelScope.launch {
            progress = 0f
            val dir = File(previewRoot, System.currentTimeMillis().toString())
            try {
                withContext(Dispatchers.IO) { dir.mkdirs(); Archives.extract(file, dir, setOf(e.path), password) { _, _ -> } }
                state = state.copy(openPath = File(dir, e.path).absolutePath)
            } catch (x: Archives.NeedPassword) {
                state = state.copy(askPassword = true, wrongPassword = x.wrong)
            } catch (x: Throwable) { state = state.copy(message = friendly(x)) }
            progress = null
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchiveScreen(path: String, onBack: () -> Unit, onRoute: (String) -> Unit, onOpenFolder: (String) -> Unit) {
    val ctx = LocalContext.current
    val vm: ArchiveViewModel = viewModel(key = path, factory = viewModelFactory {
        initializer { ArchiveViewModel(this[APPLICATION_KEY] as Application, path) }
    })
    val s = vm.state
    val snack = remember { SnackbarHostState() }
    val items = remember(s.all, s.prefix) {
        val l = childrenOf(s.all, s.prefix).map {
            FileItem(it.name, it.path, it.isDir, it.size, it.modified, File(it.name).extension.lowercase())
        }
        sortAndFilter(l, ViewPrefs(SortBy.Name, true, DisplayStyle.List, BrowseMode.Folders), "")
    }
    val selecting = s.selection.isNotEmpty()

    BackHandler(enabled = selecting || s.prefix.isNotEmpty()) { if (selecting) vm.clearSelection() else vm.up() }
    LaunchedEffect(s.message) {
        s.message?.let { msg ->
            val folder = s.doneFolder
            val r = snack.showSnackbar(msg, actionLabel = if (folder != null) "عرض" else null)
            if (r == SnackbarResult.ActionPerformed && folder != null) onOpenFolder(folder)
            vm.messageShown()
        }
    }
    LaunchedEffect(s.openPath) {
        s.openPath?.let { p -> routeFor(p)?.let(onRoute) ?: openExternal(ctx, p) { vm.post(it) }; vm.previewHandled() }
    }

    Scaffold(snackbarHost = { SnackbarHost(snack) }, topBar = {
        TopAppBar(
            title = { Column {
                Text(if (selecting) "${s.selection.size} محدد" else vm.file.name, maxLines = 1)
                if (!selecting && s.prefix.isNotEmpty()) Text("/" + s.prefix.trimEnd('/'), style = MaterialTheme.typography.labelSmall, maxLines = 1)
            } },
            navigationIcon = {
                if (selecting) IconButton(vm::clearSelection) { Icon(Icons.Rounded.Close, "إلغاء") }
                else IconButton({ if (!vm.up()) onBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") }
            },
            actions = {
                IconButton({ vm.extract(selecting) }, enabled = vm.progress == null && s.all.isNotEmpty()) {
                    Icon(Icons.Rounded.Unarchive, if (selecting) "فك المحدد" else "فك الكل")
                }
            })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            vm.progress?.let { LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth()) }
            when {
                s.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                s.error != null -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                    Text(s.error, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button({ openExternal(ctx, path) { vm.post(it) } }) { Text("فتح بتطبيق آخر") }
                }
                items.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("الأرشيف فارغ") }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(items, key = { it.path }) { f ->
                        FileRow(f, f.path in s.selection, false, {
                            when {
                                selecting -> vm.toggle(f.path)
                                f.isDir -> vm.enter(f.path)
                                else -> vm.preview(ArchiveEntry(f.path, f.name, false, f.size, f.modified))
                            }
                        }, { vm.toggle(f.path) })
                    }
                }
            }
        }
    }

    if (s.askPassword) {
        var pw by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = onBack, title = { Text("الأرشيف محمي بكلمة مرور") },
            text = { Column {
                if (s.wrongPassword) Text("كلمة المرور غير صحيحة", color = MaterialTheme.colorScheme.error)
                OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            } },
            confirmButton = { TextButton({ if (pw.isNotEmpty()) vm.submitPassword(pw) }) { Text("فتح") } },
            dismissButton = { TextButton(onBack) { Text("إلغاء") } })
    }
}
