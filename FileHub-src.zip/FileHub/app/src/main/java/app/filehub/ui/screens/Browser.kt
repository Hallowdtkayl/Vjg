package app.filehub.ui.screens

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.filehub.data.ShareHub
import app.filehub.model.*
import app.filehub.ui.components.*
import app.filehub.ui.viewers.routeFor
import app.filehub.ui.LocalPicker
import java.io.File

private enum class Dlg { Delete, Forever, EmptyTrash, Rename, NewFolder, NewFile }

fun openExternal(ctx: Context, path: String, onError: (String) -> Unit) {
    val f = File(path)
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(Intent.createChooser(i, f.name)) }
    catch (e: ActivityNotFoundException) {
        onError(if (f.extension.lowercase() in app.filehub.ui.viewers.OFFICE_EXTS)
            "لا يوجد تطبيق Office. ثبّت WPS Office أو OnlyOffice أو Google Docs لفتح هذا الملف"
        else "لا يوجد تطبيق يفتح هذا النوع")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(catId: String?, path: String?, onExit: () -> Unit, onRoute: (String) -> Unit, onShare: () -> Unit) {
    val ctx = LocalContext.current
    val vm: BrowserViewModel = viewModel(key = "$catId|$path", factory = viewModelFactory {
        initializer { BrowserViewModel(this[APPLICATION_KEY] as Application, catId, path) }
    })
    val s = vm.state
    val cat = vm.category
    val snack = remember { SnackbarHostState() }
    var searching by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    val selecting = s.selection.isNotEmpty()
    val pick = LocalPicker.current
    val shown = remember(s.items, s.prefs, s.query, pick) {
        sortAndFilter(s.items, s.prefs, s.query).filter { pick == null || it.isDir || matchesMime(it.ext, pick.mimes) }
    }

    LaunchedEffect(s.message) { s.message?.let { snack.showSnackbar(it); vm.messageShown() } }
    BackHandler(enabled = vm.canHandleBack()) { vm.handleBack() }
    BackHandler(enabled = searching) { searching = false; vm.setQuery("") }

    val click = { f: FileItem ->
        when {
            selecting -> vm.toggle(f.path)
            f.isDir -> vm.openDir(f)
            pick != null -> pick.deliver(listOf(f.path))
            cat == Category.Trash -> vm.post("استعد الملف من السلة أولاً لفتحه")
            else -> routeFor(f.path)?.let(onRoute) ?: openExternal(ctx, f.path) { vm.post(it) }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            if (selecting) TopAppBar(
                title = { Text("${s.selection.size} محدد") },
                navigationIcon = { IconButton(vm::clearSelection) { Icon(Icons.Rounded.Close, "إلغاء") } },
                actions = {
                    if (pick != null) IconButton({ pick.deliver(shown.filter { it.path in s.selection && !it.isDir }.map { it.path }) }) { Icon(Icons.Rounded.Check, "إرجاع المحدد") }
                    IconButton({ vm.selectAll(shown.map { it.path }) }) { Icon(Icons.Rounded.SelectAll, "تحديد الكل") }
                    if (cat == Category.Trash) {
                        IconButton(vm::restoreSelected) { Icon(Icons.Rounded.RestoreFromTrash, "استعادة") }
                        IconButton({ dialog = Dlg.Forever }) { Icon(Icons.Rounded.DeleteForever, "حذف نهائي") }
                    } else {
                        IconButton({ ShareHub.add(s.selection.toList()); vm.clearSelection(); onShare() }) { Icon(Icons.Rounded.Share, "مشاركة") }
                        IconButton(vm::copy) { Icon(Icons.Rounded.ContentCopy, "نسخ") }
                        IconButton(vm::cut) { Icon(Icons.Rounded.ContentCut, "قص") }
                        if (s.selection.size == 1) IconButton({ dialog = Dlg.Rename }) { Icon(Icons.Rounded.DriveFileRenameOutline, "إعادة تسمية") }
                        IconButton({ dialog = Dlg.Delete }) { Icon(Icons.Rounded.Delete, "حذف") }
                    }
                })
            else TopAppBar(
                title = {
                    if (searching) TextField(
                        s.query, vm::setQuery, singleLine = true, placeholder = { Text("بحث بالاسم…") },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                    else Column {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        s.subtitle?.let { Text(it, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                },
                navigationIcon = {
                    IconButton({
                        if (searching) { searching = false; vm.setQuery("") } else if (!vm.handleBack()) onExit()
                    }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") }
                },
                actions = {
                    if (!searching) IconButton({ searching = true }) { Icon(Icons.Rounded.Search, "بحث") }
                    if (cat != null && cat.allowsFolders) IconButton({
                        vm.setPrefs(s.prefs.copy(mode = if (s.prefs.mode == BrowseMode.Flat) BrowseMode.Folders else BrowseMode.Flat))
                    }) { Icon(if (s.prefs.mode == BrowseMode.Flat) Icons.Rounded.FolderOpen else Icons.Rounded.Dashboard, "أسلوب العرض") }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Rounded.Tune, "خيارات") }
                        DropdownMenu(menu, { menu = false }) {
                            SortBy.entries.forEach { o ->
                                DropdownMenuItem({ Text(o.label) }, { vm.setPrefs(s.prefs.copy(sortBy = o)); menu = false },
                                    trailingIcon = { if (s.prefs.sortBy == o) Icon(Icons.Rounded.Check, null) })
                            }
                            DropdownMenuItem({ Text(if (s.prefs.ascending) "تصاعدي ↑" else "تنازلي ↓") },
                                { vm.setPrefs(s.prefs.copy(ascending = !s.prefs.ascending)) })
                            HorizontalDivider()
                            DisplayStyle.entries.forEach { d ->
                                DropdownMenuItem({ Text(d.label) }, { vm.setPrefs(s.prefs.copy(style = d)); menu = false },
                                    trailingIcon = { if (s.prefs.style == d) Icon(Icons.Rounded.Check, null) })
                            }
                            HorizontalDivider()
                            DropdownMenuItem({ Text("الملفات المخفية") }, { vm.toggleHidden(); menu = false },
                                trailingIcon = { if (s.showHidden) Icon(Icons.Rounded.Check, null) })
                            if (cat == null) DropdownMenuItem({ Text("ملف نصي جديد") }, { dialog = Dlg.NewFile; menu = false },
                                leadingIcon = { Icon(Icons.Rounded.NoteAdd, null) })
                            DropdownMenuItem({ Text("تحديث") }, { vm.load(); menu = false },
                                leadingIcon = { Icon(Icons.Rounded.Refresh, null) })
                            if (cat == Category.Trash) DropdownMenuItem({ Text("إفراغ السلة") },
                                { dialog = Dlg.EmptyTrash; menu = false }, leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null) })
                        }
                    }
                })
        },
        bottomBar = {
            s.clipboard?.takeIf { cat == null }?.let { c ->
                Surface(tonalElevation = 3.dp) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${c.paths.size} عنصر ${if (c.cut) "للنقل" else "للنسخ"}", Modifier.weight(1f))
                        TextButton(vm::cancelClipboard) { Text("إلغاء") }
                        Button(vm::paste) { Icon(Icons.Rounded.ContentPaste, null); Spacer(Modifier.width(6.dp)); Text("لصق هنا") }
                    }
                }
            }
        },
        floatingActionButton = {
            if (cat == null && !selecting && s.clipboard == null)
                FloatingActionButton({ dialog = Dlg.NewFolder }) { Icon(Icons.Rounded.CreateNewFolder, "مجلد جديد") }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when {
                s.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                shown.isEmpty() -> Text("لا توجد ملفات هنا", Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                s.prefs.style == DisplayStyle.Grid -> LazyVerticalGrid(GridCells.Adaptive(104.dp), Modifier.fillMaxSize().padding(8.dp)) {
                    items(shown, key = { it.path }) { f -> FileGridCell(f, f.path in s.selection, { click(f) }, { vm.toggle(f.path) }) }
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(shown, key = { it.path }) { f ->
                        FileRow(f, f.path in s.selection, s.prefs.style == DisplayStyle.Detailed, { click(f) }, { vm.toggle(f.path) })
                    }
                }
            }
        }
    }

    val n = s.selection.size
    when (dialog) {
        Dlg.Delete -> Confirm("نقل $n عنصر إلى السلة؟", "يمكنك استعادتها من السلة خلال فترة الاحتفاظ.", "نقل", { dialog = null }) { vm.trashSelected(); dialog = null }
        Dlg.Forever -> Confirm("حذف $n عنصر نهائياً؟", "لا يمكن التراجع عن هذا الإجراء.", "حذف", { dialog = null }) { vm.deleteForever(); dialog = null }
        Dlg.EmptyTrash -> Confirm("إفراغ السلة؟", "سيُحذف كل ما فيها نهائياً.", "إفراغ", { dialog = null }) { vm.emptyTrash(); dialog = null }
        Dlg.Rename -> TextInput("إعادة تسمية", shown.firstOrNull { it.path in s.selection }?.name ?: "", { dialog = null }) { vm.rename(it); dialog = null }
        Dlg.NewFolder -> TextInput("مجلد جديد", "", { dialog = null }) { vm.newFolder(it); dialog = null }
        Dlg.NewFile -> TextInput("ملف نصي جديد", "ملاحظة.txt", { dialog = null }) { vm.newFile(it); dialog = null }
        null -> {}
    }
}

@Composable
private fun Confirm(title: String, text: String, ok: String, onDismiss: () -> Unit, onOk: () -> Unit) = AlertDialog(
    onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
    confirmButton = { TextButton(onOk) { Text(ok) } }, dismissButton = { TextButton(onDismiss) { Text("إلغاء") } })

@Composable
private fun TextInput(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true) },
        confirmButton = { TextButton({ if (v.isNotBlank() && !v.contains('/')) onOk(v) }) { Text("موافق") } },
        dismissButton = { TextButton(onDismiss) { Text("إلغاء") } })
}

/** يطابق امتداد الملف مع أنماط MIME المطلوبة من التطبيق الطالب (image/* …) */
private fun matchesMime(ext: String, mimes: List<String>): Boolean {
    if (mimes.isEmpty() || mimes.any { it == "*/*" }) return true
    val m = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: return false
    return mimes.any { p -> if (p.endsWith("/*")) m.startsWith(p.dropLast(1)) else m.equals(p, true) }
}
