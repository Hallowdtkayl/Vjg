package app.filehub.alarm

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import app.filehub.MainActivity

/**
 * نستعمل setAlarmClock: دقيق حتى في وضع Doze، ويُعامَل كمنبه حقيقي (أيقونة في شريط الحالة)
 * ولا يحتاج إذن SCHEDULE_EXACT_ALARM.
 */
object AlarmScheduler {
    const val ACT = "app.filehub.ALARM_FIRE"
    private const val SNOOZE_BASE = 1_000_000
    private const val TIMER_BASE = 2_000_000
    private const val CH_TIMER = "timers"

    private fun fire(ctx: Context, code: Int, kind: String, id: Int) = PendingIntent.getBroadcast(ctx, code,
        Intent(ctx, AlarmReceiver::class.java).setAction(ACT).putExtra("kind", kind).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun showPi(ctx: Context) = PendingIntent.getActivity(ctx, 0,
        Intent(ctx, MainActivity::class.java).setAction("app.filehub.OPEN_ALARMS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun set(ctx: Context, at: Long, pi: PendingIntent) {
        ctx.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, showPi(ctx)), pi)
    }
    private fun cancelPi(ctx: Context, pi: PendingIntent) { ctx.getSystemService(AlarmManager::class.java).cancel(pi); pi.cancel() }

    // ───── المنبهات ─────
    /** يرجع موعد الرنين التالي أو null إن كان معطّلاً */
    fun schedule(ctx: Context, a: Alarm): Long? {
        cancel(ctx, a.id)
        if (!a.enabled) return null
        val t = nextTrigger(a)
        set(ctx, t, fire(ctx, a.id, "alarm", a.id))
        return t
    }
    fun cancel(ctx: Context, id: Int) { cancelPi(ctx, fire(ctx, id, "alarm", id)); cancelPi(ctx, fire(ctx, SNOOZE_BASE + id, "snooze", id)) }
    fun snooze(ctx: Context, a: Alarm, minutes: Int) {
        set(ctx, System.currentTimeMillis() + minutes * 60_000L, fire(ctx, SNOOZE_BASE + a.id, "snooze", a.id))
    }

    // ───── المؤقتات ─────
    fun scheduleTimer(ctx: Context, t: TimerItem) {
        set(ctx, t.endsAt, fire(ctx, TIMER_BASE + t.id, "timer", t.id))
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_TIMER, "المؤقتات الجارية", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(ctx, CH_TIMER).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(t.label.ifBlank { "المؤقت" }).setContentText("يعمل").setOngoing(true).setOnlyAlertOnce(true)
            .setUsesChronometer(true).setChronometerCountDown(true).setWhen(t.endsAt).setContentIntent(showPi(ctx)).build()
        runCatching { nm.notify(TIMER_BASE + t.id, n) }
    }
    fun cancelTimer(ctx: Context, id: Int) {
        cancelPi(ctx, fire(ctx, TIMER_BASE + id, "timer", id))
        ctx.getSystemService(NotificationManager::class.java).cancel(TIMER_BASE + id)
    }

    /** بعد الإقلاع أو تغيير الوقت/المنطقة الزمنية أو استعادة نسخة احتياطية */
    fun rescheduleAll(ctx: Context) {
        AlarmStore.alarms(ctx).forEach { schedule(ctx, it) }
        val now = System.currentTimeMillis()
        AlarmStore.timers(ctx).filter { it.state == 1 }.forEach { t ->
            if (t.endsAt > now) scheduleTimer(ctx, t)
            else AlarmStore.updateTimer(ctx, t.id) { it.copy(state = 3, endsAt = 0, remainingMs = 0) }
        }
    }
}

/** عمليات المؤقت: تحدّث المخزن والمُجدوِل معاً */
object TimerActions {
    fun create(ctx: Context, totalMs: Long, label: String, start: Boolean): TimerItem {
        val l = AlarmStore.timers(ctx)
        val t = TimerItem((l.maxOfOrNull { it.id } ?: 0) + 1, label, totalMs, 0, 0, totalMs)
        AlarmStore.saveTimers(ctx, l + t)
        return if (start) start(ctx, t.id) ?: t else t
    }
    fun start(ctx: Context, id: Int): TimerItem? = AlarmStore.updateTimer(ctx, id) { t ->
        val rem = if (t.state == 2) t.remainingMs else t.totalMs
        t.copy(state = 1, endsAt = System.currentTimeMillis() + rem, remainingMs = rem)
    }?.also { AlarmScheduler.scheduleTimer(ctx, it) }
    fun pause(ctx: Context, id: Int) {
        AlarmStore.updateTimer(ctx, id) { t -> t.copy(state = 2, remainingMs = (t.endsAt - System.currentTimeMillis()).coerceAtLeast(0), endsAt = 0) }
        AlarmScheduler.cancelTimer(ctx, id)
    }
    fun reset(ctx: Context, id: Int) {
        AlarmStore.updateTimer(ctx, id) { it.copy(state = 0, endsAt = 0, remainingMs = it.totalMs) }
        AlarmScheduler.cancelTimer(ctx, id)
    }
    fun addMinute(ctx: Context, id: Int) {
        val t = AlarmStore.updateTimer(ctx, id) { t ->
            when (t.state) {
                1 -> t.copy(totalMs = t.totalMs + 60_000, endsAt = t.endsAt + 60_000)
                3 -> t.copy(state = 1, totalMs = 60_000, endsAt = System.currentTimeMillis() + 60_000, remainingMs = 60_000)
                else -> t.copy(totalMs = t.totalMs + 60_000, remainingMs = t.remainingMs + 60_000)
            }
        }
        if (t?.state == 1) AlarmScheduler.scheduleTimer(ctx, t)
    }
    fun delete(ctx: Context, id: Int) {
        AlarmScheduler.cancelTimer(ctx, id)
        AlarmStore.saveTimers(ctx, AlarmStore.timers(ctx).filter { it.id != id })
    }
}
