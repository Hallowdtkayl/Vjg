package app.filehub.ui.calc

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.filehub.FileApp
import app.filehub.calc.*
import org.json.JSONArray

private enum class Mode(val label: String) { Basic("عادية"), Sci("علمية"), Prog("المبرمج"), Units("تحويل الوحدات") }

private fun copy(ctx: Context, s: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("calc", s))
    Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = (ctx.applicationContext as FileApp).prefs
    var mode by remember { mutableStateOf(Mode.Basic) }
    var menu by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val history = remember {
        mutableStateListOf<String>().apply { runCatching { JSONArray(prefs.rawGet("calc_history") ?: "[]").let { a -> (0 until a.length()).forEach { add(a.getString(it)) } } } }
    }
    fun saveHistory() = prefs.rawPut("calc_history", JSONArray(history.toList()).toString())
    var reuse by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("الحاسبة — " + mode.label) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
            actions = {
                if (mode != Mode.Units) IconButton({ showHistory = true }) { Icon(Icons.Rounded.History, "السجل") }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.Apps, "الوضع") }
                    DropdownMenu(menu, { menu = false }) {
                        Mode.entries.forEach { m -> DropdownMenuItem({ Text(m.label) }, { mode = m; menu = false }, trailingIcon = { if (mode == m) Icon(Icons.Rounded.Check, null) }) }
                    }
                }
            })
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (mode) {
                Mode.Basic, Mode.Sci -> Standard(mode == Mode.Sci, reuse, { reuse = null }, { history.add(0, it); while (history.size > 60) history.removeAt(history.size - 1); saveHistory() })
                Mode.Prog -> Programmer()
                Mode.Units -> UnitConverter()
            }
        }
    }
    if (showHistory) ModalBottomSheet({ showHistory = false }) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("السجل", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton({ history.clear(); saveHistory() }) { Text("مسح") }
            }
            if (history.isEmpty()) Text("لا توجد عمليات بعد", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(24.dp))
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                itemsIndexed(history) { _, h ->
                    ListItem({ CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(h) } },
                        modifier = Modifier.combinedClickable(onClick = { reuse = h.substringAfterLast("= "); mode = if (mode == Mode.Prog || mode == Mode.Units) Mode.Basic else mode; showHistory = false }, onLongClick = { copy(ctx, h.substringAfterLast("= ")) }))
                }
            }
        }
    }
}

// ───────────────────────── مفاتيح ─────────────────────────
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RowScope.Key(label: String, bg: Color = MaterialTheme.colorScheme.surfaceVariant, fg: Color = MaterialTheme.colorScheme.onSurface,
                         enabled: Boolean = true, size: Int = 24, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Box(Modifier.weight(1f).padding(3.dp).height(58.dp).clip(RoundedCornerShape(18.dp)).background(if (enabled) bg else bg.copy(alpha = .35f))
        .combinedClickable(enabled = enabled, onClick = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onClick() },
            onLongClick = onLong?.let { f -> { haptic.performHapticFeedback(HapticFeedbackType.LongPress); f() } }), Alignment.Center) {
        Text(label, fontSize = size.sp, color = if (enabled) fg else fg.copy(alpha = .4f), fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Keys(vararg rows: @Composable RowScope.() -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.padding(horizontal = 8.dp)) { rows.forEach { r -> Row(Modifier.fillMaxWidth(), content = r) } }
    }
}

// ───────────────────────── عادية + علمية ─────────────────────────
@Composable
private fun Standard(sci: Boolean, reuse: String?, onReused: () -> Unit, addHistory: (String) -> Unit) {
    val ctx = LocalContext.current
    var expr by remember { mutableStateOf("") }
    var deg by remember { mutableStateOf(true) }
    var ans by remember { mutableDoubleStateOf(0.0) }
    var mem by remember { mutableDoubleStateOf(0.0) }
    var done by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scroll = rememberScrollState()
    LaunchedEffect(reuse) { reuse?.let { expr = it; done = true; onReused() } }
    LaunchedEffect(expr) { scroll.scrollTo(scroll.maxValue) }

    val preview = remember(expr, deg, ans) { runCatching { if (expr.isBlank()) "" else formatNumber(Evaluator(expr, deg, ans).eval()) }.getOrDefault("") }
    val ops = setOf('+', '-', '×', '÷', '^', '%')

    fun press(t: String) {
        error = null
        if (done) { if (t.firstOrNull() !in ops && t != "!") expr = ""; done = false }
        expr += t
    }
    fun back() {
        error = null; done = false
        val m = Regex("(asinh|acosh|atanh|asin|acos|atan|sinh|cosh|tanh|sin|cos|tan|log|ln|exp|sqrt|cbrt|abs|Ans)\\($").find(expr)
        expr = if (m != null) expr.dropLast(m.value.length) else expr.dropLast(1)
    }
    fun equals() {
        if (expr.isBlank()) return
        try {
            val v = Evaluator(expr, deg, ans).eval(); val r = formatNumber(v)
            addHistory("$expr = $r"); ans = v; expr = r; done = true; error = null
        } catch (e: CalcError) { error = e.message } catch (e: Exception) { error = "تعبير غير صالح" }
    }
    fun paren() { val o = expr.count { it == '(' }; val c = expr.count { it == ')' }
        press(if (o > c && expr.lastOrNull()?.let { it.isDigit() || it == ')' || it == '!' || it == '%' } == true) ")" else "(") }
    fun current(): Double? = runCatching { Evaluator(expr, deg, ans).eval() }.getOrNull()

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text("M: ${if (mem != 0.0) formatNumber(mem) else "—"}   ${if (deg) "DEG" else "RAD"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(expr.ifEmpty { "0" }, Modifier.horizontalScroll(scroll).combinedClickableCopy(ctx, expr), fontSize = if (expr.length > 14) 30.sp else 46.sp, maxLines = 1,
                    fontWeight = FontWeight.Light, textAlign = TextAlign.End)
                Text(error ?: (if (!done) preview else ""), fontSize = 24.sp, color = if (error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
        val acc = MaterialTheme.colorScheme.primaryContainer; val onAcc = MaterialTheme.colorScheme.onPrimaryContainer
        val prim = MaterialTheme.colorScheme.primary; val onPrim = MaterialTheme.colorScheme.onPrimary
        val sec = MaterialTheme.colorScheme.secondaryContainer
        if (sci) {
            Keys(
                { Key(if (deg) "DEG" else "RAD", sec, size = 16) { deg = !deg }; Key("sin", sec, size = 16) { press("sin(") }; Key("cos", sec, size = 16) { press("cos(") }; Key("tan", sec, size = 16) { press("tan(") }; Key("Ans", sec, size = 16) { press("Ans") } },
                { Key("ln", sec, size = 16) { press("ln(") }; Key("log", sec, size = 16) { press("log(") }; Key("√", sec) { press("√(") }; Key("xʸ", sec) { press("^") }; Key("n!", sec, size = 16) { press("!") } },
                { Key("π", sec) { press("π") }; Key("e", sec) { press("e") }; Key("x²", sec) { press("^2") }; Key("1/x", sec, size = 16) { press("1÷(") }; Key("|x|", sec, size = 16) { press("abs(") } },
                { Key("asin", sec, size = 14) { press("asin(") }; Key("acos", sec, size = 14) { press("acos(") }; Key("atan", sec, size = 14) { press("atan(") }; Key("eˣ", sec, size = 16) { press("exp(") }; Key("∛", sec) { press("cbrt(") } },
                { Key("MC", sec, size = 16) { mem = 0.0 }; Key("MR", sec, size = 16) { press(formatNumber(mem)) }; Key("M+", sec, size = 16) { current()?.let { mem += it } }; Key("M−", sec, size = 16) { current()?.let { mem -= it } }; Key("⌫", sec) { back() } }
            )
        }
        Keys(
            { Key("AC", acc, onAcc, onLong = null) { expr = ""; error = null; done = false }; Key("( )", acc, onAcc) { paren() }; Key("%", acc, onAcc) { press("%") }; Key("÷", acc, onAcc) { press("÷") } },
            { Key("7") { press("7") }; Key("8") { press("8") }; Key("9") { press("9") }; Key("×", acc, onAcc) { press("×") } },
            { Key("4") { press("4") }; Key("5") { press("5") }; Key("6") { press("6") }; Key("−", acc, onAcc) { press("-") } },
            { Key("1") { press("1") }; Key("2") { press("2") }; Key("3") { press("3") }; Key("+", acc, onAcc) { press("+") } },
            { Key("±") { expr = if (expr.isBlank()) "-" else if (expr.startsWith("-(") && expr.endsWith(")")) expr.drop(2).dropLast(1) else "-($expr)" }
              Key("0") { press("0") }; Key(".") { press(".") }
              Key("=", prim, onPrim) { equals() } },
            { if (!sci) { Key("⌫", MaterialTheme.colorScheme.surfaceVariant, size = 22) { back() }; Spacer(Modifier.weight(3f)) } }
        )
        Spacer(Modifier.height(8.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.combinedClickableCopy(ctx: Context, text: String) = this.combinedClickable(onClick = {}, onLongClick = { if (text.isNotBlank()) copy(ctx, text) })

// ───────────────────────── المبرمج ─────────────────────────
@Composable
private fun Programmer() {
    val ctx = LocalContext.current
    var base by remember { mutableIntStateOf(10) }
    var expr by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val value = remember(expr, base) { runCatching { if (expr.isBlank()) null else ProgEvaluator(expr, base).eval() }.getOrNull() }
    fun press(t: String) { expr += t; error = null }
    fun eq() { try { val v = ProgEvaluator(expr, base).eval(); expr = formatBase(v, base) } catch (e: CalcError) { error = e.message } catch (e: Exception) { error = "تعبير غير صالح" } }
    fun setBase(b: Int) { value?.let { expr = formatBase(it, b) }; base = b }
    val acc = MaterialTheme.colorScheme.primaryContainer; val onAcc = MaterialTheme.colorScheme.onPrimaryContainer
    val sec = MaterialTheme.colorScheme.secondaryContainer

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Text(expr.ifEmpty { "0" }, Modifier.combinedClickableCopy(ctx, expr), fontSize = 34.sp, fontWeight = FontWeight.Light, maxLines = 1)
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)
                listOf(16 to "HEX", 10 to "DEC", 8 to "OCT", 2 to "BIN").forEach { (b, n) ->
                    Row(Modifier.fillMaxWidth().combinedClickableCopy(ctx, value?.let { formatBase(it, b) }.orEmpty()), verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(base == b, { setBase(b) }, { Text(n) })
                        Spacer(Modifier.width(8.dp))
                        Text(value?.let { formatBase(it, b) } ?: "—", Modifier.weight(1f), fontSize = 15.sp, maxLines = 1, textAlign = TextAlign.End, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        fun digit(c: Char) = Character.digit(c, base) >= 0
        Keys(
            { listOf("A", "B", "C", "D").forEach { c -> Key(c, enabled = digit(c[0])) { press(c) } } },
            { Key("E", enabled = digit('E')) { press("E") }; Key("F", enabled = digit('F')) { press("F") }; Key("(", acc, onAcc) { press("(") }; Key(")", acc, onAcc) { press(")") } },
            { Key("AND", sec, size = 14) { press("&") }; Key("OR", sec, size = 14) { press("|") }; Key("XOR", sec, size = 14) { press("^") }; Key("NOT", sec, size = 14) { press("~") } },
            { Key("<<", sec, size = 18) { press("<<") }; Key(">>", sec, size = 18) { press(">>") }; Key("%", acc, onAcc) { press("%") }; Key("÷", acc, onAcc) { press("÷") } },
            { Key("7", enabled = digit('7')) { press("7") }; Key("8", enabled = digit('8')) { press("8") }; Key("9", enabled = digit('9')) { press("9") }; Key("×", acc, onAcc) { press("×") } },
            { Key("4", enabled = digit('4')) { press("4") }; Key("5", enabled = digit('5')) { press("5") }; Key("6", enabled = digit('6')) { press("6") }; Key("−", acc, onAcc) { press("-") } },
            { Key("1", enabled = digit('1')) { press("1") }; Key("2", enabled = digit('2')) { press("2") }; Key("3", enabled = digit('3')) { press("3") }; Key("+", acc, onAcc) { press("+") } },
            { Key("AC", acc, onAcc) { expr = ""; error = null }; Key("0") { press("0") }; Key("⌫") { expr = expr.dropLast(1); error = null }
              Key("=", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimary) { eq() } }
        )
        Spacer(Modifier.height(8.dp))
    }
}

// ───────────────────────── تحويل الوحدات ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UnitConverter() {
    val ctx = LocalContext.current
    var ci by remember { mutableIntStateOf(0) }
    val cat = Units.all[ci]
    var from by remember(ci) { mutableIntStateOf(0) }
    var to by remember(ci) { mutableIntStateOf(1.coerceAtMost(cat.units.size - 1)) }
    var input by remember { mutableStateOf("1") }
    val result = remember(input, ci, from, to) { input.toDoubleOrNull()?.let { runCatching { formatNumber(Units.convert(cat, it, from, to)) }.getOrNull() } ?: "—" }

    @Composable
    fun UnitPicker(sel: Int, onSel: (Int) -> Unit) {
        var open by remember { mutableStateOf(false) }
        Box {
            OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text(cat.units[sel].name, maxLines = 1); Spacer(Modifier.weight(1f)); Icon(Icons.Rounded.ArrowDropDown, null) }
            DropdownMenu(open, { open = false }) { cat.units.forEachIndexed { i, u -> DropdownMenuItem({ Text(u.name) }, { onSel(i); open = false }) } }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Units.all.forEachIndexed { i, c -> FilterChip(ci == i, { ci = i }, { Text(c.name) }) }
        }
        OutlinedTextField(input, { input = it.filter { c -> c.isDigit() || c == '.' || c == '-' } }, Modifier.fillMaxWidth(), label = { Text("القيمة") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 28.sp, textAlign = TextAlign.Start))
        UnitPicker(from) { from = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            FilledTonalIconButton({ val t = from; from = to; to = t }) { Icon(Icons.Rounded.SwapVert, "تبديل") }
        }
        UnitPicker(to) { to = it }
        Card(Modifier.fillMaxWidth().combinedClickableCopy(ctx, result), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(20.dp)) {
                Text("النتيجة (اضغط مطولاً للنسخ)", style = MaterialTheme.typography.labelMedium)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(result, fontSize = 36.sp, fontWeight = FontWeight.Light) }
                Text(cat.units[to].name, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .7f))
            }
        }
    }
}
