package app.filehub.model

object FileTypes {
    val images = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg", "avif")
    val videos = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "ts", "m4v", "mpg", "mpeg")
    val audio = setOf("mp3", "wav", "flac", "m4a", "ogg", "aac", "opus", "amr", "wma", "mid")
    val docs = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "note", "rtf",
        "odt", "ods", "odp", "csv", "md", "epub", "json", "xml", "html", "log")
    val archives = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz")
    val apps = setOf("apk", "apks", "xapk")
}

private const val DAY = 86_400_000L
const val LARGE_FILE_BYTES = 100L * 1024 * 1024

fun Category.matches(f: FileItem, now: Long): Boolean = when (this) {
    Category.Images -> f.ext in FileTypes.images
    Category.Videos -> f.ext in FileTypes.videos
    Category.Audio -> f.ext in FileTypes.audio
    Category.Documents -> f.ext in FileTypes.docs
    Category.Archives -> f.ext in FileTypes.archives
    Category.Apps -> f.ext in FileTypes.apps
    Category.Recent -> now - f.modified < 7 * DAY
    Category.Large -> f.size >= LARGE_FILE_BYTES
    Category.Trash -> false
}
