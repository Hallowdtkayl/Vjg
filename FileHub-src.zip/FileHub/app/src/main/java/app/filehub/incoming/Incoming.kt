package app.filehub.incoming

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.File

/** ما وصل من تطبيق آخر (عرض/مشاركة)، تقرؤه الشاشات بعد توجيه MainActivity إليها */
object IncomingHub {
    var uris: List<Uri> = emptyList()
    var mime: String? = null
    var text: String? = null
    fun set(uris: List<Uri>, mime: String?, text: String? = null) { this.uris = uris; this.mime = mime; this.text = text }
}

/** يحوّل Uri قادماً من تطبيق آخر إلى ملف حقيقي: مسار مباشر إن أمكن، وإلا نسخة في الكاش */
object IncomingResolver {
    fun displayName(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()

    fun resolve(ctx: Context, uri: Uri, mime: String?): File? {
        if (uri.scheme == "file") return uri.path?.let(::File)?.takeIf { it.exists() }
        if (uri.scheme != "content") return null
        // 1) مزوّد التخزين الخارجي: المعرّف يحمل المسار
        if (uri.authority == "com.android.externalstorage.documents") runCatching {
            val id = DocumentsContract.getDocumentId(uri)
            val vol = id.substringBefore(':'); val rel = id.substringAfter(':', "")
            val root = if (vol == "primary") Environment.getExternalStorageDirectory().absolutePath else "/storage/$vol"
            File(root, rel).takeIf { it.exists() }
        }.getOrNull()?.let { return it }
        // 2) عمود _data (MediaStore وبعض المزوّدين)
        runCatching {
            ctx.contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let(::File)?.takeIf { it.isFile && it.canRead() } else null
            }
        }.getOrNull()?.let { return it }
        // 3) نسخ إلى الكاش
        return copyToCache(ctx, uri, mime)
    }

    fun copyToCache(ctx: Context, uri: Uri, mime: String?): File? = runCatching {
        var name = displayName(ctx, uri)?.replace(Regex("[\\\\/:*?\"<>|]"), "_") ?: "file"
        if ('.' !in name) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime ?: ctx.contentResolver.getType(uri))
            if (ext != null) name += ".$ext"
        }
        val dir = File(ctx.cacheDir, "incoming/${System.currentTimeMillis()}").apply { mkdirs() }
        val out = File(dir, name)
        ctx.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        out
    }.getOrNull()
}
