package app.filehub.ui.viewers

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.filehub.ui.screens.openExternal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewer(path: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(path)
    val renderer = remember(path) { runCatching { PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)) } }
    DisposableEffect(path) { onDispose { renderer.getOrNull()?.close() } }
    val mutex = remember { Mutex() }
    val listState = rememberLazyListState()
    var scale by remember { mutableFloatStateOf(1f) }
    var tx by remember { mutableFloatStateOf(0f) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(file.name, maxLines = 1) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } })
    }) { pad ->
        val r = renderer.getOrNull()
        if (r == null) Column(Modifier.fillMaxSize().padding(pad).padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("تعذّر فتح الملف (قد يكون محمياً بكلمة مرور أو تالفاً)", textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Button({ openExternal(ctx, path) {} }) { Text("فتح بتطبيق آخر") }
        } else BoxWithConstraints(
            Modifier.fillMaxSize().padding(pad).clipToBounds()
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; tx = 0f }) }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        // Initial: نلتقط اللمس قبل القائمة؛ لا نستهلك إصبعاً واحداً عند الحجم الطبيعي فيبقى التمرير عادياً
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            if (ev.changes.size > 1 || scale > 1f) {
                                val pan = ev.calculatePan()
                                scale = (scale * ev.calculateZoom()).coerceIn(1f, 4f)
                                val maxT = size.width * (scale - 1f) / 2f
                                tx = if (scale > 1f) (tx + pan.x).coerceIn(-maxT, maxT) else 0f
                                if (scale > 1f) listState.dispatchRawDelta(-pan.y / scale)
                                ev.changes.forEach { it.consume() }
                            }
                        } while (ev.changes.any { it.pressed })
                    }
                }
        ) {
            // نرسم بدقة 1.8× ليبقى النص حاداً عند التكبير (مقايضة بالذاكرة)
            val renderW = (with(LocalDensity.current) { maxWidth.roundToPx() } * 1.8f).toInt().coerceAtMost(2400)
            LazyColumn(Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = tx),
                state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items((0 until r.pageCount).toList()) { i -> PdfPage(r, i, renderW, mutex) }
            }
        }
    }
}

@Composable
private fun PdfPage(r: PdfRenderer, index: Int, widthPx: Int, mutex: Mutex) {
    var bmp by remember(index, widthPx) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(index, widthPx) {
        bmp = withContext(Dispatchers.Default) {
            mutex.withLock {
                runCatching {
                    r.openPage(index).use { page ->
                        val h = (widthPx * page.height / page.width.toFloat()).toInt().coerceAtLeast(1)
                        Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888).also {
                            it.eraseColor(AColor.WHITE)
                            page.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        }
                    }
                }.getOrNull()
            }
        }
    }
    val b = bmp
    if (b == null) Box(Modifier.fillMaxWidth().aspectRatio(0.707f), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    else Image(b.asImageBitmap(), "صفحة ${index + 1}", Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
}
