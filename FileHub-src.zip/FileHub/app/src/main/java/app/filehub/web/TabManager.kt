package app.filehub.web

import android.content.Context
import android.graphics.Bitmap
import android.webkit.WebView
import androidx.compose.runtime.*

/** تبويب: حالة تُعرض في الواجهة + WebView حيّ يبقى في الذاكرة ليكون التبديل فورياً */
class BrowserTab(val id: Int, val noHistory: Boolean) {
    var url by mutableStateOf("")
    var title by mutableStateOf("تبويب جديد")
    var progress by mutableIntStateOf(0)
    var favicon by mutableStateOf<Bitmap?>(null)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var desktop by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var webView: WebView? = null
}

object TabManager {
    val tabs = mutableStateListOf<BrowserTab>()
    var current by mutableIntStateOf(0)
    /** رابط ينتظر الفتح في التبويب الحالي (من السجل أو العلامات أو نية خارجية) */
    var pendingUrl by mutableStateOf<String?>(null)
    /** طلب تنزيل ينتظر تأكيد المستخدم (المرحلة 2: نافذة التنزيل الكاملة) */
    var pendingDownload by mutableStateOf<DownloadRequest?>(null)
    private lateinit var app: Context
    private var nextId = 1

    val active: BrowserTab? get() = tabs.getOrNull(current)

    fun newTab(ctx: Context, url: String? = null, noHistory: Boolean = false): BrowserTab {
        app = ctx.applicationContext
        val t = BrowserTab(nextId++, noHistory)
        tabs.add(t); current = tabs.lastIndex
        val wv = webViewFor(ctx, t)
        wv.loadUrl(url ?: SearchEngines.DEFAULT_HOME)
        return t
    }

    fun webViewFor(ctx: Context, t: BrowserTab): WebView {
        app = ctx.applicationContext
        return t.webView ?: WebEngine.create(ctx, t.noHistory, callbacksFor(t)).also { t.webView = it }
    }

    fun select(i: Int) { if (i in tabs.indices) current = i }

    fun close(i: Int) {
        val t = tabs.getOrNull(i) ?: return
        t.webView?.let { it.stopLoading(); it.destroy() }; t.webView = null
        tabs.removeAt(i)
        current = current.coerceIn(0, (tabs.size - 1).coerceAtLeast(0))
    }

    private fun callbacksFor(t: BrowserTab) = object : WebCallbacks {
        override fun onProgress(p: Int) { t.progress = p }
        override fun onTitle(title: String) { if (title.isNotBlank()) t.title = title }
        override fun onUrl(u: String) { t.url = u; t.error = null }
        override fun onFavicon(b: Bitmap?) { t.favicon = b }
        override fun onNav(canBack: Boolean, canForward: Boolean) { t.canBack = canBack; t.canForward = canForward }
        override fun onError(url: String, msg: String) { t.error = msg }
        override fun onNewWindow(url: String) { newTab(app, url, t.noHistory) }
        override fun onDownload(req: DownloadRequest) { pendingDownload = req }
    }
}
