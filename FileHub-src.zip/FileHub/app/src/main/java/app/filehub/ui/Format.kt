package app.filehub.ui

import java.text.DateFormat
import java.util.Date

fun Long.readableSize(): String = when {
    this >= 1L shl 30 -> "%.1f ج.ب".format(this / (1L shl 30).toDouble())
    this >= 1L shl 20 -> "%.1f م.ب".format(this / (1L shl 20).toDouble())
    this >= 1L shl 10 -> "%d ك.ب".format(this shr 10)
    else -> "$this بايت"
}
fun Long.readableDate(): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(this))
