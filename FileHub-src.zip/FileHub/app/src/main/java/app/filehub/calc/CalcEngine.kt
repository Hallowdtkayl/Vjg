package app.filehub.calc

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

class CalcError(msg: String) : Exception(msg)

private fun normalize(src: String): String {
    val sb = StringBuilder(src.length)
    for (c in src) sb.append(when (c) {
        '×', '✕' -> '*'; '÷' -> '/'; '−', '–' -> '-'; '٫', ',' -> '.'
        in '٠'..'٩' -> '0' + (c - '٠'); in '۰'..'۹' -> '0' + (c - '۰')
        ' ' -> '\u0000'; else -> c
    })
    return sb.toString().replace("\u0000", "").replace("π", "pi")
}

/** مقيّم تعابير: أولويات صحيحة، ضرب ضمني (2π، 2(3))، نسبة مئوية ذكية (200+10% = 220)، ودرجات/راديان */
class Evaluator(src: String, private val deg: Boolean, private val ans: Double = 0.0) {
    private val s = normalize(src)
    private var p = 0
    private class V(val v: Double, val pct: Boolean = false)

    fun eval(): Double { val r = expr(); if (p < s.length) throw CalcError("تعبير غير صالح"); return r.v }

    private fun peek() = if (p < s.length) s[p] else '\u0000'

    private fun expr(): V {
        var l = term()
        while (peek() == '+' || peek() == '-') {
            val op = s[p++]; val r = term()
            val rv = if (r.pct) l.v * r.v else r.v          // 200 + 10% → 200 + 20
            l = V(if (op == '+') l.v + rv else l.v - rv)
        }
        return l
    }

    private fun startsOperand(c: Char) = c.isDigit() || c == '.' || c == '(' || c.isLetter() || c == '√'

    private fun term(): V {
        var l = unary()
        while (p < s.length) {
            val c = peek()
            if (c == '*' || c == '/') {
                p++; val r = unary()
                l = V(if (c == '*') l.v * r.v else { if (r.v == 0.0) throw CalcError("القسمة على صفر"); l.v / r.v })
            } else if (startsOperand(c)) { val r = unary(); l = V(l.v * r.v) }   // ضرب ضمني
            else break
        }
        return l
    }

    private fun unary(): V = when (peek()) {
        '-' -> { p++; val v = unary(); V(-v.v, v.pct) }
        '+' -> { p++; unary() }
        else -> power()
    }

    private fun power(): V {
        val b = postfix()
        if (peek() == '^') { p++; val e = unary(); return V(b.v.pow(e.v)) }
        return b
    }

    private fun postfix(): V {
        var v = primary()
        while (true) when (peek()) {
            '!' -> { p++; v = V(fact(v.v)) }
            '%' -> { p++; v = V(v.v / 100, true) }
            else -> return v
        }
    }

    private fun fact(x: Double): Double {
        if (x < 0 || x != floor(x) || x > 170) throw CalcError("المضروب يتطلب عدداً صحيحاً من 0 إلى 170")
        var r = 1.0; for (i in 2..x.toInt()) r *= i; return r
    }

    private val names = listOf("asinh", "acosh", "atanh", "asin", "acos", "atan", "sinh", "cosh", "tanh", "sin", "cos", "tan", "log", "ln", "exp", "sqrt", "cbrt", "abs", "pi", "ans", "e")

    private fun primary(): V {
        if (p >= s.length) throw CalcError("تعبير ناقص")
        val c = s[p]
        when {
            c == '(' -> { p++; val v = expr(); if (peek() == ')') p++ else if (p < s.length) throw CalcError("قوس غير مغلق"); return v }
            c == '√' -> { p++; val v = unary().v; if (v < 0) throw CalcError("جذر عدد سالب"); return V(sqrt(v)) }
            c.isDigit() || c == '.' -> return V(number())
            c.isLetter() -> {
                val name = names.firstOrNull { s.startsWith(it, p, ignoreCase = true) } ?: throw CalcError("غير معروف: $c")
                p += name.length
                when (name.lowercase()) {
                    "pi" -> return V(PI); "e" -> return V(E); "ans" -> return V(ans)
                }
                val arg = if (peek() == '(') { p++; val v = expr().v; if (peek() == ')') p++; v } else unary().v
                return V(func(name.lowercase(), arg))
            }
        }
        throw CalcError("رمز غير مفهوم: $c")
    }

    private fun number(): Double {
        val st = p
        while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
        return s.substring(st, p).toDoubleOrNull() ?: throw CalcError("رقم غير صالح")
    }

    private fun rad(x: Double) = if (deg) Math.toRadians(x) else x
    private fun back(x: Double) = if (deg) Math.toDegrees(x) else x

    private fun func(n: String, x: Double): Double = when (n) {
        "sin" -> { val r = sin(rad(x)); if (abs(r) < 1e-15) 0.0 else r }
        "cos" -> { val r = cos(rad(x)); if (abs(r) < 1e-15) 0.0 else r }
        "tan" -> { if (deg && x % 180 == 90.0) throw CalcError("tan غير معرّفة"); val r = tan(rad(x)); if (abs(r) < 1e-15) 0.0 else r }
        "asin" -> { if (x !in -1.0..1.0) throw CalcError("خارج المجال"); back(asin(x)) }
        "acos" -> { if (x !in -1.0..1.0) throw CalcError("خارج المجال"); back(acos(x)) }
        "atan" -> back(atan(x))
        "sinh" -> sinh(x); "cosh" -> cosh(x); "tanh" -> tanh(x)
        "asinh" -> asinh(x); "acosh" -> acosh(x); "atanh" -> atanh(x)
        "ln" -> { if (x <= 0) throw CalcError("خارج المجال"); ln(x) }
        "log" -> { if (x <= 0) throw CalcError("خارج المجال"); log10(x) }
        "exp" -> exp(x); "sqrt" -> { if (x < 0) throw CalcError("جذر عدد سالب"); sqrt(x) }
        "cbrt" -> cbrt(x); "abs" -> abs(x)
        else -> throw CalcError("دالة غير معروفة")
    }
}

/** عرض النتيجة بـ 12 رقماً معنوياً (يمنع 0.30000000000000004) وبصيغة علمية للأعداد الكبيرة/الصغيرة */
fun formatNumber(v: Double): String {
    if (v.isNaN()) throw CalcError("غير معرّف")
    if (v.isInfinite()) throw CalcError("كبير جداً")
    if (v == 0.0) return "0"
    val bd = BigDecimal(v).round(MathContext(12)).stripTrailingZeros()
    val a = abs(v)
    return if (a >= 1e15 || a < 1e-9) bd.toString().replace("E+", "E") else bd.toPlainString()
}

/** مقيّم المبرمج: أعداد صحيحة 64 بت بالقاعدة المختارة وعمليات بتّية بأولويات لغة C */
class ProgEvaluator(src: String, private val base: Int) {
    private val s = normalize(src).uppercase().replace("AND", "&").replace("OR", "|").replace("XOR", "^").replace("NOT", "~")
    private var p = 0
    fun eval(): Long { val r = or(); if (p < s.length) throw CalcError("تعبير غير صالح"); return r }
    private fun peek() = if (p < s.length) s[p] else '\u0000'
    private fun or(): Long { var l = xor(); while (peek() == '|') { p++; l = l or xor() }; return l }
    private fun xor(): Long { var l = and(); while (peek() == '^') { p++; l = l xor and() }; return l }
    private fun and(): Long { var l = shift(); while (peek() == '&') { p++; l = l and shift() }; return l }
    private fun shift(): Long {
        var l = add()
        while (true) {
            if (s.startsWith("<<", p)) { p += 2; l = l shl add().toInt() } else if (s.startsWith(">>", p)) { p += 2; l = l shr add().toInt() } else return l
        }
    }
    private fun add(): Long { var l = mul(); while (peek() == '+' || peek() == '-') { val o = s[p++]; val r = mul(); l = if (o == '+') l + r else l - r }; return l }
    private fun mul(): Long {
        var l = un()
        while (peek() == '*' || peek() == '/' || peek() == '%') {
            val o = s[p++]; val r = un()
            if (o != '*' && r == 0L) throw CalcError("القسمة على صفر")
            l = when (o) { '*' -> l * r; '/' -> l / r; else -> l % r }
        }
        return l
    }
    private fun un(): Long = when (peek()) { '-' -> { p++; -un() }; '~' -> { p++; un().inv() }; '+' -> { p++; un() }; else -> prim() }
    private fun prim(): Long {
        if (peek() == '(') { p++; val v = or(); if (peek() == ')') p++; return v }
        val st = p
        while (p < s.length && Character.digit(s[p], base) >= 0) p++
        if (st == p) throw CalcError("تعبير ناقص")
        return runCatching { java.lang.Long.parseUnsignedLong(s.substring(st, p), base) }.getOrElse { throw CalcError("رقم كبير جداً") }
    }
}

fun formatBase(v: Long, base: Int): String = when (base) {
    10 -> v.toString(); 16 -> java.lang.Long.toHexString(v).uppercase(); 8 -> java.lang.Long.toOctalString(v); else -> java.lang.Long.toBinaryString(v)
}

// ───────────── محوّل الوحدات ─────────────
class UnitDef(val name: String, val toBase: Double)
class UnitCategory(val name: String, val units: List<UnitDef>, val temperature: Boolean = false)

object Units {
    val all = listOf(
        UnitCategory("الطول", listOf(UnitDef("متر", 1.0), UnitDef("كيلومتر", 1000.0), UnitDef("سنتيمتر", 0.01), UnitDef("ملّيمتر", 0.001),
            UnitDef("ميل", 1609.344), UnitDef("ياردة", 0.9144), UnitDef("قدم", 0.3048), UnitDef("بوصة", 0.0254), UnitDef("ميل بحري", 1852.0))),
        UnitCategory("الكتلة", listOf(UnitDef("كيلوغرام", 1.0), UnitDef("غرام", 0.001), UnitDef("ملّيغرام", 1e-6), UnitDef("طن", 1000.0),
            UnitDef("رطل", 0.45359237), UnitDef("أونصة", 0.028349523125))),
        UnitCategory("الحرارة", listOf(UnitDef("مئوية °C", 1.0), UnitDef("فهرنهايت °F", 1.0), UnitDef("كلفن K", 1.0)), true),
        UnitCategory("المساحة", listOf(UnitDef("متر مربع", 1.0), UnitDef("كيلومتر مربع", 1e6), UnitDef("هكتار", 1e4), UnitDef("دونم", 1000.0),
            UnitDef("فدّان", 4046.8564224), UnitDef("قدم مربعة", 0.09290304), UnitDef("بوصة مربعة", 0.00064516))),
        UnitCategory("الحجم", listOf(UnitDef("لتر", 1.0), UnitDef("ملّيلتر", 0.001), UnitDef("متر مكعب", 1000.0), UnitDef("غالون (أمريكي)", 3.785411784),
            UnitDef("كوب", 0.2365882365), UnitDef("قدم مكعب", 28.316846592))),
        UnitCategory("السرعة", listOf(UnitDef("متر/ثانية", 1.0), UnitDef("كم/ساعة", 1 / 3.6), UnitDef("ميل/ساعة", 0.44704), UnitDef("عقدة", 0.514444444), UnitDef("ماخ", 340.29))),
        UnitCategory("الزمن", listOf(UnitDef("ثانية", 1.0), UnitDef("دقيقة", 60.0), UnitDef("ساعة", 3600.0), UnitDef("يوم", 86400.0), UnitDef("أسبوع", 604800.0),
            UnitDef("شهر (30 يوماً)", 2_592_000.0), UnitDef("سنة (365 يوماً)", 31_536_000.0))),
        UnitCategory("البيانات", listOf(UnitDef("بايت", 1.0), UnitDef("كيلوبايت (KB)", 1024.0), UnitDef("ميغابايت (MB)", 1024.0 * 1024), UnitDef("غيغابايت (GB)", 1024.0 * 1024 * 1024),
            UnitDef("تيرابايت (TB)", 1024.0 * 1024 * 1024 * 1024), UnitDef("بت", 0.125))),
        UnitCategory("الطاقة", listOf(UnitDef("جول", 1.0), UnitDef("كيلوجول", 1000.0), UnitDef("سعرة (cal)", 4.184), UnitDef("كيلو سعرة (kcal)", 4184.0), UnitDef("واط-ساعة", 3600.0), UnitDef("كيلوواط-ساعة", 3.6e6)))
    )

    fun convert(cat: UnitCategory, v: Double, from: Int, to: Int): Double {
        if (cat.temperature) {
            val c = when (from) { 0 -> v; 1 -> (v - 32) * 5 / 9; else -> v - 273.15 }
            return when (to) { 0 -> c; 1 -> c * 9 / 5 + 32; else -> c + 273.15 }
        }
        return v * cat.units[from].toBase / cat.units[to].toBase
    }
}
