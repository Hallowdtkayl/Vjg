package app.filehub.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.filehub.model.*
import app.filehub.ui.readableDate
import app.filehub.ui.readableSize

@Composable
fun SectionTitle(text: String) = Text(
    text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
)

@Composable
fun IconBadge(icon: ImageVector, color: Color, size: Int = 44) = Box(
    Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = .15f)),
    contentAlignment = Alignment.Center
) { Icon(icon, null, tint = color, modifier = Modifier.size((size * .55f).dp)) }

@Composable
fun StorageCard(v: StorageVolume, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val icon = when (v.kind) {
        StorageVolume.Kind.Internal -> Icons.Rounded.PhoneAndroid
        StorageVolume.Kind.SdCard -> Icons.Rounded.SdCard
        StorageVolume.Kind.Usb -> Icons.Rounded.Usb
    }
    Card(modifier.clickable(onClick = onClick), shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(icon, MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(v.name, fontWeight = FontWeight.Bold)
                    Text("${v.used.readableSize()} من ${v.total.readableSize()}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { if (v.total > 0) v.used.toFloat() / v.total else 0f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape))
        }
    }
}

@Composable
fun CategoryTile(c: Category, count: Int?, onClick: () -> Unit, modifier: Modifier = Modifier) = Column(
    modifier.clip(MaterialTheme.shapes.medium).clickable(onClick = onClick).padding(8.dp),
    horizontalAlignment = Alignment.CenterHorizontally
) {
    IconBadge(c.icon, c.color, 56)
    Spacer(Modifier.height(6.dp))
    Text(c.title, style = MaterialTheme.typography.labelMedium, maxLines = 2,
        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    Text(count?.toString() ?: "…", style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
}

fun iconFor(f: FileItem): Pair<ImageVector, Color> = if (f.isDir) Icons.Rounded.Folder to Color(0xFFFFB300) else when (f.ext) {
    "jpg", "jpeg", "png", "gif", "webp", "heic" -> Icons.Rounded.Image to Color(0xFFE91E63)
    "mp4", "mkv", "avi", "mov", "webm", "3gp" -> Icons.Rounded.VideoLibrary to Color(0xFF7C4DFF)
    "mp3", "wav", "flac", "m4a", "ogg" -> Icons.Rounded.AudioFile to Color(0xFFFF9800)
    "zip", "rar", "7z" -> Icons.Rounded.FolderZip to Color(0xFF795548)
    "pdf" -> Icons.Rounded.PictureAsPdf to Color(0xFFF44336)
    "doc", "docx", "txt", "note" -> Icons.Rounded.Description to Color(0xFF2196F3)
    "xls", "xlsx", "csv" -> Icons.Rounded.TableChart to Color(0xFF4CAF50)
    "ppt", "pptx" -> Icons.Rounded.Slideshow to Color(0xFFFF5722)
    else -> Icons.Rounded.InsertDriveFile to Color(0xFF78909C)
}

/** مصغّر حقيقي للصور والفيديو، وأيقونة لباقي الأنواع */
@Composable
fun FileThumb(f: FileItem, size: Int = 44) {
    val (icon, color) = iconFor(f)
    val real = remember(f.path) { File(f.path).isFile }
    if (real && !f.isDir && (f.ext in FileTypes.images || f.ext in FileTypes.videos)) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(File(f.path)).size(256).crossfade(true).build(),
            contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = .15f))
        )
    } else IconBadge(icon, color, size)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(f: FileItem, selected: Boolean, detailed: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    Row(Modifier.fillMaxWidth().background(bg).combinedClickable(onClick = onClick, onLongClick = onLong)
        .padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        FileThumb(f)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            val sub = when {
                f.count > 0 -> "${f.count} ملف • ${f.size.readableSize()}"
                f.isDir -> f.modified.readableDate()
                else -> "${f.size.readableSize()} • ${f.modified.readableDate()}"
            }
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (detailed) Text(f.original ?: f.path, style = MaterialTheme.typography.labelSmall, maxLines = 1,
                overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileGridCell(f: FileItem, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    Column(Modifier.clip(MaterialTheme.shapes.medium).background(bg)
        .combinedClickable(onClick = onClick, onLongClick = onLong).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.TopEnd) {
            FileThumb(f, 80)
            if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(4.dp).size(20.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(f.name, style = MaterialTheme.typography.labelMedium, maxLines = 2,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}
