package app.filehub.web

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** قاعدة بيانات المتصفح (SQLite مباشرة بلا مكتبات). التاريخ والعلامات والمواقع المثبتة جاهزة؛ التنزيلات في المرحلة التالية */
class WebDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "web.db", null, 1) {
    companion object {
        @Volatile private var inst: WebDb? = null
        fun get(ctx: Context): WebDb = inst ?: synchronized(this) { inst ?: WebDb(ctx.applicationContext).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, title TEXT, time INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_history_time ON history(time DESC)")
        db.execSQL("CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL UNIQUE, title TEXT, time INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE pinned(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, url TEXT NOT NULL, scope TEXT NOT NULL, icon TEXT, theme INTEGER)")
        db.execSQL("""CREATE TABLE downloads(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, original_url TEXT NOT NULL, page_url TEXT, file_name TEXT NOT NULL,
            mime TEXT, dir TEXT NOT NULL, total INTEGER NOT NULL DEFAULT -1, done INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL, segments INTEGER NOT NULL DEFAULT 4,
            user_agent TEXT, cookies TEXT, resumable INTEGER NOT NULL DEFAULT 0, etag TEXT, created INTEGER NOT NULL, error TEXT)""")
        db.execSQL("CREATE TABLE segments(download_id INTEGER NOT NULL, idx INTEGER NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL, pos INTEGER NOT NULL, PRIMARY KEY(download_id, idx))")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    // ───── التاريخ ─────
    fun addHistory(url: String, title: String?) {
        if (url.startsWith("about:") || url.isBlank()) return
        val db = writableDatabase
        // لا نكرر الزيارة المتتالية لنفس العنوان خلال دقيقة
        val last = db.rawQuery("SELECT url, time FROM history ORDER BY id DESC LIMIT 1", null).use { if (it.moveToFirst()) it.getString(0) to it.getLong(1) else null }
        val now = System.currentTimeMillis()
        if (last != null && last.first == url && now - last.second < 60_000) { db.execSQL("UPDATE history SET title=?, time=? WHERE id=(SELECT MAX(id) FROM history)", arrayOf(title ?: "", now)); return }
        db.insert("history", null, ContentValues().apply { put("url", url); put("title", title ?: ""); put("time", now) })
    }
    fun history(query: String = "", limit: Int = 300): List<HistoryEntry> {
        val like = "%${query.trim()}%"
        return readableDatabase.rawQuery("SELECT id,url,title,time FROM history WHERE url LIKE ? OR title LIKE ? ORDER BY time DESC LIMIT $limit", arrayOf(like, like)).use { c ->
            generateSequence { if (c.moveToNext()) HistoryEntry(c.getLong(0), c.getString(1), c.getString(2).orEmpty(), c.getLong(3)) else null }.toList()
        }
    }
    fun deleteHistory(id: Long) { writableDatabase.delete("history", "id=?", arrayOf("$id")) }
    fun clearHistory(sinceMs: Long = 0) { writableDatabase.delete("history", "time>=?", arrayOf("$sinceMs")) }

    // ───── العلامات ─────
    fun isBookmarked(url: String) = readableDatabase.rawQuery("SELECT 1 FROM bookmarks WHERE url=?", arrayOf(url)).use { it.moveToFirst() }
    fun toggleBookmark(url: String, title: String): Boolean {
        if (isBookmarked(url)) { writableDatabase.delete("bookmarks", "url=?", arrayOf(url)); return false }
        writableDatabase.insert("bookmarks", null, ContentValues().apply { put("url", url); put("title", title); put("time", System.currentTimeMillis()) })
        return true
    }
    fun bookmarks(): List<Bookmark> = readableDatabase.rawQuery("SELECT id,url,title,time FROM bookmarks ORDER BY time DESC", null).use { c ->
        generateSequence { if (c.moveToNext()) Bookmark(c.getLong(0), c.getString(1), c.getString(2).orEmpty(), c.getLong(3)) else null }.toList()
    }

    // ───── المواقع المثبتة ─────
    fun pinned(): List<PinnedSite> = readableDatabase.rawQuery("SELECT id,name,url,scope,icon,theme FROM pinned ORDER BY id DESC", null).use { c ->
        generateSequence { if (c.moveToNext()) PinnedSite(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), if (c.isNull(5)) null else c.getInt(5)) else null }.toList()
    }
    fun addPinned(s: PinnedSite): Long = writableDatabase.insert("pinned", null, ContentValues().apply {
        put("name", s.name); put("url", s.url); put("scope", s.scope); put("icon", s.iconPath); put("theme", s.themeColor)
    })
    fun removePinned(id: Long) { writableDatabase.delete("pinned", "id=?", arrayOf("$id")) }

    // ───── التنزيلات: الجداول جاهزة، والعمليات تُكتب في المرحلة التالية ─────
    // TODO(phase-2): insertDownload / updateDownload / downloads() / saveSegments / loadSegments
}
