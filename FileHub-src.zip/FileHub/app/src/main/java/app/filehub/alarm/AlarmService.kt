package app.filehub.alarm

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.DateFormat
import java.util.Date

data class Ring(val kind: String, val id: Int, val title: String, val label: String, val snoozeMin: Int, val timeMs: Long)
object RingState { val current = MutableStateFlow<Ring?>(null) }

/** يستقبل لحظة الرنين: يجدول التكرار التالي فوراً ثم يبدأ الخدمة */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val kind = i.getStringExtra("kind") ?: return
        val id = i.getIntExtra("id", 0)
        if (kind == "alarm") AlarmStore.alarms(ctx).firstOrNull { it.id == id }?.let { a ->
            if (a.days != 0) AlarmScheduler.schedule(ctx, a)                 // المتكرر: الموعد التالي
            else AlarmStore.upsert(ctx, a.copy(enabled = false))             // مرة واحدة: يتعطّل
        }
        ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmService::class.java).setAction(AlarmService.ACT_RING).putExtra("kind", kind).putExtra("id", id))
    }
}

class AlarmBootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { AlarmScheduler.rescheduleAll(ctx) }
}

class AlarmService : Service() {
    companion object {
        const val ACT_RING = "app.filehub.RING"; const val ACT_DISMISS = "app.filehub.RING_DISMISS"
        const val ACT_SNOOZE = "app.filehub.RING_SNOOZE"; const val ACT_ADD_MIN = "app.filehub.RING_ADD_MIN"
        private const val CH = "alarm_ring"; private const val ID = 900
    }
    private var player: MediaPlayer? = null
    private var vib: Vibrator? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_RING -> ring(intent.getStringExtra("kind") ?: "alarm", intent.getIntExtra("id", 0))
            ACT_DISMISS -> finishRing(false)
            ACT_SNOOZE -> { RingState.current.value?.let { r -> AlarmStore.alarms(this).firstOrNull { it.id == r.id }?.let { AlarmScheduler.snooze(this, it, r.snoozeMin) } }; finishRing(false) }
            ACT_ADD_MIN -> { RingState.current.value?.let { TimerActions.addMinute(this, it.id) }; finishRing(false, keepTimer = true) }
        }
        return START_NOT_STICKY
    }

    private fun pi(action: String, code: Int) = PendingIntent.getService(this, code, Intent(this, AlarmService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE)

    private fun ring(kind: String, id: Int) {
        val isTimer = kind == "timer"
        val alarm = if (!isTimer) AlarmStore.alarms(this).firstOrNull { it.id == id } else null
        val timer = if (isTimer) AlarmStore.timers(this).firstOrNull { it.id == id } else null
        if (alarm == null && timer == null) { stopSelf(); return }
        if (timer != null) {
            AlarmStore.updateTimer(this, id) { it.copy(state = 3, endsAt = 0, remainingMs = 0) }
            getSystemService(NotificationManager::class.java).cancel(2_000_000 + id)
        }
        val label = alarm?.label?.ifBlank { null } ?: timer?.label?.ifBlank { null } ?: ""
        val title = if (isTimer) "انتهى المؤقت" else "المنبه"
        val snooze = if (isTimer) 0 else alarm?.snoozeMin ?: 0
        RingState.current.value = Ring(kind, id, title, label, snooze, System.currentTimeMillis())

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "رنين المنبه", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null); enableVibration(false) })
        val open = PendingIntent.getActivity(this, 0, Intent(this, AlarmRingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val timeText = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
        val b = NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(label.ifBlank { title })
            .setContentText(timeText).setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true).setFullScreenIntent(open, true).setContentIntent(open)
        if (snooze > 0) b.addAction(0, "غفوة", pi(ACT_SNOOZE, 2))
        if (isTimer) b.addAction(0, "+1 د", pi(ACT_ADD_MIN, 3))
        b.addAction(0, "إيقاف", pi(ACT_DISMISS, 1))
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(ID, n)

        wake?.release()
        wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "filehub:alarm").apply { acquire(60_000) }
        startSound(alarm?.ringtone, alarm?.gradual ?: false, alarm?.vibrate ?: true)
        runCatching { startActivity(Intent(this, AlarmRingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ finishRing(true) }, 10 * 60_000L)    // يسكت تلقائياً بعد 10 دقائق
    }

    private fun startSound(uriStr: String?, gradual: Boolean, vibrate: Boolean) {
        stopSound()
        val uri = uriStr?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        player = runCatching {
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@AlarmService, uri); isLooping = true; prepare()
                setVolume(if (gradual) 0.05f else 1f, if (gradual) 0.05f else 1f); start()
            }
        }.getOrNull()
        if (gradual) {                // يرتفع الصوت تدريجياً خلال 30 ثانية
            var v = 0.05f
            val step = object : Runnable { override fun run() { v = (v + 0.05f).coerceAtMost(1f); player?.setVolume(v, v); if (v < 1f) handler.postDelayed(this, 1500) } }
            handler.postDelayed(step, 1500)
        }
        if (vibrate) vib = getSystemService(Vibrator::class.java)?.also { it.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0)) }
    }

    private fun stopSound() {
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop(); player?.release() }; player = null
        runCatching { vib?.cancel() }; vib = null
    }

    private fun finishRing(missed: Boolean, keepTimer: Boolean = false) {
        val r = RingState.current.value
        stopSound()
        if (r != null && r.kind == "timer" && !keepTimer) AlarmStore.updateTimer(this, r.id) { it.copy(state = 0, endsAt = 0, remainingMs = it.totalMs) }
        if (missed && r != null) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(901, NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("منبه فائت")
                .setContentText(r.label.ifBlank { r.title }).setAutoCancel(true).build())
        }
        RingState.current.value = null
        wake?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() { stopSound(); RingState.current.value = null; super.onDestroy() }
}
