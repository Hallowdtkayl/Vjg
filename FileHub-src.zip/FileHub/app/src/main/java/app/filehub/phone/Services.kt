package app.filehub.phone

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.CallScreeningService
import android.telecom.InCallService
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import app.filehub.FileApp

object CallNotifier {
    private const val CH_IN = "incoming_call"
    private const val CH_ON = "ongoing_call"
    private const val ID = 77
    const val ACT_ANSWER = "app.filehub.CALL_ANSWER"
    const val ACT_DECLINE = "app.filehub.CALL_DECLINE"
    const val ACT_HANGUP = "app.filehub.CALL_HANGUP"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_IN, "المكالمات الواردة", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false)   // الرنين نشغّله بأنفسنا
        })
        nm.createNotificationChannel(NotificationChannel(CH_ON, "المكالمات الجارية", NotificationManager.IMPORTANCE_LOW))
    }

    private fun action(ctx: Context, a: String, code: Int) =
        PendingIntent.getBroadcast(ctx, code, Intent(ctx, CallActionReceiver::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)

    fun update(ctx: Context, list: List<CallUi>) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (list.isEmpty()) { nm.cancel(ID); return }
        val ringing = list.firstOrNull { it.ringing && !it.ignored }
        val primary = ringing ?: list.firstOrNull { it.ringing } ?: list.first()
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val icon = android.R.drawable.sym_call_incoming
        val n = if (ringing != null) {
            val person = Person.Builder().setName(ringing.title).setImportant(true).build()
            NotificationCompat.Builder(ctx, CH_IN).setSmallIcon(icon).setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX).setOngoing(true).setContentIntent(open)
                .setFullScreenIntent(open, true)       // يملأ الشاشة (حتى على شاشة القفل)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, action(ctx, ACT_DECLINE, 1), action(ctx, ACT_ANSWER, 2)))
                .build()
        } else {
            val text = when {
                primary.ringing -> "مكالمة واردة (متجاهَلة)"
                primary.state == Call.STATE_HOLDING -> "معلّقة"
                else -> "مكالمة جارية"
            }
            NotificationCompat.Builder(ctx, CH_ON).setSmallIcon(icon).setCategory(NotificationCompat.CATEGORY_CALL)
                .setContentTitle(primary.title).setContentText(text).setOngoing(true).setContentIntent(open)
                .apply { if (primary.connectMs > 0) { setUsesChronometer(true); setWhen(primary.connectMs) } }
                .apply {
                    if (primary.ringing) { addAction(0, "رد", action(ctx, ACT_ANSWER, 2)); addAction(0, "رفض", action(ctx, ACT_DECLINE, 1)) }
                    else addAction(0, "إنهاء", action(ctx, ACT_HANGUP, 3))
                }.build()
        }
        nm.notify(ID, n)
    }

    fun cancel(ctx: Context) { ctx.getSystemService(NotificationManager::class.java).cancel(ID) }
}

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        when (i.action) {
            CallNotifier.ACT_ANSWER -> {
                CallManager.answerRinging()
                runCatching { ctx.startActivity(Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            CallNotifier.ACT_DECLINE -> CallManager.rejectRinging()
            CallNotifier.ACT_HANGUP -> CallManager.hangupAll()
        }
    }
}

/** الخدمة التي يربطها النظام بالتطبيق عندما يكون الهاتف الافتراضي */
class FileHubInCallService : InCallService() {
    override fun onCreate() {
        super.onCreate()
        CallNotifier.ensureChannels(this)
        CallManager.service = this
        CallManager.onChanged = {
            CallNotifier.update(this, CallManager.ui.value)
            if (!CallManager.hasRinging()) Ringer.stop()
        }
    }

    override fun onCallAdded(call: Call) {
        CallManager.add(applicationContext, call)
        if (call.state == Call.STATE_RINGING) Ringer.start(this)
        // شاشة كاملة فوراً؛ والإشعار ذو fullScreenIntent احتياط لشاشة القفل
        runCatching { startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    override fun onCallRemoved(call: Call) {
        CallManager.remove(call)
        if (!CallManager.hasRinging()) Ringer.stop()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        CallManager.muted.value = audioState.isMuted
        CallManager.speaker.value = audioState.route == CallAudioState.ROUTE_SPEAKER
    }

    override fun onDestroy() {
        Ringer.stop(); CallManager.service = null; CallManager.onChanged = null
        CallNotifier.cancel(this)
        super.onDestroy()
    }
}

/** فحص المكالمة قبل الرنين: عدم الإزعاج. يُرفض صامتاً دون إشعار ويبقى في السجل */
class ScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        val incoming = android.os.Build.VERSION.SDK_INT < 29 || details.callDirection == Call.Details.DIRECTION_INCOMING
        val number = details.handle?.schemeSpecificPart
        val reject = incoming && PhoneRules.shouldReject(this, (application as FileApp).prefs, number)
        val resp = CallResponse.Builder().apply {
            if (reject) { setDisallowCall(true); setRejectCall(true); setSkipNotification(true) }
        }.build()
        respondToCall(details, resp)
    }
}
