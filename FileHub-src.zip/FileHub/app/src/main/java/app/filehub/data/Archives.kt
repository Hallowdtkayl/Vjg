package app.filehub.data

import com.github.junrar.Archive
import net.lingala.zip4j.ZipFile
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.io.IOException
import net.lingala.zip4j.exception.ZipException as Zip4jException

data class ArchiveEntry(val path: String, val name: String, val isDir: Boolean, val size: Long, val modified: Long)

/** محرك موحّد لفتح وفك zip (مع كلمة مرور/AES) و rar (4 و5) و 7z */
object Archives {
    val exts = setOf("zip", "rar", "7z")
    class NeedPassword(val wrong: Boolean = false) : Exception("password")

    private fun norm(p: String) = p.replace('\\', '/').removePrefix("./").trimStart('/').trimEnd('/')
    private fun wanted(sel: Set<String>?, path: String) = sel == null || sel.any { path == it || path.startsWith("$it/") }
    private fun safeTarget(dest: File, path: String): File {
        val t = File(dest, path)
        if (!t.canonicalPath.startsWith(dest.canonicalPath + File.separator)) throw IOException("مسار غير آمن داخل الأرشيف")
        return t
    }
    private fun entry(path: String, dir: Boolean, size: Long, time: Long) =
        ArchiveEntry(path, path.substringAfterLast('/'), dir, size, time)

    fun list(f: File, pw: String?): List<ArchiveEntry> = when (f.extension.lowercase()) {
        "zip" -> ZipFile(f).use { z ->
            z.charset = Charsets.UTF_8
            if (z.isEncrypted && pw == null) throw NeedPassword()
            z.fileHeaders.map { entry(norm(it.fileName), it.isDirectory, it.uncompressedSize, it.lastModifiedTimeEpoch) }
        }
        "rar" -> if (SevenZipJb.isRar5(f)) SevenZipJb.list(f, pw) else (if (pw != null) Archive(f, pw) else Archive(f)).use { a ->
            if (pw == null && a.fileHeaders.any { it.isEncrypted }) throw NeedPassword()
            a.fileHeaders.map { entry(norm(it.fileName), it.isDirectory, it.fullUnpackSize, it.mTime?.time ?: 0L) }
        }
        "7z" -> open7z(f, pw).use { sz ->
            sz.entries.map { entry(norm(it.name), it.isDirectory, it.size, if (it.hasLastModifiedDate) it.lastModifiedDate.time else 0L) }
        }
        else -> throw IOException("صيغة غير مدعومة")
    }.filter { it.path.isNotEmpty() }

    @Suppress("DEPRECATION")
    private fun open7z(f: File, pw: String?): SevenZFile = try {
        if (pw != null) SevenZFile(f, pw.toCharArray()) else SevenZFile(f)
    } catch (e: PasswordRequiredException) { throw NeedPassword(pw != null) }

    /** sel == null → فك الكل؛ وإلا فك المسارات المحددة (والمجلدات بكل محتوياتها) */
    fun extract(f: File, dest: File, sel: Set<String>?, pw: String?, progress: (Int, Int) -> Unit) {
        when (f.extension.lowercase()) {
            "zip" -> ZipFile(f).use { z ->
                z.charset = Charsets.UTF_8
                if (pw != null) z.setPassword(pw.toCharArray()) else if (z.isEncrypted) throw NeedPassword()
                val hs = z.fileHeaders
                hs.forEachIndexed { i, h ->
                    val path = norm(h.fileName)
                    if (path.isNotEmpty() && wanted(sel, path)) {
                        val t = safeTarget(dest, path)
                        if (h.isDirectory) t.mkdirs() else {
                            t.parentFile?.mkdirs()
                            try { z.getInputStream(h).use { ins -> t.outputStream().use { ins.copyTo(it) } } }
                            catch (e: Zip4jException) { if (e.type == Zip4jException.Type.WRONG_PASSWORD) throw NeedPassword(true) else throw e }
                            t.setLastModified(h.lastModifiedTimeEpoch)
                        }
                    }
                    progress(i + 1, hs.size)
                }
            }
            "rar" -> if (SevenZipJb.isRar5(f)) SevenZipJb.extract(f, dest, sel, pw, progress) else (if (pw != null) Archive(f, pw) else Archive(f)).use { a ->
                val hs = a.fileHeaders
                if (pw == null && hs.any { it.isEncrypted }) throw NeedPassword()
                hs.forEachIndexed { i, h ->
                    val path = norm(h.fileName)
                    if (path.isNotEmpty() && wanted(sel, path)) {
                        val t = safeTarget(dest, path)
                        if (h.isDirectory) t.mkdirs() else {
                            t.parentFile?.mkdirs()
                            try { t.outputStream().use { a.extractFile(h, it) } }
                            catch (e: IOException) { throw e }
                            catch (e: Exception) { if (pw != null && h.isEncrypted) throw NeedPassword(true) else throw IOException(e.message, e) }
                        }
                    }
                    progress(i + 1, hs.size)
                }
            }
            "7z" -> {
                val total = open7z(f, pw).use { it.entries.count() }
                open7z(f, pw).use { sz ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0
                    var e = sz.nextEntry
                    while (e != null) {
                        val path = norm(e.name)
                        if (path.isNotEmpty() && wanted(sel, path)) {
                            val t = safeTarget(dest, path)
                            if (e.isDirectory) t.mkdirs() else {
                                t.parentFile?.mkdirs()
                                t.outputStream().use { out ->
                                    var n = sz.read(buf)
                                    while (n > 0) { out.write(buf, 0, n); n = sz.read(buf) }
                                }
                            }
                        }
                        progress(++done, total)
                        e = sz.nextEntry
                    }
                }
            }
            else -> throw IOException("صيغة غير مدعومة")
        }
    }
}
