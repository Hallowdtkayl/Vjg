package app.filehub.ui.screens

import android.os.Environment
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.filehub.FileApp
import app.filehub.ui.readableDate
import app.filehub.ui.readableSize
import app.filehub.ui.viewers.TEXT_EXTS
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** مدخل محرر النصوص والأكواد: ملف جديد + آخر الملفات النصية على الجهاز */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorHubScreen(onBack: () -> Unit, onOpen: (String) -> Unit, onBrowse: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as FileApp
    val scope = rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }
    val files by produceState<List<app.filehub.model.FileItem>?>(null) {
        value = withContext(Dispatchers.IO) {
            runCatching { app.repo.scan(force = true).filter { it.ext in TEXT_EXTS }.sortedByDescending { it.modified }.take(80) }.getOrDefault(emptyList())
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("محرر النصوص والأكواد") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                actions = { IconButton(onBrowse) { Icon(Icons.Rounded.FolderOpen, "تصفح المستندات") } })
        },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { showNew = true }, icon = { Icon(Icons.Rounded.NoteAdd, null) }, text = { Text("ملف جديد") }) }
    ) { pad ->
        val l = files
        if (l == null) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator() }
        else LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
            item { Text("آخر الملفات النصية", Modifier.padding(20.dp, 12.dp, 20.dp, 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
            if (l.isEmpty()) item { Text("لا توجد ملفات نصية بعد. أنشئ ملفاً جديداً.", Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(l, key = { it.path }) { f ->
                ListItem({ Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${f.size.readableSize()} • ${f.modified.readableDate()} • ${File(f.path).parent.orEmpty().removePrefix("/storage/emulated/0")}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    leadingContent = { Icon(if (f.ext in setOf("txt", "md", "note")) Icons.Rounded.Description else Icons.Rounded.Code, null, tint = MaterialTheme.colorScheme.primary) },
                    modifier = Modifier.clickable { onOpen(f.path) })
            }
        }
    }
    if (showNew) {
        var name by remember { mutableStateOf("ملاحظة.txt") }
        AlertDialog({ showNew = false }, title = { Text("ملف جديد") },
            text = { Column { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("الاسم (مع الامتداد: .txt .kt .py …)") })
                Text("يُحفظ في FileHub/Notes", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)) } },
            confirmButton = { TextButton({
                val n = name.trim().let { if ('.' in it) it else "$it.txt" }
                if (n.isBlank() || '/' in n) return@TextButton
                showNew = false
                scope.launch {
                    val dir = File(Environment.getExternalStorageDirectory(), "FileHub/Notes").also { it.mkdirs() }
                    val r = runCatching { app.repo.mkfile(dir, n); File(dir, n).path }
                    r.onSuccess { onOpen(it) }.onFailure { Toast.makeText(ctx, it.message ?: "تعذّر الإنشاء", Toast.LENGTH_SHORT).show() }
                }
            }) { Text("إنشاء") } },
            dismissButton = { TextButton({ showNew = false }) { Text("إلغاء") } })
    }
}
