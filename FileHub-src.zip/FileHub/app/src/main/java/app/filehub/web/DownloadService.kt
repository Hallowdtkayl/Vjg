package app.filehub.web

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** خدمة أمامية تُبقي التنزيلات حيّة في الخلفية مع إشعار تقدّم (هيكل: المرحلة 2 تربطها بمحرّك التنزيل) */
class DownloadService : Service() {
    companion object { private const val CH = "web_downloads"; private const val ID = 52 }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CH, "تنزيلات المتصفح", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("التنزيلات").setContentText("جارٍ التحضير…").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(ID, n)
        // TODO(phase-2): تشغيل قائمة الانتظار (حد أقصى للتنزيلات المتوازية)، تحديث الإشعار، الإيقاف عند فراغ القائمة
        stopSelf(); return START_NOT_STICKY
    }
}
