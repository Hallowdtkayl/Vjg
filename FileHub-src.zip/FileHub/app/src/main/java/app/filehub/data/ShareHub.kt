package app.filehub.data

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RunInfo(val port: Int, val token: String)
data class HotspotInfo(val ssid: String, val password: String)
data class IpCandidate(val name: String, val ip: String) {
    val label: String get() = when {
        name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("swlan") -> "Wi-Fi / نقطة اتصال"
        name.startsWith("rndis") || name.startsWith("usb") -> "USB"
        name.startsWith("eth") -> "إيثرنت"
        else -> name
    }
}

/** حالة المشاركة المشتركة بين الواجهة والخدمة */
object ShareHub {
    val files = MutableStateFlow<List<String>>(emptyList())
    val running = MutableStateFlow<RunInfo?>(null)
    val hotspot = MutableStateFlow<HotspotInfo?>(null)
    val log = MutableStateFlow<List<String>>(emptyList())

    fun add(paths: List<String>) { files.update { (it + paths).distinct() } }
    fun remove(path: String) { files.update { it - path } }
    fun clear() { files.value = emptyList() }
    fun addLog(s: String) {
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        log.update { (listOf("$t  $s") + it).take(50) }
    }
}

object NetUtil {
    /** عناوين IPv4 المحلية القابلة للمشاركة (بدون بيانات الجوال والأنفاق) */
    fun candidates(): List<IpCandidate> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>()
                .filter { !it.isLoopbackAddress }.map { IpCandidate(ni.name, it.hostAddress ?: "") } }
            .filterNot { c -> listOf("rmnet", "ccmni", "v4-", "tun", "dummy", "clat").any { c.name.startsWith(it) } || c.ip.isEmpty() }
    }.getOrDefault(emptyList())
}

/** نقطة اتصال محلية (LocalOnlyHotspot): شبكة مؤقتة بلا إنترنت تكفي لنقل الملفات */
object Hotspot {
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    fun start(ctx: Context, onDone: (Result<HotspotInfo>) -> Unit) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r; onDone(runCatching { info(r) })
                }
                override fun onStopped() { reservation = null; ShareHub.hotspot.value = null }
                override fun onFailed(reason: Int) {
                    onDone(Result.failure(IllegalStateException(when (reason) {
                        ERROR_INCOMPATIBLE_MODE -> "نقطة الاتصال العادية أو الربط مفعّل حالياً، أوقفه أولاً أو استخدمه مباشرة"
                        ERROR_TETHERING_DISALLOWED -> "الجهاز لا يسمح بإنشاء نقطة اتصال"
                        ERROR_NO_CHANNEL -> "لا توجد قناة متاحة، فعّل Wi-Fi وحاول ثانية"
                        else -> "تعذّر الإنشاء. تأكد من تشغيل Wi-Fi والموقع (GPS)"
                    })))
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            onDone(Result.failure(IllegalStateException("الصلاحية مفقودة أو الموقع (GPS) مغلق")))
        } catch (e: Exception) { onDone(Result.failure(e)) }
    }

    @Suppress("DEPRECATION")
    private fun info(r: WifiManager.LocalOnlyHotspotReservation): HotspotInfo =
        if (Build.VERSION.SDK_INT >= 30) {
            val c = r.softApConfiguration
            val ssid = if (Build.VERSION.SDK_INT >= 33) c.wifiSsid?.toString()?.trim('"') else c.ssid
            HotspotInfo(ssid.orEmpty(), c.passphrase.orEmpty())
        } else {
            val c = r.wifiConfiguration
            HotspotInfo(c?.SSID.orEmpty().trim('"'), c?.preSharedKey.orEmpty().trim('"'))
        }

    fun stop() { reservation?.close(); reservation = null; ShareHub.hotspot.value = null }
}
