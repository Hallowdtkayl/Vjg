package app.filehub

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.IntentCompat
import app.filehub.clock.Alarm
import app.filehub.clock.ClockModel
import app.filehub.incoming.IncomingHub
import app.filehub.ui.AppRoot
import app.filehub.ui.theme.FileHubTheme

class MainActivity : ComponentActivity() {
    /** مسار داخلي يُفتح عند وصول نية خارجية: اتصال، رسالة، ملف، مشاركة، منبه… */
    private var deepLink by mutableStateOf<String?>(null)

    private fun uriArg(s: String?) = Uri.encode(s.orEmpty())

    /** يرجع true إذا كانت النية «صامتة» (EXTRA_SKIP_UI) ولا تحتاج عرض الواجهة */
    private fun handle(i: Intent?): Boolean {
        i ?: return false
        val d = i.data
        val cats = i.categories.orEmpty()
        when {
            i.action == "app.filehub.OPEN_CLOCK" -> deepLink = "clock"
            i.action == "app.filehub.OPEN_THREAD" -> deepLink = "thread?id=${i.getLongExtra("thread", -1)}&address=${uriArg(i.getStringExtra("address"))}"

            // ───── الساعة: تعمل مع المساعدات الصوتية وتطبيقات أخرى ─────
            i.action == AlarmClock.ACTION_SET_ALARM -> return setAlarm(i)
            i.action == AlarmClock.ACTION_SET_TIMER -> return setTimer(i)
            i.action == AlarmClock.ACTION_SHOW_ALARMS || i.action == AlarmClock.ACTION_SHOW_TIMERS -> deepLink = "clock"

            // ───── الهاتف والرسائل ─────
            (i.action == Intent.ACTION_DIAL || i.action == Intent.ACTION_VIEW) && (d == null || d.scheme == "tel") ->
                deepLink = "dialer?number=${uriArg(d?.schemeSpecificPart?.let { Uri.decode(it) })}"
            (i.action == Intent.ACTION_SENDTO || i.action == Intent.ACTION_VIEW) && d?.scheme in setOf("sms", "smsto", "mms", "mmsto") -> {
                val addr = Uri.decode(d?.schemeSpecificPart.orEmpty()).substringBefore(',').substringBefore(';')
                val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
                deepLink = "thread?id=-1&address=${uriArg(addr)}&body=${uriArg(body)}"
            }

            // ───── إنشاء جهة اتصال من تطبيق آخر ─────
            (i.action == Intent.ACTION_INSERT || i.action == Intent.ACTION_INSERT_OR_EDIT) && i.type?.contains("contact") == true || i.type?.contains("person") == true && i.action == Intent.ACTION_INSERT ->
                deepLink = "contactedit?id=-1&number=${uriArg(i.getStringExtra(ContactsContract.Intents.Insert.PHONE))}" +
                    "&name=${uriArg(i.getStringExtra(ContactsContract.Intents.Insert.NAME))}&email=${uriArg(i.getStringExtra(ContactsContract.Intents.Insert.EMAIL))}"

            // ───── مشاركة إلينا: ملفات → نقطة QR، نص → ملاحظة في المحرر ─────
            i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE -> {
                val uris = buildList {
                    IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { add(it) }
                    IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { addAll(it) }
                    if (isEmpty()) i.clipData?.let { c -> (0 until c.itemCount).forEach { n -> c.getItemAt(n).uri?.let { u -> add(u) } } }
                }.distinct()
                val text = i.getStringExtra(Intent.EXTRA_TEXT)
                if (uris.isNotEmpty()) { IncomingHub.set(uris, i.type); deepLink = "sharein" }
                else if (!text.isNullOrBlank()) { IncomingHub.set(emptyList(), "text/plain", text); deepLink = "incoming" }
            }

            // ───── المتصفح: روابط الويب وبحث الويب ─────
            i.action == Intent.ACTION_VIEW && (d?.scheme == "http" || d?.scheme == "https") -> deepLink = "web?url=${uriArg(d.toString())}"
            i.action == Intent.ACTION_WEB_SEARCH -> deepLink = "web?url=${uriArg(app.filehub.web.WebEngine.resolveInput(i.getStringExtra(android.app.SearchManager.QUERY).orEmpty()))}"

            // ───── فتح/تعديل ملف قادم من تطبيق آخر ─────
            (i.action == Intent.ACTION_VIEW || i.action == Intent.ACTION_EDIT) && d != null -> { IncomingHub.set(listOf(d), i.type); deepLink = "incoming" }

            // ───── أيقونات الفئات (معرض، موسيقى، حاسبة…) ─────
            i.action == Intent.ACTION_MAIN -> when {
                Intent.CATEGORY_APP_GALLERY in cats -> deepLink = "cat/images"
                Intent.CATEGORY_APP_MUSIC in cats -> deepLink = "cat/audio"
                Intent.CATEGORY_APP_CALCULATOR in cats -> deepLink = "calculator"
                Intent.CATEGORY_APP_MESSAGING in cats -> deepLink = "messages"
                Intent.CATEGORY_APP_CONTACTS in cats -> deepLink = "contacts"
                Intent.CATEGORY_APP_BROWSER in cats -> deepLink = "web"
            }
        }
        return false
    }

    private fun setAlarm(i: Intent): Boolean {
        val h = i.getIntExtra(AlarmClock.EXTRA_HOUR, -1); val m = i.getIntExtra(AlarmClock.EXTRA_MINUTES, 0)
        if (h !in 0..23 || m !in 0..59) { deepLink = "clock"; return false }
        var mask = 0
        i.getIntegerArrayListExtra(AlarmClock.EXTRA_DAYS)?.forEach { if (it in 1..7) mask = mask or (1 shl (it - 1)) }
        ClockModel.saveAlarm(this, Alarm(0, h, m, i.getStringExtra(AlarmClock.EXTRA_MESSAGE).orEmpty(), true, mask,
            i.getStringExtra(AlarmClock.EXTRA_RINGTONE)?.takeIf { it != AlarmClock.VALUE_RINGTONE_SILENT },
            i.getBooleanExtra(AlarmClock.EXTRA_VIBRATE, true)))
        val skip = i.getBooleanExtra(AlarmClock.EXTRA_SKIP_UI, false)
        if (skip) Toast.makeText(this, "تم ضبط المنبه %02d:%02d".format(h, m), Toast.LENGTH_SHORT).show() else deepLink = "clock"
        return skip
    }

    private fun setTimer(i: Intent): Boolean {
        val len = i.getIntExtra(AlarmClock.EXTRA_LENGTH, 0)
        if (len !in 1..86_400) { deepLink = "clock"; return false }
        ClockModel.addTimer(this, len * 1000L, i.getStringExtra(AlarmClock.EXTRA_MESSAGE).orEmpty(), true)
        val skip = i.getBooleanExtra(AlarmClock.EXTRA_SKIP_UI, false)
        if (skip) Toast.makeText(this, "بدأ المؤقّت", Toast.LENGTH_SHORT).show() else deepLink = "clock"
        return skip
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        if (handle(intent)) moveTaskToBack(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (handle(intent)) { finish(); return }
        enableEdgeToEdge()
        setContent {
            val st = (application as FileApp).settings
            val sys = isSystemInDarkTheme()
            val dark = when (st.theme) { 1 -> false; 2 -> true; else -> sys }
            FileHubTheme(dark) { AppRoot(deepLink) { deepLink = null } }
        }
    }
}
