package app.filehub.ui.viewers

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import app.filehub.data.PlaybackService
import app.filehub.model.FileTypes
import app.filehub.ui.components.IconBadge
import app.filehub.ui.screens.openExternal
import kotlinx.coroutines.delay
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

/** صيغ لا يدعمها ExoPlayer جيداً → تذهب مباشرة إلى محرك VLC (المبني على FFmpeg) */
private val VLC_FIRST = setOf("avi", "wmv", "mpg", "mpeg", "flv", "rmvb", "asf", "divx", "vob", "wma", "ape")

private enum class Engine { Exo, Vlc }

/** يختار المحرك: ExoPlayer أولاً (أخف)، وإن فشل التشغيل ننتقل تلقائياً إلى VLC */
@Composable
fun MediaViewer(path: String, onBack: () -> Unit) {
    val file = File(path)
    val ext = file.extension.lowercase()
    var engine by remember { mutableStateOf(if (ext in VLC_FIRST) Engine.Vlc else Engine.Exo) }
    when {
        engine == Engine.Vlc -> VlcViewer(path, onBack)
        ext in FileTypes.audio -> AudioViewer(path, onBack) { engine = Engine.Vlc }
        else -> VideoViewer(path, onBack) { engine = Engine.Vlc }
    }
}

private fun siblingsAudio(file: File): List<File> =
    file.parentFile?.listFiles()?.filter { it.isFile && it.extension.lowercase() in FileTypes.audio }
        ?.sortedBy { it.name.lowercase() }.orEmpty().ifEmpty { listOf(file) }

// ───────────────────────── فيديو (ExoPlayer) ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VideoViewer(path: String, onBack: () -> Unit, onFail: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(path)
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(path) {
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        val l = object : Player.Listener { override fun onPlayerError(e: PlaybackException) { onFail() } }
        player.addListener(l); player.prepare(); player.playWhenReady = true
        onDispose { player.removeListener(l); player.release() }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { player.pause() }
    Scaffold(containerColor = Color.Black, topBar = {
        TopAppBar(title = { Text(file.name, maxLines = 1) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White))
    }) { pad ->
        AndroidView({ c -> PlayerView(c).apply { this.player = player; useController = true } }, Modifier.fillMaxSize().padding(pad))
    }
}

// ───────────────────────── صوت (خدمة خلفية) ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AudioViewer(path: String, onBack: () -> Unit, onFail: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(path)
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var title by remember { mutableStateOf(file.nameWithoutExtension) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    DisposableEffect(path) {
        val future = MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        var listener: Player.Listener? = null
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            val l = object : Player.Listener {
                override fun onMediaItemTransition(item: MediaItem?, reason: Int) { item?.mediaMetadata?.title?.let { title = it.toString() } }
                override fun onPlayerError(e: PlaybackException) { c.clearMediaItems(); onFail() }
            }
            listener = l; c.addListener(l)
            if (c.currentMediaItem?.mediaId != path) {   // لا نعيد التشغيل إن كان الملف نفسه يعمل
                val items = siblingsAudio(file)
                c.setMediaItems(items.map {
                    MediaItem.Builder().setUri(Uri.fromFile(it)).setMediaId(it.path)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(it.nameWithoutExtension).build()).build()
                }, items.indexOfFirst { it.path == path }.coerceAtLeast(0), 0L)
                c.prepare()
            }
            c.play()
            c.currentMediaItem?.mediaMetadata?.title?.let { title = it.toString() }
        }, ContextCompat.getMainExecutor(ctx))
        // نحرّر الاتصال فقط؛ الخدمة تواصل التشغيل في الخلفية
        onDispose { listener?.let { controller?.removeListener(it) }; MediaController.releaseFuture(future) }
    }
    Scaffold(topBar = {
        TopAppBar(title = { Text("تشغيل الصوت", maxLines = 1) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Column(Modifier.weight(1f).fillMaxWidth(), Arrangement.Center, Alignment.CenterHorizontally) {
                IconBadge(Icons.Rounded.MusicNote, MaterialTheme.colorScheme.primary, 140)
                Spacer(Modifier.height(16.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                Text("يستمر التشغيل عند الخروج، والتحكم من الإشعار", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            AndroidView({ c -> PlayerView(c).apply { useController = true; controllerShowTimeoutMs = 0; controllerHideOnTouch = false } },
                Modifier.fillMaxWidth().height(220.dp), update = { it.player = controller })
        }
    }
}

// ───────────────────────── VLC (AVI وغيره) ─────────────────────────
private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VlcViewer(path: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(path)
    val isAudio = file.extension.lowercase() in FileTypes.audio
    val vlc = remember { LibVLC(ctx, arrayListOf("--no-drop-late-frames", "--no-skip-frames")) }
    val player = remember { MediaPlayer(vlc) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableFloatStateOf(0f) }
    var seeking by remember { mutableStateOf(false) }
    var time by remember { mutableLongStateOf(0L) }
    var len by remember { mutableLongStateOf(0L) }
    var failed by remember { mutableStateOf(false) }

    DisposableEffect(path) {
        player.setEventListener { ev -> if (ev.type == MediaPlayer.Event.EncounteredError) failed = true }
        val media = Media(vlc, Uri.fromFile(file)).apply { setHWDecoderEnabled(true, false) }
        player.media = media; media.release(); player.play()
        onDispose { player.setEventListener(null); player.stop(); player.detachViews(); player.release(); vlc.release() }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { if (!isAudio) player.pause() }
    LaunchedEffect(Unit) {
        while (true) {
            delay(400)
            len = player.length; time = player.time; playing = player.isPlaying
            if (!seeking) pos = player.position
        }
    }

    Scaffold(containerColor = Color.Black, topBar = {
        TopAppBar(title = { Text(file.name, maxLines = 1) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White, navigationIconContentColor = Color.White))
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView({ c -> VLCVideoLayout(c).also { player.attachViews(it, null, false, false) } }, Modifier.fillMaxSize())
                if (isAudio) Box(Modifier.align(Alignment.Center)) { IconBadge(Icons.Rounded.MusicNote, Color.White, 120) }
                if (failed) Column(Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = .85f)).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("تعذّر تشغيل هذا الملف", color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Button({ openExternal(ctx, path) {} }) { Text("فتح بتطبيق آخر") }
                }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF111111)).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ if (player.isPlaying) player.pause() else player.play() }) {
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "تشغيل/إيقاف", tint = Color.White)
                }
                Text(fmt(time), color = Color.White, style = MaterialTheme.typography.labelMedium)
                Slider(pos, { seeking = true; pos = it }, Modifier.weight(1f).padding(horizontal = 8.dp),
                    onValueChangeFinished = { player.position = pos; seeking = false })
                Text(fmt(len), color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
