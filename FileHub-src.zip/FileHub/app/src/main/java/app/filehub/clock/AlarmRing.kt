package app.filehub.clock

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import app.filehub.ui.theme.FileHubTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Ring(val kind: String, val id: Int, val label: String, val hour: Int, val minute: Int, val snoozeMin: Int, val ringtone: String?, val vibrate: Boolean) {
    fun toExtras() = Bundle().apply {
        putString("kind", kind); putInt("id", id); putString("label", label); putInt("h", hour); putInt("m", minute)
        putInt("snooze", snoozeMin); putString("tone", ringtone); putBoolean("vib", vibrate)
    }
    companion object {
        fun from(i: Intent) = Ring(i.getStringExtra("kind") ?: "alarm", i.getIntExtra("id", 0), i.getStringExtra("label").orEmpty(),
            i.getIntExtra("h", 0), i.getIntExtra("m", 0), i.getIntExtra("snooze", 10), i.getStringExtra("tone"), i.getBooleanExtra("vib", true))
    }
}

object RingState { val current = MutableStateFlow<Ring?>(null) }

/** يشغّل الصوت والاهتزاز كخدمة أمامية، فلا يقتله النظام ويرنّ حتى مع إغلاق الشاشة */
class AlarmRingService : Service() {
    companion object {
        const val ACT_RING = "app.filehub.RING"
        const val ACT_DISMISS = "app.filehub.RING_DISMISS"
        const val ACT_SNOOZE = "app.filehub.RING_SNOOZE"
        const val ACT_PLUS1 = "app.filehub.RING_PLUS1"
        private const val CH = "alarm_ring"
        private const val ID = 31
        private const val MAX_RING_MS = 10 * 60_000L
    }

    private var player: MediaPlayer? = null
    private var vib: Vibrator? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_DISMISS -> stopRing()
            ACT_SNOOZE -> { RingState.current.value?.let { if (it.kind == "alarm") AlarmScheduler.snooze(this, it.id, it.snoozeMin) }; stopRing() }
            ACT_PLUS1 -> { RingState.current.value?.let { if (it.kind == "timer") ClockModel.restartTimer(this, it.id, 60_000) }; stopRing() }
            else -> intent?.let { startRing(Ring.from(it)) } ?: stopRing()
        }
        return START_NOT_STICKY
    }

    private fun action(code: Int, a: String) = PendingIntent.getService(this, code, Intent(this, AlarmRingService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)

    private fun startRing(r: Ring) {
        RingState.current.value = r
        ClockNotifier.channel(this, CH, "رنين المنبه", NotificationManager.IMPORTANCE_HIGH)
        val ui = PendingIntent.getActivity(this, 0, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(r.label)
            .setContentText(if (r.kind == "alarm") "%02d:%02d".format(r.hour, r.minute) else "انتهى الوقت")
            .setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX).setOngoing(true)
            .setContentIntent(ui).setFullScreenIntent(ui, true)
        if (r.kind == "alarm") b.addAction(0, "غفوة ${r.snoozeMin} د", action(1, ACT_SNOOZE)) else b.addAction(0, "+1 د", action(3, ACT_PLUS1))
        b.addAction(0, "إيقاف", action(2, ACT_DISMISS))
        val n: Notification = b.build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(ID, n)

        wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "filehub:alarm").apply { acquire(MAX_RING_MS + 10_000) }
        playSound(r)
        if (r.vibrate) vib = getSystemService(Vibrator::class.java)?.also { it.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0)) }
        runCatching { startActivity(Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ if (r.kind == "alarm") ClockNotifier.timerDone(this, "منبه فائت: ${r.label}"); stopRing() }, MAX_RING_MS)
    }

    private fun playSound(r: Ring) {
        val candidates = listOfNotNull(r.ringtone?.let(Uri::parse), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
        for (uri in candidates) {
            val p = runCatching {
                MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    setDataSource(this@AlarmRingService, uri); isLooping = true; prepare(); setVolume(0.15f, 0.15f); start()
                }
            }.getOrNull() ?: continue
            player = p
            var v = 0.15f      // ارتفاع تدريجي للصوت
            handler.post(object : Runnable { override fun run() { v = (v + 0.06f).coerceAtMost(1f); runCatching { p.setVolume(v, v) }; if (v < 1f) handler.postDelayed(this, 1000) } })
            return
        }
    }

    private fun stopRing() {
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop(); player?.release() }; player = null
        runCatching { vib?.cancel() }; vib = null
        runCatching { wake?.let { if (it.isHeld) it.release() } }; wake = null
        RingState.current.value = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); runCatching { player?.release() }; vib?.cancel(); super.onDestroy() }
}

class AlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else @Suppress("DEPRECATION") window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { FileHubTheme(dark = true) { RingScreen { finish() } } }
    }
    private fun send(a: String) = startService(Intent(this, AlarmRingService::class.java).setAction(a))

    @Composable
    private fun RingScreen(onDone: () -> Unit) {
        val ring by RingState.current.collectAsState()
        var seen by remember { mutableStateOf(false) }
        LaunchedEffect(ring) { if (ring != null) seen = true else { delay(if (seen) 200 else 1500); if (RingState.current.value == null) onDone() } }
        val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B2250), Color(0xFF0B0D17))))) {
            val r = ring ?: return@Box
            Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(96.dp))
                Text(if (r.kind == "alarm") "المنبه" else "المؤقّت", color = Color.White.copy(alpha = .7f), fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)), color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Light)
                Text(r.label, color = Color.White, fontSize = 26.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
                Spacer(Modifier.weight(1f))
                if (r.kind == "alarm") OutlinedButton({ send(AlarmRingService.ACT_SNOOZE) }, Modifier.fillMaxWidth().height(60.dp)) { Text("غفوة ${r.snoozeMin} دقائق", color = Color.White, fontSize = 18.sp) }
                else OutlinedButton({ send(AlarmRingService.ACT_PLUS1) }, Modifier.fillMaxWidth().height(60.dp)) { Text("+1 دقيقة", color = Color.White, fontSize = 18.sp) }
                Spacer(Modifier.height(16.dp))
                Button({ send(AlarmRingService.ACT_DISMISS) }, Modifier.fillMaxWidth().height(72.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                    Text("إيقاف", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(48.dp))
            }
        }
    }
}
