package app.filehub.data

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import app.filehub.model.FileItem
import app.filehub.model.StorageVolume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import android.os.storage.StorageVolume as SysVolume

class FileRepository(private val ctx: Context) {
    companion object {
        const val TRASH = ".filehub_trash"
        private const val DAY = 86_400_000L
    }

    @Volatile private var cache: List<FileItem>? = null
    fun invalidate() { cache = null }

    // ───────── وحدات التخزين (داخلية / بطاقة / USB) ─────────
    fun volumes(): List<StorageVolume> {
        val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        return sm.storageVolumes.filter { it.state == Environment.MEDIA_MOUNTED }.mapNotNull { sv ->
            val dir = dirOf(sv) ?: return@mapNotNull null
            val desc = sv.getDescription(ctx)
            val kind = when {
                sv.isPrimary -> StorageVolume.Kind.Internal
                desc.contains("usb", true) -> StorageVolume.Kind.Usb
                else -> StorageVolume.Kind.SdCard
            }
            StorageVolume(desc, kind, dir.absolutePath, dir.totalSpace - dir.freeSpace, dir.totalSpace)
        }
    }

    private fun dirOf(sv: SysVolume): File? =
        if (Build.VERSION.SDK_INT >= 30) sv.directory
        else runCatching { File(SysVolume::class.java.getMethod("getPath").invoke(sv) as String) }.getOrNull()

    private fun File.toItem() = FileItem(
        name, absolutePath, isDirectory, if (isDirectory) 0 else length(), lastModified(), extension.lowercase()
    )

    // ───────── قراءة مجلد حقيقي ─────────
    suspend fun list(dir: File, showHidden: Boolean): List<FileItem> = withContext(Dispatchers.IO) {
        dir.listFiles().orEmpty()
            .filter { it.name != TRASH && (showHidden || !it.name.startsWith(".")) }
            .map { it.toItem() }
    }

    // ───────── مسح كامل لكل الوحدات (أساس التصنيفات) ─────────
    suspend fun scan(force: Boolean = false, showHidden: Boolean = false): List<FileItem> =
        withContext(Dispatchers.IO) {
            if (!force) cache?.let { return@withContext it }
            val out = ArrayList<FileItem>(4096)
            volumes().forEach { walk(File(it.root), 0, out, showHidden) }
            cache = out
            out
        }

    private fun walk(dir: File, depth: Int, out: MutableList<FileItem>, hidden: Boolean) {
        if (depth > 25) return
        val children = dir.listFiles() ?: return
        for (f in children) {
            val n = f.name
            if (n == TRASH || (!hidden && n.startsWith("."))) continue
            if (f.isDirectory) {
                if (depth == 0 && n == "Android") continue   // بيانات التطبيقات
                walk(f, depth + 1, out, hidden)
            } else out.add(f.toItem())
        }
    }

    // ───────── عمليات الملفات ─────────
    private fun unique(dir: File, name: String): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (true) {
            t = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
            if (!t.exists()) return t
            i++
        }
    }

    private fun copyTo(src: File, target: File) {
        if (src.isDirectory) src.copyRecursively(target) else src.copyTo(target)
    }

    private fun moveTo(src: File, target: File) {
        if (!src.renameTo(target)) { copyTo(src, target); src.deleteRecursively() }
    }

    suspend fun paste(paths: List<String>, dest: File, cut: Boolean) = withContext(Dispatchers.IO) {
        for (p in paths) {
            val src = File(p)
            if (src.isDirectory && (dest.absolutePath + "/").startsWith(src.absolutePath + "/"))
                throw IOException("لا يمكن نسخ مجلد داخل نفسه")
            if (cut && src.parentFile?.absolutePath == dest.absolutePath) continue
            val target = unique(dest, src.name)
            if (cut) moveTo(src, target) else copyTo(src, target)
        }
        invalidate()
    }

    suspend fun rename(f: File, newName: String) = withContext(Dispatchers.IO) {
        val t = File(f.parentFile, newName)
        if (t.exists()) throw IOException("الاسم مستخدم مسبقاً")
        if (!f.renameTo(t)) throw IOException("تعذّرت إعادة التسمية")
        invalidate()
    }

    suspend fun mkdir(parent: File, name: String) = withContext(Dispatchers.IO) {
        val t = File(parent, name)
        if (t.exists()) throw IOException("المجلد موجود مسبقاً")
        if (!t.mkdirs()) throw IOException("تعذّر إنشاء المجلد")
    }

    suspend fun createFile(parent: File, name: String) = withContext(Dispatchers.IO) {
        val t = File(parent, name)
        if (t.exists()) throw IOException("الملف موجود مسبقاً")
        if (!t.createNewFile()) throw IOException("تعذّر إنشاء الملف")
        invalidate()
    }

    suspend fun mkfile(parent: File, name: String) = withContext(Dispatchers.IO) {
        val t = File(parent, name)
        if (t.exists()) throw IOException("الملف موجود مسبقاً")
        if (!t.createNewFile()) throw IOException("تعذّر إنشاء الملف")
        invalidate()
    }

    // ───────── سلة المحذوفات (مجلد مخفي في كل وحدة + فهرس JSON) ─────────
    private fun trashDirFor(f: File): File {
        val root = volumes().map { File(it.root) }
            .firstOrNull { f.absolutePath.startsWith(it.absolutePath + "/") }
            ?: Environment.getExternalStorageDirectory()
        return File(root, TRASH).also { it.mkdirs(); File(it, ".nomedia").createNewFile() }
    }

    private fun readIndex(td: File): JSONObject =
        runCatching { JSONObject(File(td, "index.json").readText()) }.getOrDefault(JSONObject())

    private fun writeIndex(td: File, o: JSONObject) = File(td, "index.json").writeText(o.toString())

    suspend fun moveToTrash(files: List<File>) = withContext(Dispatchers.IO) {
        files.forEach { f ->
            val td = trashDirFor(f)
            val idx = readIndex(td)
            val key = "${System.currentTimeMillis()}_${f.name}"
            moveTo(f, File(td, key))
            idx.put(key, JSONObject().put("orig", f.absolutePath).put("ts", System.currentTimeMillis()))
            writeIndex(td, idx)
        }
        invalidate()
    }

    suspend fun listTrash(): List<FileItem> = withContext(Dispatchers.IO) {
        val out = mutableListOf<FileItem>()
        val days = ctx.getSharedPreferences("view_prefs", Context.MODE_PRIVATE).getInt("trash_days", 30)
        val limit = System.currentTimeMillis() - days * DAY
        volumes().forEach { v ->
            val td = File(v.root, TRASH)
            if (!td.isDirectory) return@forEach
            val idx = readIndex(td)
            var changed = false
            for (key in idx.keys().asSequence().toList()) {
                val f = File(td, key)
                val o = idx.getJSONObject(key)
                val ts = o.getLong("ts")
                if (!f.exists()) { idx.remove(key); changed = true; continue }
                if (ts < limit) { f.deleteRecursively(); idx.remove(key); changed = true; continue }
                val orig = o.getString("orig")
                val name = File(orig).name
                val size = if (f.isDirectory) f.walkTopDown().sumOf { if (it.isFile) it.length() else 0L } else f.length()
                out += FileItem(name, f.absolutePath, f.isDirectory, size, ts, File(name).extension.lowercase(), original = orig)
            }
            if (changed) writeIndex(td, idx)
        }
        out
    }

    private fun dropFromIndex(item: FileItem) {
        val f = File(item.path); val td = f.parentFile ?: return
        val idx = readIndex(td); idx.remove(f.name); writeIndex(td, idx)
    }

    suspend fun restore(items: List<FileItem>) = withContext(Dispatchers.IO) {
        items.forEach { it ->
            val orig = File(it.original ?: return@forEach)
            orig.parentFile?.mkdirs()
            moveTo(File(it.path), unique(orig.parentFile ?: return@forEach, orig.name))
            dropFromIndex(it)
        }
        invalidate()
    }

    suspend fun deleteForever(items: List<FileItem>) = withContext(Dispatchers.IO) {
        items.forEach { File(it.path).deleteRecursively(); dropFromIndex(it) }
    }

    suspend fun emptyTrash() = withContext(Dispatchers.IO) {
        volumes().forEach { File(it.root, TRASH).deleteRecursively() }
    }
}
