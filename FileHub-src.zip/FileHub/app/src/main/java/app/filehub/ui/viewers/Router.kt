package app.filehub.ui.viewers

import android.net.Uri
import app.filehub.data.Archives
import app.filehub.model.FileTypes
import java.io.File

/** نصوص وأكواد تُفتح في المحرر الداخلي */
val TEXT_EXTS = setOf(
    "txt", "note", "md", "json", "xml", "csv", "log", "html", "htm", "ini", "conf", "cfg", "yml", "yaml", "toml",
    "srt", "sh", "bat", "properties", "gradle", "java", "kt", "kts", "py", "js", "jsx", "tsx", "css", "scss",
    "c", "cpp", "h", "hpp", "cs", "go", "rs", "php", "rb", "swift", "sql", "lua", "dart", "vue", "tex", "env"
)
/** مستندات Office: تُفتح بتطبيق خارجي ليبقى التنسيق الأصلي كاملاً */
val OFFICE_EXTS = setOf("doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf")

/** الشاشة الداخلية المناسبة للملف، أو null ليُفتح بتطبيق خارجي */
fun routeFor(path: String): String? {
    val ext = File(path).extension.lowercase()
    val e = Uri.encode(path)
    return when {
        ext in Archives.exts -> "archive?path=$e"
        ext in FileTypes.images && ext != "svg" -> "view/image?path=$e"
        ext in FileTypes.videos || ext in FileTypes.audio -> "view/media?path=$e"
        ext == "pdf" -> "view/pdf?path=$e"
        ext in TEXT_EXTS -> "view/text?path=$e"
        else -> null
    }
}
