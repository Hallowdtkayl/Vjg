package app.filehub.clock

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.filehub.FileApp
import app.filehub.MainActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** days: قناع بتات؛ البت (dow-1) حيث dow من Calendar (1=الأحد … 7=السبت). 0 = مرة واحدة */
data class Alarm(val id: Int, val hour: Int, val minute: Int, val label: String = "", val enabled: Boolean = true,
                 val days: Int = 0, val ringtone: String? = null, val vibrate: Boolean = true, val snoozeMin: Int = 10)

data class TimerItem(val id: Int, val label: String, val durationMs: Long, val endAt: Long = 0L, val remainingMs: Long = durationMs) {
    val running get() = endAt > 0
}

private fun prefs(ctx: Context) = (ctx.applicationContext as FileApp).prefs

object ClockStore {
    private fun Alarm.json() = JSONObject().put("id", id).put("h", hour).put("m", minute).put("label", label).put("on", enabled)
        .put("days", days).put("tone", ringtone ?: JSONObject.NULL).put("vib", vibrate).put("snooze", snoozeMin)
    private fun JSONObject.alarm() = Alarm(getInt("id"), getInt("h"), getInt("m"), optString("label", ""), optBoolean("on", true),
        optInt("days", 0), if (isNull("tone")) null else getString("tone"), optBoolean("vib", true), optInt("snooze", 10))
    private fun TimerItem.json() = JSONObject().put("id", id).put("label", label).put("dur", durationMs).put("end", endAt).put("rem", remainingMs)
    private fun JSONObject.timer() = TimerItem(getInt("id"), optString("label", ""), getLong("dur"), optLong("end", 0), optLong("rem", getLong("dur")))

    fun alarms(ctx: Context): List<Alarm> = runCatching {
        JSONArray(prefs(ctx).rawGet("alarms") ?: "[]").let { a -> (0 until a.length()).map { a.getJSONObject(it).alarm() } }
    }.getOrDefault(emptyList())
    fun saveAlarms(ctx: Context, l: List<Alarm>) = prefs(ctx).rawPut("alarms", JSONArray(l.map { it.json() }).toString())
    fun timers(ctx: Context): List<TimerItem> = runCatching {
        JSONArray(prefs(ctx).rawGet("timers") ?: "[]").let { a -> (0 until a.length()).map { a.getJSONObject(it).timer() } }
    }.getOrDefault(emptyList())
    fun saveTimers(ctx: Context, l: List<TimerItem>) = prefs(ctx).rawPut("timers", JSONArray(l.map { it.json() }).toString())
}

/** الجدولة عبر setAlarmClock: دقيقة، تعمل مع Doze، ولا تحتاج إذن «المنبّهات الدقيقة» */
object AlarmScheduler {
    const val ACTION = "app.filehub.CLOCK_FIRE"

    fun nextTrigger(a: Alarm, now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now; set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (a.days == 0) { if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1); return c.timeInMillis }
        repeat(8) {
            if (((a.days shr (c.get(Calendar.DAY_OF_WEEK) - 1)) and 1) == 1 && c.timeInMillis > now) return c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }

    private fun fire(ctx: Context, kind: String, id: Int) = PendingIntent.getBroadcast(ctx, 0,
        Intent(ctx, AlarmReceiver::class.java).setAction(ACTION).setData(Uri.parse("filehub://clock/$kind/$id")).putExtra("kind", kind).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun show(ctx: Context) = PendingIntent.getActivity(ctx, 0,
        Intent(ctx, MainActivity::class.java).setAction("app.filehub.OPEN_CLOCK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun set(ctx: Context, at: Long, kind: String, id: Int) =
        ctx.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show(ctx)), fire(ctx, kind, id))
    private fun cancel(ctx: Context, kind: String, id: Int) { ctx.getSystemService(AlarmManager::class.java).cancel(fire(ctx, kind, id)) }

    fun schedule(ctx: Context, a: Alarm) { if (a.enabled) set(ctx, nextTrigger(a), "alarm", a.id) else cancel(ctx, "alarm", a.id) }
    fun cancelAlarm(ctx: Context, id: Int) { cancel(ctx, "alarm", id); cancel(ctx, "snooze", id) }
    fun snooze(ctx: Context, alarmId: Int, minutes: Int) = set(ctx, System.currentTimeMillis() + minutes * 60_000L, "snooze", alarmId)
    fun scheduleTimer(ctx: Context, t: TimerItem) = set(ctx, t.endAt, "timer", t.id)
    fun cancelTimer(ctx: Context, id: Int) = cancel(ctx, "timer", id)

    fun rescheduleAll(ctx: Context) {
        ClockStore.alarms(ctx).forEach { schedule(ctx, it) }
        val now = System.currentTimeMillis()
        val fixed = ClockStore.timers(ctx).map { t ->
            if (!t.running) t
            else if (t.endAt > now) { scheduleTimer(ctx, t); t }
            else { ClockNotifier.timerDone(ctx, t.label); t.copy(endAt = 0, remainingMs = t.durationMs) }   // انتهى أثناء إيقاف الجهاز
        }
        ClockStore.saveTimers(ctx, fixed)
        ClockModel.load(ctx)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != AlarmScheduler.ACTION) return
        val id = i.getIntExtra("id", -1)
        val ring: Ring = when (i.getStringExtra("kind")) {
            "alarm", "snooze" -> {
                val a = ClockStore.alarms(ctx).firstOrNull { it.id == id } ?: return
                if (i.getStringExtra("kind") == "alarm") {
                    if (a.days == 0) ClockStore.saveAlarms(ctx, ClockStore.alarms(ctx).map { if (it.id == id) it.copy(enabled = false) else it })
                    else AlarmScheduler.schedule(ctx, a)      // التالي فوراً
                }
                Ring("alarm", id, a.label.ifBlank { "المنبه" }, a.hour, a.minute, a.snoozeMin, a.ringtone, a.vibrate)
            }
            "timer" -> {
                val t = ClockStore.timers(ctx).firstOrNull { it.id == id } ?: return
                ClockStore.saveTimers(ctx, ClockStore.timers(ctx).map { if (it.id == id) it.copy(endAt = 0, remainingMs = it.durationMs) else it })
                Ring("timer", id, t.label.ifBlank { "انتهى المؤقّت" }, 0, 0, 0, null, true)
            }
            else -> return
        }
        ClockModel.load(ctx); TimerNotifier.update(ctx)
        ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmRingService::class.java).setAction(AlarmRingService.ACT_RING).putExtras(ring.toExtras()))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { AlarmScheduler.rescheduleAll(ctx); TimerNotifier.update(ctx) }
}

object ClockNotifier {
    fun channel(ctx: Context, id: String, name: String, importance: Int) {
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(id, name, importance).apply { setSound(null, null) })
    }
    fun timerDone(ctx: Context, label: String) {
        channel(ctx, "clock_info", "تنبيهات الساعة", NotificationManager.IMPORTANCE_HIGH)
        val n = NotificationCompat.Builder(ctx, "clock_info").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("انتهى المؤقّت").setContentText(label.ifBlank { "انتهى الوقت" }).setAutoCancel(true).build()
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(System.currentTimeMillis().toInt(), n) }
    }
}

/** إشعار دائم بالعدّ التنازلي للمؤقّت الجاري (يتحدّث من النظام بلا استهلاك) */
object TimerNotifier {
    private const val ID = 4242
    fun update(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val t = ClockStore.timers(ctx).filter { it.running }.minByOrNull { it.endAt }
        if (t == null) { nm.cancel(ID); return }
        ClockNotifier.channel(ctx, "timers", "المؤقّتات الجارية", NotificationManager.IMPORTANCE_LOW)
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).setAction("app.filehub.OPEN_CLOCK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, "timers").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(t.label.ifBlank { "المؤقّت" }).setContentText("الوقت المتبقي").setOngoing(true).setOnlyAlertOnce(true)
            .setUsesChronometer(true).setChronometerCountDown(true).setWhen(t.endAt).setContentIntent(open).build()
        runCatching { nm.notify(ID, n) }
    }
}

/** حالة الواجهة + العمليات (تحفظ وتجدول) */
object ClockModel {
    var alarms by mutableStateOf<List<Alarm>>(emptyList()); private set
    var timers by mutableStateOf<List<TimerItem>>(emptyList()); private set

    fun load(ctx: Context) { alarms = ClockStore.alarms(ctx); timers = ClockStore.timers(ctx) }

    private fun nextId(ids: List<Int>) = (ids.maxOrNull() ?: 0) + 1

    fun saveAlarm(ctx: Context, a: Alarm): Alarm {
        val l = ClockStore.alarms(ctx)
        val x = if (a.id <= 0) a.copy(id = nextId(l.map { it.id })) else a
        val out = if (l.any { it.id == x.id }) l.map { if (it.id == x.id) x else it } else l + x
        ClockStore.saveAlarms(ctx, out); AlarmScheduler.cancelAlarm(ctx, x.id); AlarmScheduler.schedule(ctx, x); load(ctx)
        return x
    }
    fun toggleAlarm(ctx: Context, id: Int, on: Boolean) { ClockStore.alarms(ctx).firstOrNull { it.id == id }?.let { saveAlarm(ctx, it.copy(enabled = on)) } }
    fun deleteAlarm(ctx: Context, id: Int) { AlarmScheduler.cancelAlarm(ctx, id); ClockStore.saveAlarms(ctx, ClockStore.alarms(ctx).filter { it.id != id }); load(ctx) }

    private fun mutateTimer(ctx: Context, id: Int, f: (TimerItem) -> TimerItem?) {
        val out = ClockStore.timers(ctx).mapNotNull { if (it.id == id) f(it) else it }
        ClockStore.saveTimers(ctx, out); load(ctx); TimerNotifier.update(ctx)
    }
    fun addTimer(ctx: Context, durationMs: Long, label: String = "", start: Boolean = true) {
        val l = ClockStore.timers(ctx)
        val t = TimerItem(nextId(l.map { it.id }), label, durationMs)
        ClockStore.saveTimers(ctx, l + t); load(ctx)
        if (start) startTimer(ctx, t.id)
    }
    fun startTimer(ctx: Context, id: Int) = mutateTimer(ctx, id) { t -> t.copy(endAt = System.currentTimeMillis() + t.remainingMs).also { AlarmScheduler.scheduleTimer(ctx, it) } }
    fun pauseTimer(ctx: Context, id: Int) = mutateTimer(ctx, id) { t ->
        AlarmScheduler.cancelTimer(ctx, id); t.copy(remainingMs = (t.endAt - System.currentTimeMillis()).coerceAtLeast(0), endAt = 0)
    }
    fun resetTimer(ctx: Context, id: Int) = mutateTimer(ctx, id) { t -> AlarmScheduler.cancelTimer(ctx, id); t.copy(endAt = 0, remainingMs = t.durationMs) }
    fun addMinute(ctx: Context, id: Int) = mutateTimer(ctx, id) { t ->
        if (t.running) t.copy(endAt = t.endAt + 60_000, durationMs = t.durationMs + 60_000).also { AlarmScheduler.scheduleTimer(ctx, it) }
        else t.copy(remainingMs = t.remainingMs + 60_000, durationMs = maxOf(t.durationMs, t.remainingMs + 60_000))
    }
    fun deleteTimer(ctx: Context, id: Int) = mutateTimer(ctx, id) { AlarmScheduler.cancelTimer(ctx, id); null }
    /** «+1 دقيقة» من شاشة الرنين: يعيد تشغيل المؤقّت دقيقة واحدة */
    fun restartTimer(ctx: Context, id: Int, ms: Long) = mutateTimer(ctx, id) { t -> t.copy(endAt = System.currentTimeMillis() + ms, remainingMs = ms).also { AlarmScheduler.scheduleTimer(ctx, it) } }
}

/** ساعة الإيقاف (عدّاد تصاعدي) تستمر حتى لو أُغلق التطبيق، وتحفظ اللفّات */
object Stopwatch {
    var running by mutableStateOf(false); private set
    private var acc by mutableLongStateOf(0L)
    private var startWall by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>()

    fun elapsed(now: Long) = acc + if (running) now - startWall else 0L

    fun load(ctx: Context) {
        runCatching {
            val j = JSONObject(prefs(ctx).rawGet("stopwatch") ?: return)
            running = j.getBoolean("run"); acc = j.getLong("acc"); startWall = j.getLong("start")
            laps.clear(); j.getJSONArray("laps").let { a -> (0 until a.length()).forEach { laps.add(a.getLong(it)) } }
        }
    }
    private fun save(ctx: Context) = prefs(ctx).rawPut("stopwatch", JSONObject().put("run", running).put("acc", acc).put("start", startWall).put("laps", JSONArray(laps.toList())).toString())

    fun start(ctx: Context) { if (!running) { startWall = System.currentTimeMillis(); running = true; save(ctx) } }
    fun stop(ctx: Context) { if (running) { acc += System.currentTimeMillis() - startWall; running = false; save(ctx) } }
    fun lap(ctx: Context) { if (running) { laps.add(elapsed(System.currentTimeMillis())); save(ctx) } }
    fun reset(ctx: Context) { running = false; acc = 0; startWall = 0; laps.clear(); save(ctx) }
}
