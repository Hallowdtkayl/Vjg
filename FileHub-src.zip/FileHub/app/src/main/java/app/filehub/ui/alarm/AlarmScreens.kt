package app.filehub.ui.alarm

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import app.filehub.alarm.*
import kotlinx.coroutines.delay
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()
private fun timeText(c: Context, h: Int, m: Int) = DateFormat.getTimeFormat(c).format(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }.time)

private fun untilText(ms: Long): String {
    val min = (ms / 60_000).coerceAtLeast(0); val d = min / 1440; val h = (min % 1440) / 60; val m = min % 60
    return "بعد " + listOfNotNull(d.takeIf { it > 0 }?.let { "$it يوم" }, h.takeIf { it > 0 }?.let { "$it س" }, m.takeIf { it > 0 || (d == 0L && h == 0L) }?.let { if (it == 0L) "أقل من دقيقة" else "$it د" }).joinToString(" و ")
}

private fun daysSummary(d: Int): String {
    if (d == 0) return "مرة واحدة"; if (d == 127) return "كل يوم"
    val names = DateFormatSymbols(Locale.getDefault()).shortWeekdays
    return (1..7).filter { d and (1 shl (it - 1)) != 0 }.joinToString("، ") { names[it] }
}

// ───────────────────────── الشاشة الرئيسية (4 تبويبات) ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var alarms by remember { mutableStateOf(AlarmStore.alarms(ctx)) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    BackHandler(editing != null) { editing = null }

    if (editing != null) {
        AlarmEditor(editing!!, { editing = null }, onSave = { a ->
            val saved = AlarmStore.upsert(ctx, a)
            val t = AlarmScheduler.schedule(ctx, saved)
            if (t != null) toast(ctx, "سيرن " + untilText(t - System.currentTimeMillis()))
            alarms = AlarmStore.alarms(ctx); editing = null
        }, onDelete = { id -> AlarmScheduler.cancel(ctx, id); AlarmStore.delete(ctx, id); alarms = AlarmStore.alarms(ctx); editing = null })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("المنبه والمؤقت") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } })
        },
        floatingActionButton = {
            if (tab == 0) FloatingActionButton({ editing = Alarm(0, Calendar.getInstance().get(Calendar.HOUR_OF_DAY), Calendar.getInstance().get(Calendar.MINUTE)) }) { Icon(Icons.Rounded.Add, "منبه جديد") }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            val tabs = listOf("منبه" to Icons.Rounded.Alarm, "العالم" to Icons.Rounded.Public, "مؤقت" to Icons.Rounded.HourglassBottom, "إيقاف" to Icons.Rounded.Timer)
            ScrollableTabRow(tab, edgePadding = 0.dp) { tabs.forEachIndexed { i, (l, ic) -> Tab(tab == i, { tab = i }, text = { Text(l) }, icon = { Icon(ic, null) }) } }
            if (Build.VERSION.SDK_INT >= 34 && !ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
                Card(Modifier.padding(12.dp).fillMaxWidth(), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("فعّل «الإشعارات بملء الشاشة»", fontWeight = FontWeight.SemiBold)
                        Text("بدونها قد لا تظهر شاشة المنبه فوق القفل (يبقى الصوت).", style = MaterialTheme.typography.bodySmall)
                        TextButton({ runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))) } }) { Text("فتح الإعداد") }
                    }
                }
            when (tab) {
                0 -> AlarmsTab(alarms, { alarms = AlarmStore.alarms(ctx) }, { editing = it })
                1 -> WorldTab()
                2 -> TimerTab()
                else -> StopwatchTab()
            }
        }
    }
}

// ───────────────────────── المنبهات ─────────────────────────
@Composable
private fun AlarmsTab(alarms: List<Alarm>, refresh: () -> Unit, edit: (Alarm) -> Unit) {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(30_000) } }
    val next = alarms.filter { it.enabled }.minOfOrNull { nextTrigger(it, now) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(if (next != null) "المنبه التالي: " + untilText(next - now) else "لا توجد منبهات مفعّلة", style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        if (alarms.isEmpty()) item { Text("اضغط + لإضافة منبه", Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(alarms, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth().clickable { edit(a) }, colors = CardDefaults.cardColors(if (a.enabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(timeText(ctx, a.hour, a.minute), fontSize = 34.sp, fontWeight = FontWeight.Light, color = if (a.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text((if (a.label.isNotBlank()) a.label + " • " else "") + daysSummary(a.days), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Switch(a.enabled, { on ->
                        val s = AlarmStore.upsert(ctx, a.copy(enabled = on))
                        val t = AlarmScheduler.schedule(ctx, s)
                        if (t != null) toast(ctx, "سيرن " + untilText(t - System.currentTimeMillis()))
                        refresh()
                    })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmEditor(a: Alarm, onCancel: () -> Unit, onSave: (Alarm) -> Unit, onDelete: (Int) -> Unit) {
    val ctx = LocalContext.current
    val state = rememberTimePickerState(a.hour, a.minute, DateFormat.is24HourFormat(ctx))
    var label by remember { mutableStateOf(a.label) }
    var days by remember { mutableIntStateOf(a.days) }
    var vibrate by remember { mutableStateOf(a.vibrate) }
    var gradual by remember { mutableStateOf(a.gradual) }
    var snooze by remember { mutableIntStateOf(a.snoozeMin) }
    var ring by remember { mutableStateOf(a.ringtone) }
    val ringName = remember(ring) { runCatching { RingtoneManager.getRingtone(ctx, ring?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).getTitle(ctx) }.getOrDefault("الافتراضي") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }?.let { ring = it.toString() }
    }
    val firstDow = Calendar.getInstance().firstDayOfWeek
    val order = (0..6).map { (firstDow - 1 + it) % 7 + 1 }
    val names = remember { DateFormatSymbols(Locale.getDefault()).shortWeekdays }

    Scaffold(topBar = {
        TopAppBar(title = { Text(if (a.id == 0) "منبه جديد" else "تعديل المنبه") }, navigationIcon = { IconButton(onCancel) { Icon(Icons.Rounded.Close, "إغلاق") } },
            actions = {
                if (a.id != 0) IconButton({ onDelete(a.id) }) { Icon(Icons.Rounded.Delete, "حذف") }
                TextButton({ onSave(a.copy(hour = state.hour, minute = state.minute, days = days, label = label, enabled = true, ringtone = ring, vibrate = vibrate, snoozeMin = snooze, gradual = gradual)) }) { Text("حفظ") }
            })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { TimePicker(state) }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                order.forEach { dow -> val bit = 1 shl (dow - 1); FilterChip(days and bit != 0, { days = days xor bit }, { Text(names[dow]) }) }
            }
            Text(daysSummary(days), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(label, { label = it }, Modifier.fillMaxWidth(), label = { Text("تسمية") }, singleLine = true, leadingIcon = { Icon(Icons.Rounded.Label, null) })
            ListItem({ Text("نغمة المنبه") }, supportingContent = { Text(ringName) }, leadingContent = { Icon(Icons.Rounded.MusicNote, null) },
                modifier = Modifier.clickable {
                    pick.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ring?.let(Uri::parse)))
                })
            ListItem({ Text("الاهتزاز") }, leadingContent = { Icon(Icons.Rounded.Vibration, null) }, trailingContent = { Switch(vibrate, { vibrate = it }) })
            ListItem({ Text("رفع الصوت تدريجياً") }, supportingContent = { Text("يبدأ هادئاً ويصل لأقصاه خلال 30 ثانية") }, leadingContent = { Icon(Icons.Rounded.VolumeUp, null) }, trailingContent = { Switch(gradual, { gradual = it }) })
            Column(Modifier.fillMaxWidth()) {
                Text("مدة الغفوة", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodyLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "بدون", 5 to "5 د", 9 to "9 د", 10 to "10 د", 15 to "15 د").forEach { (v, l) -> FilterChip(snooze == v, { snooze = v }, { Text(l) }) }
                }
            }
        }
    }
}

// ───────────────────────── الساعة العالمية ─────────────────────────
@Composable
private fun WorldTab() {
    val ctx = LocalContext.current
    var zones by remember { mutableStateOf(AlarmStore.zones(ctx)) }
    var adding by remember { mutableStateOf(false) }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val local = TimeZone.getDefault()
    fun dayKey(tz: TimeZone) = Calendar.getInstance(tz).apply { timeInMillis = now }.let { it.get(Calendar.YEAR) * 400 + it.get(Calendar.DAY_OF_YEAR) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("هنا", style = MaterialTheme.typography.titleMedium); Text(local.id.substringAfterLast('/').replace('_', ' '), style = MaterialTheme.typography.bodySmall) }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(DateFormat.getTimeFormat(ctx).format(Date(now)), fontSize = 30.sp, fontWeight = FontWeight.Light) }
                }
            }
        }
        itemsIndexed(zones, key = { _, z -> z }) { _, id ->
            val tz = TimeZone.getTimeZone(id)
            val diffH = (tz.getOffset(now) - local.getOffset(now)) / 3_600_000.0
            val dayDiff = dayKey(tz) - dayKey(local)
            val fmt = DateFormat.getTimeFormat(ctx).apply { timeZone = tz }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(id.substringAfterLast('/').replace('_', ' '), style = MaterialTheme.typography.titleMedium)
                        Text((when { dayDiff > 0 -> "غداً"; dayDiff < 0 -> "أمس"; else -> "اليوم" }) + " • " + (if (diffH == 0.0) "نفس التوقيت" else (if (diffH > 0) "+" else "") + (if (diffH % 1.0 == 0.0) diffH.toInt().toString() else diffH.toString()) + " س"),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(fmt.format(Date(now)), fontSize = 28.sp, fontWeight = FontWeight.Light) }
                    IconButton({ zones = zones - id; AlarmStore.saveZones(ctx, zones) }) { Icon(Icons.Rounded.Close, "إزالة") }
                }
            }
        }
        item { OutlinedButton({ adding = true }, Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text("إضافة مدينة") } }
    }
    if (adding) {
        var q by remember { mutableStateOf("") }
        val all = remember { TimeZone.getAvailableIDs().filter { '/' in it && !it.startsWith("Etc") && !it.startsWith("SystemV") } }
        val hits = remember(q) { if (q.length < 2) emptyList() else all.filter { it.replace('_', ' ').contains(q, true) }.take(30) }
        AlertDialog({ adding = false }, title = { Text("إضافة مدينة") }, confirmButton = { TextButton({ adding = false }) { Text("إغلاق") } },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text("ابحث بالإنجليزية: Tokyo, Cairo…") })
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(hits, key = { it }) { id -> ListItem({ Text(id.substringAfterLast('/').replace('_', ' ')) }, supportingContent = { Text(id.substringBefore('/')) },
                            modifier = Modifier.clickable { if (id !in zones) { zones = zones + id; AlarmStore.saveZones(ctx, zones) }; adding = false }) }
                    }
                }
            })
    }
}

// ───────────────────────── المؤقت (عدّ تنازلي) ─────────────────────────
private fun clock(ms: Long): String {
    val s = (ms + 999) / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
private fun TimerTab() {
    val ctx = LocalContext.current
    var timers by remember { mutableStateOf(AlarmStore.timers(ctx)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var custom by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { var n = 0; while (true) { delay(200); now = System.currentTimeMillis(); if (++n % 4 == 0) timers = AlarmStore.timers(ctx) } }
    fun reload() { timers = AlarmStore.timers(ctx) }
    fun remaining(t: TimerItem) = when (t.state) { 1 -> (t.endsAt - now).coerceAtLeast(0); 3 -> 0; else -> t.remainingMs }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("ابدأ مؤقتاً سريعاً", Modifier.padding(horizontal = 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1 to "1 د", 5 to "5 د", 10 to "10 د", 15 to "15 د", 30 to "30 د", 60 to "ساعة").forEach { (m, l) ->
                    AssistChip({ TimerActions.create(ctx, m * 60_000L, "", true); reload() }, { Text(l) })
                }
                AssistChip({ custom = true }, { Text("مخصص") }, leadingIcon = { Icon(Icons.Rounded.Add, null) })
            }
        }
        if (timers.isEmpty()) item { Text("لا توجد مؤقتات", Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(timers, key = { it.id }) { t ->
            val rem = remaining(t)
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(84.dp), Alignment.Center) {
                        CircularProgressIndicator(progress = { if (t.totalMs > 0) (rem.toFloat() / t.totalMs).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxSize(), strokeWidth = 6.dp,
                            color = if (t.state == 3) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(clock(rem), fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium) }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.label.ifBlank { "المؤقت" }, style = MaterialTheme.typography.titleMedium)
                        Text("من " + clock(t.totalMs) + when (t.state) { 1 -> " • يعمل"; 2 -> " • متوقف"; 3 -> " • انتهى"; else -> "" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row {
                            FilledIconButton({ if (t.state == 1) TimerActions.pause(ctx, t.id) else TimerActions.start(ctx, t.id); reload() }, Modifier.size(40.dp)) { Icon(if (t.state == 1) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "تشغيل/إيقاف") }
                            IconButton({ TimerActions.addMinute(ctx, t.id); reload() }) { Icon(Icons.Rounded.MoreTime, "+1 دقيقة") }
                            IconButton({ TimerActions.reset(ctx, t.id); reload() }) { Icon(Icons.Rounded.Replay, "إعادة") }
                            IconButton({ TimerActions.delete(ctx, t.id); reload() }) { Icon(Icons.Rounded.Delete, "حذف") }
                        }
                    }
                }
            }
        }
    }
    if (custom) {
        var h by remember { mutableStateOf("0") }; var m by remember { mutableStateOf("5") }; var s by remember { mutableStateOf("0") }; var label by remember { mutableStateOf("") }
        val total = ((h.toLongOrNull() ?: 0) * 3600 + (m.toLongOrNull() ?: 0) * 60 + (s.toLongOrNull() ?: 0)) * 1000
        AlertDialog({ custom = false }, title = { Text("مؤقت مخصص") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(Triple("س", h, { v: String -> h = v }), Triple("د", m, { v: String -> m = v }), Triple("ث", s, { v: String -> s = v })).forEach { (l, v, set) ->
                                OutlinedTextField(v, { set(it.filter(Char::isDigit).take(2)) }, Modifier.weight(1f), label = { Text(l) }, singleLine = true,
                                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 20.sp, textAlign = TextAlign.Center))
                            }
                        }
                    }
                    OutlinedTextField(label, { label = it }, singleLine = true, label = { Text("تسمية (اختياري)") })
                }
            },
            confirmButton = { TextButton({ if (total > 0) { TimerActions.create(ctx, total, label, true); reload(); custom = false } }, enabled = total > 0) { Text("ابدأ") } },
            dismissButton = { TextButton({ custom = false }) { Text("إلغاء") } })
    }
}

// ───────────────────────── ساعة الإيقاف (عدّاد تصاعدي) ─────────────────────────
private fun swText(ms: Long): String {
    val cs = (ms / 10) % 100; val s = (ms / 1000) % 60; val m = (ms / 60_000) % 60; val h = ms / 3_600_000
    return if (h > 0) "%d:%02d:%02d.%02d".format(h, m, s, cs) else "%02d:%02d.%02d".format(m, s, cs)
}

@Composable
private fun StopwatchTab() {
    val ctx = LocalContext.current
    var sw by remember { mutableStateOf(AlarmStore.stopwatch(ctx)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(sw.running) { while (sw.running) { now = System.currentTimeMillis(); delay(30) }; now = System.currentTimeMillis() }
    fun set(s: StopwatchState) { sw = s; AlarmStore.saveStopwatch(ctx, s) }
    val el = sw.elapsed(now)
    val laps = sw.laps.mapIndexed { i, cum -> Triple(i + 1, cum - (sw.laps.getOrNull(i - 1) ?: 0L), cum) }
    val best = if (laps.size >= 3) laps.minOf { it.second } else -1L
    val worst = if (laps.size >= 3) laps.maxOf { it.second } else -1L

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(swText(el), fontSize = 56.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
            if (sw.running) OutlinedButton({ set(sw.copy(laps = sw.laps + sw.elapsed(System.currentTimeMillis()))) }, Modifier.size(width = 120.dp, height = 56.dp)) { Icon(Icons.Rounded.Flag, null); Spacer(Modifier.width(6.dp)); Text("لفة") }
            else if (el > 0) OutlinedButton({ set(StopwatchState()) }, Modifier.size(width = 120.dp, height = 56.dp)) { Icon(Icons.Rounded.Replay, null); Spacer(Modifier.width(6.dp)); Text("تصفير") }
            FilledIconButton({
                val t = System.currentTimeMillis()
                if (sw.running) set(sw.copy(running = false, accum = sw.elapsed(t), startWall = 0)) else set(sw.copy(running = true, startWall = t))
            }, Modifier.size(72.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = if (sw.running) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)) {
                Icon(if (sw.running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (sw.running) "إيقاف" else "بدء", Modifier.size(36.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(laps.reversed(), key = { it.first }) { (n, lapMs, cum) ->
                ListItem({ CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(swText(lapMs), fontFamily = FontFamily.Monospace,
                    color = when (lapMs) { best -> Color(0xFF2E7D32); worst -> MaterialTheme.colorScheme.error; else -> MaterialTheme.colorScheme.onSurface }) } },
                    leadingContent = { Text("لفة $n") }, trailingContent = { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(swText(cum), fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant) } })
            }
        }
    }
}
