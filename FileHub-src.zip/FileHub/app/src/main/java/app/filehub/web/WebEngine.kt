package app.filehub.web

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import android.os.Looper
import android.os.Message
import android.webkit.*

/** كل ما يحتاجه الواجهة من أحداث الصفحة. كل دالة لها تنفيذ افتراضي فارغ */
interface WebCallbacks {
    fun onProgress(p: Int) {}
    fun onTitle(t: String) {}
    fun onUrl(u: String) {}
    fun onFavicon(b: Bitmap?) {}
    fun onNav(canBack: Boolean, canForward: Boolean) {}
    fun onDownload(req: DownloadRequest) {}
    fun onNewWindow(url: String) {}
    fun onError(url: String, msg: String) {}
    fun onMedia(m: SniffedMedia) {}          // phase-2: التقاط روابط الفيديو/الصوت
}

object WebEngine {
    const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private var warmed = false

    /** تهيئة محرّك Chromium أثناء خمول التطبيق، فيفتح أول تبويب أسرع */
    fun warmUp(app: Application) {
        if (warmed) return; warmed = true
        Looper.myQueue().addIdleHandler { runCatching { WebView(MutableContextWrapper(app)).destroy() }; false }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun create(ctx: Context, noHistory: Boolean, cb: WebCallbacks): WebView {
        val wv = WebView(MutableContextWrapper(ctx.applicationContext))   // السياق قابل للتبديل عند الإرفاق بنشاط
        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            @Suppress("DEPRECATION") databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true); javaScriptCanOpenWindowsAutomatically = true
            allowFileAccess = false; allowContentAccess = false
            useWideViewPort = true; loadWithOverviewMode = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            cacheMode = if (noHistory) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            @Suppress("DEPRECATION") saveFormData = !noHistory
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(wv, true) }
        wv.webViewClient = BrowserClient(cb, noHistory)
        wv.webChromeClient = ChromeClient(cb)
        wv.setDownloadListener { url, ua, cd, mime, len -> cb.onDownload(DownloadRequest(url, ua, cd, mime, len, wv.url)) }
        return wv
    }

    fun setDesktop(wv: WebView, on: Boolean) {
        wv.settings.userAgentString = if (on) DESKTOP_UA else null
        wv.settings.useWideViewPort = true
        wv.reload()
    }

    fun cookiesFor(url: String): String? = CookieManager.getInstance().getCookie(url)
    fun flushCookies() = CookieManager.getInstance().flush()

    /** يحوّل نص شريط العنوان إلى رابط أو استعلام بحث */
    fun resolveInput(raw: String, searchBase: String = SearchEngines.all[0].second): String {
        val t = raw.trim()
        if (t.isEmpty()) return SearchEngines.DEFAULT_HOME
        if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*").matches(t) && !Regex("^[\\w.-]+:\\d+.*").matches(t)) return t
        if ('.' in t && ' ' !in t || t.startsWith("localhost")) return "https://$t"
        return searchBase + Uri.encode(t)
    }
}

class BrowserClient(private val cb: WebCallbacks, private val noHistory: Boolean) : WebViewClient() {
    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
        val u = r.url
        return when (u.scheme) {
            "http", "https", "about", "blob", "data" -> false
            "intent" -> { runCatching { v.context.startActivity(Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }; true }
            else -> { runCatching { v.context.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }; true }   // tel/mailto/market…
        }
    }
    override fun onPageStarted(v: WebView, url: String, f: Bitmap?) { cb.onUrl(url); cb.onProgress(0); cb.onNav(v.canGoBack(), v.canGoForward()) }
    override fun onPageFinished(v: WebView, url: String) {
        cb.onUrl(url); cb.onTitle(v.title.orEmpty()); cb.onNav(v.canGoBack(), v.canGoForward())
        if (!noHistory) runCatching { WebDb.get(v.context.applicationContext).addHistory(url, v.title) }
        WebEngine.flushCookies()
    }
    override fun doUpdateVisitedHistory(v: WebView, url: String, isReload: Boolean) { cb.onUrl(url); cb.onNav(v.canGoBack(), v.canGoForward()) }
    override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
        if (r.isForMainFrame) cb.onError(r.url.toString(), e.description.toString())
    }
    @SuppressLint("WebViewClientOnReceivedSslError")
    override fun onReceivedSslError(v: WebView, h: android.webkit.SslErrorHandler, e: android.net.http.SslError) { h.cancel(); cb.onError(e.url.orEmpty(), "شهادة الأمان غير صالحة") }

    // TODO(phase-2): shouldInterceptRequest لالتقاط روابط mp4/webm/m3u8/mpd وحجب الإعلانات البسيط
}

class ChromeClient(private val cb: WebCallbacks) : WebChromeClient() {
    override fun onProgressChanged(v: WebView, p: Int) { cb.onProgress(p) }
    override fun onReceivedTitle(v: WebView, t: String?) { cb.onTitle(t.orEmpty()) }
    override fun onReceivedIcon(v: WebView, icon: Bitmap?) { cb.onFavicon(icon) }
    override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
        // نلتقط رابط النافذة المنبثقة ونفتحه في تبويب جديد
        val temp = WebView(MutableContextWrapper(v.context.applicationContext))
        temp.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(w: WebView, r: WebResourceRequest): Boolean { cb.onNewWindow(r.url.toString()); w.post { w.destroy() }; return true }
            override fun onPageStarted(w: WebView, url: String, f: Bitmap?) { if (url != "about:blank") { cb.onNewWindow(url); w.post { w.destroy() } } }
        }
        (resultMsg.obj as WebView.WebViewTransport).webView = temp
        resultMsg.sendToTarget()
        return true
    }
    // TODO(phase-2): onShowFileChooser (رفع الملفات)، onPermissionRequest (كاميرا/مايك)، onGeolocationPermissionsShowPrompt،
    //                onShowCustomView/onHideCustomView (ملء الشاشة للفيديو)، onJsAlert/Confirm/Prompt
}
