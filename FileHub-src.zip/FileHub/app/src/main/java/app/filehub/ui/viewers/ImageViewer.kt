package app.filehub.ui.viewers

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.filehub.model.FileTypes
import app.filehub.ui.screens.openExternal
import coil.compose.AsyncImage
import java.io.File

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ImageViewer(path: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = File(path)
    val list = remember(path) {
        file.parentFile?.listFiles()?.filter { it.isFile && it.extension.lowercase().let { e -> e in FileTypes.images && e != "svg" } }
            ?.sortedBy { it.name.lowercase() }.orEmpty().ifEmpty { listOf(file) }
    }
    val pager = rememberPagerState(list.indexOfFirst { it.path == path }.coerceAtLeast(0)) { list.size }
    var bars by remember { mutableStateOf(true) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize(), key = { list[it].path }) { i ->
            ZoomImage(list[i]) { bars = !bars }
        }
        if (bars) TopAppBar(
            title = { Text("${list[pager.currentPage].name}  (${pager.currentPage + 1}/${list.size})", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
            actions = { IconButton({ openExternal(ctx, list[pager.currentPage].path) {} }) { Icon(Icons.AutoMirrored.Rounded.OpenInNew, "فتح بتطبيق آخر") } },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Black.copy(alpha = .55f), titleContentColor = Color.White,
                navigationIconContentColor = Color.White, actionIconContentColor = Color.White)
        )
    }
}

@Composable
private fun ZoomImage(file: File, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Box(Modifier.fillMaxSize()
        .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }, onDoubleTap = { scale = if (scale > 1f) 1f else 2.5f; offset = Offset.Zero }) }
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val ev = awaitPointerEvent()
                    // لا نستهلك اللمسة بإصبع واحد عند الحجم الطبيعي، ليبقى التمرير بين الصور ممكناً
                    if (ev.changes.size > 1 || scale > 1f) {
                        scale = (scale * ev.calculateZoom()).coerceIn(1f, 5f)
                        offset = if (scale > 1f) offset + ev.calculatePan() else Offset.Zero
                        ev.changes.forEach { it.consume() }
                    }
                } while (ev.changes.any { it.pressed })
            }
        },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(file, null, Modifier.fillMaxSize().graphicsLayer(
            scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y), contentScale = ContentScale.Fit)
    }
}
