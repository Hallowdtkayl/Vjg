package app.filehub.ui.phone

import android.Manifest
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.telephony.PhoneNumberUtils
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.automirrored.rounded.CallMade
import androidx.compose.material.icons.automirrored.rounded.CallMissed
import androidx.compose.material.icons.automirrored.rounded.CallReceived
import androidx.compose.material.icons.automirrored.rounded.Message
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import app.filehub.FileApp
import app.filehub.phone.*
import app.filehub.ui.components.SectionTitle
import app.filehub.ui.readableDate
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────────────────── عناصر مشتركة ─────────────────────────
@Composable
fun Avatar(name: String, photo: String?, size: Int = 48) {
    val colors = listOf(0xFF3949D6, 0xFF00897B, 0xFFE64A19, 0xFF8E24AA, 0xFF1E88E5, 0xFF6D4C41, 0xFFC2185B)
    val bg = Color(colors[(name.hashCode() and 0x7FFFFFFF) % colors.size])
    Box(Modifier.size(size.dp).clip(CircleShape).background(bg), Alignment.Center) {
        val initial = name.firstOrNull { it.isLetter() }?.uppercase()
        if (initial != null) Text(initial, color = Color.White, fontSize = (size * .42f).sp, fontWeight = FontWeight.SemiBold)
        else Icon(Icons.Rounded.Person, null, tint = Color.White, modifier = Modifier.size((size * .55f).dp))
        if (photo != null) AsyncImage(photo, null, Modifier.fillMaxSize().clip(CircleShape))
    }
}

private val PHONE_PERMS: Array<String> = buildList {
    addAll(listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.WRITE_CALL_LOG,
        Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS))
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

private fun hasPhonePerms(c: Context) = PHONE_PERMS.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

@Composable
private fun RequirePhonePermissions(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(hasPhonePerms(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = hasPhonePerms(ctx) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { ok = hasPhonePerms(ctx) }
    if (ok) content() else Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.Call, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text("صلاحيات الهاتف", style = MaterialTheme.typography.titleLarge)
        Text("لقراءة سجل المكالمات وجهات الاتصال وإجراء المكالمات واستقبالها.", textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
        Button({ launcher.launch(PHONE_PERMS) }) { Text("منح الصلاحيات") }
    }
}

/** هل التطبيق هو الهاتف الافتراضي؟ + دالة الطلب */
@Composable
private fun rememberDefaultDialer(): Pair<Boolean, () -> Unit> {
    val ctx = LocalContext.current
    var isDef by remember { mutableStateOf(DialerUtil.isDefault(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { isDef = DialerUtil.isDefault(ctx) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { isDef = DialerUtil.isDefault(ctx) }
    return isDef to { runCatching { launcher.launch(DialerUtil.requestIntent(ctx)) } }
}

private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()
private fun smsIntent(n: String) = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(n)}"))
private fun addContactIntent(n: String) = Intent(Intent.ACTION_INSERT_OR_EDIT).setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE)
    .putExtra(ContactsContract.Intents.Insert.PHONE, n)

private fun dayLabel(t: Long): String {
    val now = Calendar.getInstance(); val c = Calendar.getInstance().apply { timeInMillis = t }
    val d = (now.get(Calendar.YEAR) * 366 + now.get(Calendar.DAY_OF_YEAR)) - (c.get(Calendar.YEAR) * 366 + c.get(Calendar.DAY_OF_YEAR))
    return when (d) { 0 -> "اليوم"; 1 -> "أمس"; else -> t.readableDate() }
}
private fun timeLabel(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
private fun durLabel(s: Long) = if (s <= 0) "" else if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)

private fun typeInfo(t: Int): Triple<androidx.compose.ui.graphics.vector.ImageVector, String, Boolean> = when (t) {
    CallLog.Calls.INCOMING_TYPE -> Triple(Icons.AutoMirrored.Rounded.CallReceived, "واردة", false)
    CallLog.Calls.OUTGOING_TYPE -> Triple(Icons.AutoMirrored.Rounded.CallMade, "صادرة", false)
    CallLog.Calls.MISSED_TYPE -> Triple(Icons.AutoMirrored.Rounded.CallMissed, "فائتة", true)
    CallLog.Calls.VOICEMAIL_TYPE -> Triple(Icons.Rounded.Voicemail, "بريد صوتي", false)
    CallLog.Calls.REJECTED_TYPE -> Triple(Icons.Rounded.PhoneDisabled, "مرفوضة", true)
    CallLog.Calls.BLOCKED_TYPE -> Triple(Icons.Rounded.Block, "محجوبة", true)
    else -> Triple(Icons.AutoMirrored.Rounded.CallReceived, "واردة", false)
}

// ───────────────────────── ViewModel السجل ─────────────────────────
class PhoneViewModel(app: Application) : AndroidViewModel(app) {
    var entries by mutableStateOf<List<LogEntry>>(emptyList()); private set
    var loading by mutableStateOf(true); private set
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(selfChange: Boolean) { reload() } }

    init { app.contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI, true, obs); reload() }

    fun reload() {
        viewModelScope.launch {
            entries = withContext(Dispatchers.IO) { runCatching { CallLogRepo.load(getApplication()) }.getOrDefault(emptyList()) }
            loading = false
        }
    }
    fun markRead() { viewModelScope.launch(Dispatchers.IO) { CallLogRepo.markRead(getApplication()) } }
    fun delete(ids: List<Long>) { viewModelScope.launch(Dispatchers.IO) { runCatching { CallLogRepo.delete(getApplication(), ids) }; reload() } }
    fun clearAll() { viewModelScope.launch(Dispatchers.IO) { runCatching { CallLogRepo.clearAll(getApplication()) }; reload() } }
    override fun onCleared() { getApplication<Application>().contentResolver.unregisterContentObserver(obs) }
}

private data class Row(val e: LogEntry, val count: Int, val ids: List<Long>)

private fun group(list: List<LogEntry>): List<Row> {
    val out = ArrayList<Row>()
    for (e in list) {
        val l = out.lastOrNull()
        if (l != null && l.e.number == e.number && l.e.type == e.type && dayLabel(l.e.date) == dayLabel(e.date))
            out[out.size - 1] = l.copy(count = l.count + 1, ids = l.ids + e.id)
        else out.add(Row(e, 1, listOf(e.id)))
    }
    return out
}

// ───────────────────────── الشاشة الرئيسية للهاتف ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneScreen(onBack: () -> Unit, onDialer: (String) -> Unit, onHistory: (String) -> Unit, onSettings: () -> Unit, onOpenFile: (String) -> Unit,
                onAddContact: (String) -> Unit, onSms: (String) -> Unit) {
    RequirePhonePermissions {
        val ctx = LocalContext.current
        val app = ctx.applicationContext as FileApp
        val vm: PhoneViewModel = viewModel()
        val (isDefault, requestDefault) = rememberDefaultDialer()
        var tab by remember { mutableIntStateOf(0) }
        var filter by remember { mutableIntStateOf(0) }          // 0 الكل 1 فائتة 2 واردة 3 صادرة 4 محجوبة
        var query by remember { mutableStateOf("") }
        var searching by remember { mutableStateOf(false) }
        var expanded by remember { mutableStateOf<Long?>(null) }
        var dnd by remember { mutableIntStateOf(app.prefs.dndMode) }
        var confirmClear by remember { mutableStateOf(false) }
        var menu by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { vm.markRead() }

        val rows = remember(vm.entries, filter, query) {
            group(vm.entries.filter {
                when (filter) {
                    1 -> it.type == CallLog.Calls.MISSED_TYPE
                    2 -> it.type == CallLog.Calls.INCOMING_TYPE
                    3 -> it.type == CallLog.Calls.OUTGOING_TYPE
                    4 -> it.type == CallLog.Calls.BLOCKED_TYPE || it.type == CallLog.Calls.REJECTED_TYPE
                    else -> true
                } && (query.isBlank() || it.number.contains(query) || (it.name?.contains(query, true) == true))
            })
        }
        val hits by produceState(emptyList<ContactHit>(), query) {
            delay(150); value = if (query.length >= 2) withContext(Dispatchers.IO) { ContactsLookup.search(ctx, query, 6) } else emptyList()
        }
        val recordings by produceState(emptyList<File>(), tab) { if (tab == 1) value = withContext(Dispatchers.IO) { CallRecorder.list(ctx) } }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { if (searching) TextField(query, { query = it }, singleLine = true, placeholder = { Text("بحث بالاسم أو الرقم") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)) else Text("الهاتف") },
                    navigationIcon = { IconButton({ if (searching) { searching = false; query = "" } else onBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                    actions = {
                        if (!searching) IconButton({ searching = true }) { Icon(Icons.Rounded.Search, "بحث") }
                        IconButton(onSettings) { Icon(Icons.Rounded.Settings, "إعدادات الهاتف") }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "المزيد") }
                            DropdownMenu(menu, { menu = false }) { DropdownMenuItem({ Text("مسح السجل") }, { confirmClear = true; menu = false }) }
                        }
                    })
            },
            floatingActionButton = { FloatingActionButton({ onDialer("") }) { Icon(Icons.Rounded.Dialpad, "لوحة الأرقام") } }
        ) { pad ->
            Column(Modifier.padding(pad)) {
                if (!isDefault) Card(Modifier.padding(12.dp).fillMaxWidth(), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("اجعل «ملفاتي» تطبيق الهاتف الافتراضي", fontWeight = FontWeight.SemiBold)
                        Text("لتظهر شاشة المكالمة الواردة، ويعمل عدم الإزعاج والحظر والتسجيل.", style = MaterialTheme.typography.bodySmall)
                        TextButton(requestDefault) { Text("تعيين كافتراضي") }
                    }
                }
                // عدم الإزعاج السريع
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.DoNotDisturbOn, null, tint = MaterialTheme.colorScheme.primary)
                    listOf("عدم الإزعاج: إيقاف", "غير المعروفة", "الكل عدا المفضلة").forEachIndexed { i, l ->
                        FilterChip(dnd == i, { dnd = i; app.prefs.dndMode = i }, { Text(l) })
                    }
                }
                TabRow(tab) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("السجل") })
                    Tab(tab == 1, { tab = 1 }, text = { Text("التسجيلات") })
                }
                if (tab == 0) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp, 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("الكل", "فائتة", "واردة", "صادرة", "محجوبة").forEachIndexed { i, l -> FilterChip(filter == i, { filter = i }, { Text(l) }) }
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        if (hits.isNotEmpty()) {
                            item { SectionTitle("جهات الاتصال") }
                            items(hits, key = { "h" + it.number }) { h ->
                                ListItem({ Text(h.name) }, supportingContent = { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(h.number) } },
                                    leadingContent = { Avatar(h.name, h.photo) },
                                    trailingContent = { IconButton({ DialerUtil.call(ctx, h.number) }) { Icon(Icons.Rounded.Call, "اتصال", tint = Color(0xFF2E7D32)) } },
                                    modifier = Modifier.clickable { onHistory(h.number) })
                            }
                            item { SectionTitle("السجل") }
                        }
                        if (vm.loading) item { Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { CircularProgressIndicator() } }
                        else if (rows.isEmpty()) item { Text("لا توجد مكالمات", Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        var last = ""
                        rows.forEach { r ->
                            val day = dayLabel(r.e.date)
                            if (day != last) { last = day; item(key = "d$day${r.e.id}") { Text(day, Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) } }
                            item(key = r.e.id) {
                                LogRowItem(r, expanded == r.e.id, { expanded = if (expanded == r.e.id) null else r.e.id },
                                    onCall = { DialerUtil.call(ctx, r.e.number) }, onHistory = { onHistory(r.e.number) },
                                    onDelete = { vm.delete(r.ids) }, onBlock = {
                                        if (Blocklist.block(ctx, r.e.number)) toast(ctx, "تم الحظر") else toast(ctx, "الحظر يتطلب جعل التطبيق الهاتف الافتراضي")
                                    }, onAdd = { onAddContact(r.e.number) }, onSms = { onSms(r.e.number) })
                            }
                        }
                    }
                } else RecordingsTab(recordings, onOpenFile, onDeleted = { f -> f.delete(); tab = 0; tab = 1 })
            }
        }
        if (confirmClear) AlertDialog({ confirmClear = false }, title = { Text("مسح السجل كاملاً؟") }, text = { Text("لا يمكن التراجع.") },
            confirmButton = { TextButton({ vm.clearAll(); confirmClear = false }) { Text("مسح") } },
            dismissButton = { TextButton({ confirmClear = false }) { Text("إلغاء") } })
    }
}

@Composable
private fun LogRowItem(r: Row, expanded: Boolean, onToggle: () -> Unit, onCall: () -> Unit, onHistory: () -> Unit,
                       onDelete: () -> Unit, onBlock: () -> Unit, onAdd: () -> Unit, onSms: () -> Unit) {
    val e = r.e
    val (icon, label, bad) = typeInfo(e.type)
    val title = e.name ?: e.number.ifEmpty { "رقم مجهول" }
    Column(Modifier.fillMaxWidth().clickable(onClick = onToggle)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(title, e.photo)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(if (r.count > 1) "$title (${r.count})" else title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                    color = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, Modifier.size(15.dp), tint = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(4.dp))
                    Text(buildString { append(label); if (e.name != null && e.number.isNotEmpty()) append(" • ").append(e.number); durLabel(e.duration).takeIf { it.isNotEmpty() }?.let { append(" • ").append(it) } },
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Text(timeLabel(e.date), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            IconButton(onCall) { Icon(Icons.Rounded.Call, "اتصال", tint = Color(0xFF2E7D32)) }
        }
        if (expanded) Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            AssistChip(onSms, { Text("رسالة") }, leadingIcon = { Icon(Icons.AutoMirrored.Rounded.Message, null) })
            AssistChip(onHistory, { Text("التفاصيل") }, leadingIcon = { Icon(Icons.Rounded.History, null) })
            if (e.name == null && e.number.isNotEmpty()) AssistChip(onAdd, { Text("إضافة جهة") }, leadingIcon = { Icon(Icons.Rounded.PersonAdd, null) })
            AssistChip(onBlock, { Text("حظر") }, leadingIcon = { Icon(Icons.Rounded.Block, null) })
            AssistChip(onDelete, { Text("حذف") }, leadingIcon = { Icon(Icons.Rounded.Delete, null) })
        }
    }
}

@Composable
private fun RecordingsTab(files: List<File>, onOpen: (String) -> Unit, onDeleted: (File) -> Unit) {
    if (files.isEmpty()) Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.FiberManualRecord, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("لا توجد تسجيلات. فعّل التسجيل من إعدادات الهاتف أو زر التسجيل أثناء المكالمة.", textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
    } else LazyColumn(Modifier.fillMaxSize()) {
        items(files, key = { it.path }) { f ->
            ListItem({ Text(f.nameWithoutExtension, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(timeLabel(f.lastModified()) + " • " + dayLabel(f.lastModified())) },
                leadingContent = { Icon(Icons.Rounded.GraphicEq, null, tint = MaterialTheme.colorScheme.primary) },
                trailingContent = { IconButton({ onDeleted(f) }) { Icon(Icons.Rounded.Delete, "حذف") } },
                modifier = Modifier.clickable { onOpen(f.path) })
        }
    }
}

// ───────────────────────── لوحة الأرقام ─────────────────────────
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DialerScreen(initial: String, onBack: () -> Unit, onHistory: (String) -> Unit, onAddContact: (String) -> Unit, onSms: (String) -> Unit) {
    RequirePhonePermissions {
        val ctx = LocalContext.current
        var number by remember { mutableStateOf(initial) }
        val accounts = remember { DialerUtil.accounts(ctx) }
        val tone = remember { runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 70) }.getOrNull() }
        DisposableEffect(Unit) { onDispose { tone?.release() } }
        val hits by produceState(emptyList<ContactHit>(), number) {
            delay(120); value = if (number.length >= 2) withContext(Dispatchers.IO) { ContactsLookup.search(ctx, number, 4) } else emptyList()
        }
        fun press(ch: Char) {
            number += ch
            val t = when (ch) { '*' -> 10; '#' -> 11; in '0'..'9' -> ch - '0'; else -> -1 }
            if (t >= 0) tone?.startTone(t, 90)
        }
        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO", "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")

        Scaffold(topBar = {
            TopAppBar(title = { Text("لوحة الأرقام") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } },
                actions = {
                    if (number.isNotEmpty()) {
                        IconButton({ onAddContact(number) }) { Icon(Icons.Rounded.PersonAdd, "إضافة جهة") }
                        IconButton({ onSms(number) }) { Icon(Icons.AutoMirrored.Rounded.Message, "رسالة") }
                    }
                    IconButton({ (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString()
                        ?.filter { it.isDigit() || it in "+*#" }?.let { number = it } }) { Icon(Icons.Rounded.ContentPaste, "لصق") }
                })
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                // الاقتراحات
                Column(Modifier.fillMaxWidth().weight(1f)) {
                    hits.forEach { h ->
                        ListItem({ Text(h.name) }, supportingContent = { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(h.number) } },
                            leadingContent = { Avatar(h.name, h.photo, 40) }, modifier = Modifier.clickable { number = h.number.filter { it.isDigit() || it == '+' } })
                    }
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(number.takeLast(22), Modifier.weight(1f), fontSize = if (number.length > 14) 26.sp else 36.sp, maxLines = 1, textAlign = TextAlign.Center)
                        if (number.isNotEmpty()) Box(Modifier.size(48.dp).clip(CircleShape).combinedClickable(onClick = { number = number.dropLast(1) }, onLongClick = { number = "" }), Alignment.Center) {
                            Icon(Icons.AutoMirrored.Rounded.Backspace, "حذف")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    keys.chunked(3).forEach { row ->
                        Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            row.forEach { (k, sub) ->
                                Column(Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
                                    .combinedClickable(onClick = { press(k[0]) }, onLongClick = { if (k == "0") press('+') }),
                                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(k, fontSize = 28.sp, fontWeight = FontWeight.Medium)
                                    if (sub.isNotEmpty()) Text(sub, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                // زر الاتصال (شريحة لكل زر عند وجود أكثر من شريحة)
                Row(Modifier.padding(bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (accounts.size > 1) accounts.forEach { (h, label) ->
                        Button({ if (number.isNotEmpty()) { DialerUtil.call(ctx, number, h) } }, Modifier.height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))) {
                            Icon(Icons.Rounded.Call, null); Spacer(Modifier.width(6.dp)); Text(label)
                        }
                    } else FilledIconButton({ if (number.isNotEmpty() && !DialerUtil.call(ctx, number)) toast(ctx, "تعذّر الاتصال") }, Modifier.size(64.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF2E7D32))) { Icon(Icons.Rounded.Call, "اتصال", tint = Color.White) }
                }
            }
        }
    }
}

// ───────────────────────── تفاصيل رقم / جهة ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(number: String, onBack: () -> Unit, onAddContact: (String) -> Unit, onSms: (String) -> Unit) {
    RequirePhonePermissions {
        val ctx = LocalContext.current
        val vm: PhoneViewModel = viewModel()
        val info by produceState<ContactInfo?>(null, number) { value = withContext(Dispatchers.IO) { ContactsLookup.lookup(ctx, number) } }
        val mine = remember(vm.entries, number) { vm.entries.filter { PhoneNumberUtils.compare(ctx, it.number, number) } }
        var blocked by remember { mutableStateOf(Blocklist.isBlocked(ctx, number)) }
        val title = info?.name ?: number
        val thread by produceState<app.filehub.sms.SmsThread?>(null, number) {
            value = withContext(Dispatchers.IO) { runCatching { app.filehub.sms.SmsRepo.threads(ctx).firstOrNull { PhoneNumberUtils.compare(ctx, it.address, number) } }.getOrNull() }
        }
        Scaffold(topBar = { TopAppBar(title = { Text("التفاصيل") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } }) }) { pad ->
            LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Avatar(title, info?.photo, 96)
                        Text(title, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp))
                        if (info != null) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(number, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            FilledTonalIconButton({ DialerUtil.call(ctx, number) }) { Icon(Icons.Rounded.Call, "اتصال") }
                            FilledTonalIconButton({ onSms(number) }) { Icon(Icons.AutoMirrored.Rounded.Message, "رسالة") }
                            if (info == null) FilledTonalIconButton({ onAddContact(number) }) { Icon(Icons.Rounded.PersonAdd, "إضافة") }
                            FilledTonalIconButton({
                                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("n", number)); toast(ctx, "تم النسخ")
                            }) { Icon(Icons.Rounded.ContentCopy, "نسخ") }
                            FilledTonalIconButton({
                                if (blocked) { Blocklist.unblock(ctx, number); blocked = false; toast(ctx, "أُلغي الحظر") }
                                else if (Blocklist.block(ctx, number)) { blocked = true; toast(ctx, "تم الحظر") } else toast(ctx, "الحظر يتطلب جعل التطبيق الهاتف الافتراضي")
                            }, colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = if (blocked) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer)) {
                                Icon(Icons.Rounded.Block, "حظر")
                            }
                        }
                    }
                }
                item { SectionTitle("سجل المكالمات (${mine.size})") }
                items(mine, key = { it.id }) { e ->
                    val (icon, label, bad) = typeInfo(e.type)
                    ListItem({ Text(label, color = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface) },
                        supportingContent = { Text(dayLabel(e.date) + " • " + timeLabel(e.date) + durLabel(e.duration).let { if (it.isEmpty()) "" else " • $it" }) },
                        leadingContent = { Icon(icon, null, tint = if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant) },
                        trailingContent = { IconButton({ vm.delete(listOf(e.id)) }) { Icon(Icons.Rounded.Delete, "حذف") } })
                }
                item { SectionTitle("الرسائل") }
                item {
                    val t = thread
                    ListItem({ Text(t?.snippet ?: "لا توجد رسائل مع هذا الرقم", maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(if (t != null) "${t.count} رسالة • ${t.date.readableDate()}" else "ابدأ محادثة جديدة") },
                        leadingContent = { Icon(Icons.AutoMirrored.Rounded.Message, null) },
                        modifier = Modifier.clickable { onSms(number) })
                }
            }
        }
    }
}

// ───────────────────────── إعدادات الهاتف ─────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = (ctx.applicationContext as FileApp).prefs
    val (isDefault, requestDefault) = rememberDefaultDialer()
    var dnd by remember { mutableIntStateOf(prefs.dndMode) }
    var repeat by remember { mutableStateOf(prefs.dndRepeat) }
    var rec by remember { mutableIntStateOf(prefs.autoRecord) }
    var vib by remember { mutableStateOf(prefs.vibrate) }
    var ring by remember { mutableStateOf(prefs.ringtone) }
    var blocked by remember { mutableStateOf(Blocklist.list(ctx)) }
    var newBlock by remember { mutableStateOf("") }
    var quick by remember { mutableStateOf(prefs.quickReplies) }
    val ringTitle = remember(ring) { runCatching { RingtoneManager.getRingtone(ctx, ring?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)).getTitle(ctx) }.getOrDefault("الافتراضي") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        IntentCompat.getParcelableExtra(r.data ?: return@rememberLauncherForActivityResult, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            ?.let { ring = it.toString(); prefs.ringtone = it.toString() }
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    @Composable fun Chips(opts: List<String>, cur: Int, onPick: (Int) -> Unit) =
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            opts.forEachIndexed { i, l -> FilterChip(cur == i, { onPick(i) }, { Text(l) }) }
        }

    Scaffold(topBar = { TopAppBar(title = { Text("إعدادات الهاتف") }, navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 32.dp)) {
            item { SectionTitle("التطبيق الافتراضي") }
            item {
                ListItem({ Text(if (isDefault) "ملفاتي هو تطبيق الهاتف الافتراضي" else "ملفاتي ليس الافتراضي") },
                    supportingContent = { Text("مطلوب لاستقبال المكالمات بشاشة كاملة، والحظر، وعدم الإزعاج.") },
                    leadingContent = { Icon(if (isDefault) Icons.Rounded.CheckCircle else Icons.Rounded.Warning, null, tint = if (isDefault) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error) },
                    trailingContent = { if (!isDefault) TextButton(requestDefault) { Text("تعيين") } })
            }
            item { SectionTitle("عدم الإزعاج") }
            item { Chips(listOf("إيقاف", "غير المعروفة", "الكل عدا المفضلة"), dnd) { dnd = it; prefs.dndMode = it } }
            item {
                Text("تُفصل المكالمة فور وصولها دون رنين ولا إشعار، وتبقى ظاهرة في السجل ضمن «محجوبة». «غير المعروفة» = أرقام ليست في جهات اتصالك. المفضلة = الجهات المميّزة بنجمة.",
                    Modifier.padding(20.dp, 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                ListItem({ Text("السماح بالاتصال المتكرر") }, supportingContent = { Text("إن اتصل الرقم نفسه ثانية خلال 3 دقائق تُمرَّر المكالمة (قد تكون طارئة).") },
                    trailingContent = { Switch(repeat, { repeat = it; prefs.dndRepeat = it }) })
            }
            item { SectionTitle("الرنين") }
            item {
                ListItem({ Text("نغمة الرنين") }, supportingContent = { Text(ringTitle) }, leadingContent = { Icon(Icons.Rounded.MusicNote, null) },
                    modifier = Modifier.clickable {
                        pick.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                            .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, ring?.let(Uri::parse)))
                    })
                ListItem({ Text("الاهتزاز") }, leadingContent = { Icon(Icons.Rounded.Vibration, null) }, trailingContent = { Switch(vib, { vib = it; prefs.vibrate = it }) })
            }
            item { SectionTitle("تسجيل المكالمات") }
            item {
                Chips(listOf("إيقاف", "الكل", "غير المعروفة"), rec) {
                    rec = it; prefs.autoRecord = it
                    if (it != 0 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPerm.launch(Manifest.permission.RECORD_AUDIO)
                }
                Text("تنبيه: أندرويد 9+ يمنع التطبيقات العادية من التقاط صوت الطرف الآخر، فغالباً يُسجَّل صوتك وما يخرج من المكبّر فقط (يلتقط الطرفين على أجهزة الروت/النظام). تسجيل المكالمات يتطلب موافقة الطرف الآخر في كثير من الدول، والمسؤولية عليك.",
                    Modifier.padding(20.dp, 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item { SectionTitle("الردود السريعة على المكالمات") }
            item {
                OutlinedTextField(quick, { quick = it; prefs.quickReplies = it }, Modifier.fillMaxWidth().padding(horizontal = 20.dp), label = { Text("رد في كل سطر") }, minLines = 3)
                Text("تظهر عند زر «رسالة» في شاشة المكالمة الواردة، وتُرسل عبر تطبيق الرسائل الافتراضي.", Modifier.padding(20.dp, 6.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item { SectionTitle("الأرقام المحظورة") }
            item {
                if (!Blocklist.canBlock(ctx)) Text("الحظر متاح فقط عندما يكون التطبيق هو الهاتف الافتراضي.", Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newBlock, { newBlock = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.weight(1f), singleLine = true, label = { Text("رقم للحظر") })
                    TextButton({ if (newBlock.isNotEmpty() && Blocklist.block(ctx, newBlock)) { newBlock = ""; blocked = Blocklist.list(ctx) } else toast(ctx, "تعذّر الحظر") }) { Text("حظر") }
                }
            }
            items(blocked, key = { "b$it" }) { n ->
                ListItem({ CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Text(n) } }, leadingContent = { Icon(Icons.Rounded.Block, null) },
                    trailingContent = { TextButton({ Blocklist.unblock(ctx, n); blocked = Blocklist.list(ctx) }) { Text("إلغاء الحظر") } })
            }
        }
    }
}
