package app.aero.launcher

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.viewpager2.widget.ViewPager2

/** المجلد المفتوح: يكبر بعدد التطبيقات، ويتحول إلى صفحات عند الكثرة، ويفتح بأنيميشن من أيقونته. */
class FolderOverlay(private val a: MainActivity, private val folderKey: String, members: List<AppInfo>,
                    name: String, private val origin: View) : FrameLayout(a) {
    private val d = resources.displayMetrics.density
    private val panel = LinearLayout(a)

    init {
        val ins = a.root.inset
        setPadding(ins.left, ins.top, ins.right, ins.bottom)
        setBackgroundColor(0x80000000.toInt())
        isClickable = true
        setOnClickListener { close() }
        val dm = resources.displayMetrics
        val land = dm.widthPixels > dm.heightPixels
        val cellW = (78 * d).toInt(); val cellH = (90 * d).toInt()
        val pad = (14 * d).toInt(); val titleH = (44 * d).toInt(); val dotsH = (22 * d).toInt()
        val availW = dm.widthPixels - ins.left - ins.right - (32 * d).toInt()
        val availH = dm.heightPixels - ins.top - ins.bottom - (32 * d).toInt()
        val maxCols = maxOf(2, minOf(if (land) 6 else 4, (availW - 2 * pad) / cellW))
        val maxRows = maxOf(1, minOf(4, (availH - 2 * pad - titleH - dotsH) / cellH))
        val n = members.size
        val base = if (n <= 4) 2 else if (n <= 9) 3 else 4
        val cols = maxOf(base, (n + maxRows - 1) / maxRows).coerceAtMost(maxCols)
        var rows = (n + cols - 1) / cols
        var pages = 1
        if (rows > maxRows) { rows = maxRows; pages = (n + cols * rows - 1) / (cols * rows) }
        val per = cols * rows

        panel.orientation = LinearLayout.VERTICAL
        panel.isClickable = true
        panel.background = rr(0xF01E2026.toInt(), 28 * d)
        panel.setPadding(pad, pad / 2, pad, pad)
        panel.addView(TextView(a).apply {
            text = name; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setOnClickListener { a.folderMenu(folderKey) }
        }, LinearLayout.LayoutParams(cols * cellW, titleH))

        fun cell(app: AppInfo): AppCell {
            val c = AppCell(a, app, true, a.st.scale)
            c.setOnClickListener { a.launch(app, c) }
            c.setOnLongClickListener { a.folderAppMenu(folderKey, app); true }
            return c
        }
        if (pages == 1) {
            panel.addView(GridPage(a, cols, rows, members.map { cell(it) }, 0), LinearLayout.LayoutParams(cols * cellW, rows * cellH))
        } else {
            val list = ArrayList<View>()
            members.chunked(per).forEach { ch -> list.add(GridPage(a, cols, rows, ch.map { cell(it) }, 0)) }
            val vp = ViewPager2(a)
            vp.offscreenPageLimit = list.size
            vp.adapter = PagesAdapter(list)
            val dots = Dots(a); dots.count = list.size
            vp.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageScrolled(p: Int, o: Float, px: Int) { dots.pos = p + o }
            })
            panel.addView(vp, LinearLayout.LayoutParams(cols * cellW, rows * cellH))
            panel.addView(dots, LinearLayout.LayoutParams(cols * cellW, dotsH))
        }
        addView(panel, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
    }

    private fun delta(): Pair<Float, Float> {
        val ol = IntArray(2); origin.getLocationOnScreen(ol)
        val pl = IntArray(2); panel.getLocationOnScreen(pl)
        return Pair((ol[0] + origin.width / 2f) - (pl[0] + panel.width / 2f - panel.translationX),
            (ol[1] + origin.height / 2f) - (pl[1] + panel.height / 2f - panel.translationY))
    }

    fun open() {
        alpha = 0f; panel.alpha = 0f
        animate().alpha(1f).setDuration(180).start()
        post {
            val (dx, dy) = delta()
            panel.translationX = dx; panel.translationY = dy
            panel.scaleX = 0.25f; panel.scaleY = 0.25f; panel.alpha = 1f
            panel.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(330).setInterpolator(OvershootInterpolator(0.9f)).start()
        }
    }

    fun close(anim: Boolean = true) {
        a.folder = null
        if (!anim) { (parent as? ViewGroup)?.removeView(this); return }
        val (dx, dy) = delta()
        animate().alpha(0f).setDuration(220).start()
        panel.animate().translationX(dx).translationY(dy).scaleX(0.25f).scaleY(0.25f).setDuration(220)
            .withEndAction { (parent as? ViewGroup)?.removeView(this) }.start()
    }
}
