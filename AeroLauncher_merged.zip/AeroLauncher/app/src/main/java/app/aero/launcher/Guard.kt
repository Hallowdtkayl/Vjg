package app.aero.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.util.TimeZone

data class GCfg(val enabled: Boolean, val base: Int, val bonusH: Int, val bonusM: Int, val exempt: Set<String>)

/**
 * رصيد استخدام يمنع الإدمان:
 *  - كل ساعة تضيف `base` دقيقة، وعند ساعة المكافأة تضيف `bonusM` دقيقة.
 *  - الرصيد يتراكم ويُنفق متى شئت، ويُصفَّر يومياً الساعة 8:00 صباحاً.
 *  - الساعة داخلية محصّنة ضد تغيير التاريخ (تعتمد elapsedRealtime لا ساعة الجهاز).
 *  - أي تغيير يخفف القيود يُطبَّق بعد 24 ساعة؛ تشديد القيود فوري.
 */
object Guard {
    private const val HOUR = 3_600_000L
    private const val DAY = 24 * HOUR
    private const val RESET_H = 8
    const val DELAY = 24 * HOUR
    const val UNLOCK_WAIT = 30 * 60_000L
    const val UNLOCK_LEN = 10 * 60_000L
    const val OWN = "app.aero.launcher"

    /** لا تُحتسب ولا تُحجب أبداً (النظام، المكالمات، اللانشر نفسه). */
    val NEUTRAL = setOf(OWN, "com.android.systemui", "android", "com.android.server.telecom", "com.android.incallui",
        "com.android.phone", "com.android.emergency", "com.google.android.permissioncontroller", "com.android.permissioncontroller")

    /** شاشات يمكن بها التحايل (الإعدادات، المثبّت): مقفلة طوال تفعيل الحماية إلا بنافذة فتح مؤجلة. */
    val GUARDED = setOf("com.android.settings", "com.android.packageinstaller",
        "com.google.android.packageinstaller", "com.samsung.android.packageinstaller")

    @Volatile var blocked = false
    @Volatile var enabled = false
    @Volatile var exempt: Set<String> = emptySet()

    private fun sp(c: Context) = c.getSharedPreferences("aero", Context.MODE_PRIVATE)

    // ---------- الساعة المحصّنة ----------
    fun now(c: Context): Long {
        val p = sp(c)
        val wall = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        val boot = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)
        val lastEl = p.getLong("g_el", -1L); val lastLog = p.getLong("g_log", -1L)
        val lastBoot = p.getInt("g_boot", -2)
        var off = p.getLong("g_off", 0L)
        val logical: Long
        if (lastLog < 0) { logical = wall; off = 0L }
        else if (boot == lastBoot && el >= lastEl) { logical = lastLog + (el - lastEl); off = logical - wall }
        else { var l = wall + off; if (l < lastLog) l = lastLog; logical = l; off = l - wall }
        p.edit().putLong("g_el", el).putLong("g_log", logical).putLong("g_off", off).putInt("g_boot", boot).apply()
        return logical
    }

    fun tz(c: Context): TimeZone {
        val p = sp(c)
        val id = p.getString("g_tz", null) ?: TimeZone.getDefault().id.also { p.edit().putString("g_tz", it).apply() }
        return TimeZone.getTimeZone(id)
    }

    private fun local(c: Context, t: Long) = t + tz(c).getOffset(t)
    private fun dayIndex(c: Context, t: Long) = Math.floorDiv(local(c, t) - RESET_H * HOUR, DAY)

    // ---------- الرصيد ----------
    fun earned(c: Context, g: GCfg, t: Long): Long {
        val lt = local(c, t)
        val start = Math.floorDiv(lt - RESET_H * HOUR, DAY) * DAY + RESET_H * HOUR
        val n = ((lt - start) / HOUR).toInt()
        var m = 0L
        for (k in 0..n) { val h = (RESET_H + k) % 24; m += if (h == g.bonusH) g.bonusM else g.base }
        return m * 60_000L
    }

    fun used(c: Context, t: Long): Long {
        val p = sp(c); val di = dayIndex(c, t)
        if (p.getLong("g_day", Long.MIN_VALUE) != di) { p.edit().putLong("g_day", di).putLong("g_used", 0L).apply(); return 0L }
        return p.getLong("g_used", 0L)
    }

    fun addUsed(c: Context, t: Long, ms: Long) { val u = used(c, t) + ms; sp(c).edit().putLong("g_used", u).apply() }
    fun remainingMs(c: Context): Long { val g = cfg(c); val t = now(c); return earned(c, g, t) - used(c, t) }
    fun nextGrantMs(c: Context): Long {
        val lt = local(c, now(c))
        return HOUR - Math.floorMod(lt - RESET_H * HOUR, HOUR)
    }

    // ---------- الإعدادات (مع تأخير التخفيف) ----------
    private fun toJson(g: GCfg) = JSONObject().put("e", g.enabled).put("b", g.base).put("h", g.bonusH)
        .put("m", g.bonusM).put("x", JSONArray(g.exempt.toList())).toString()

    private fun fromJson(s: String): GCfg {
        val o = JSONObject(s); val a = o.getJSONArray("x")
        return GCfg(o.getBoolean("e"), o.getInt("b"), o.getInt("h"), o.getInt("m"), (0 until a.length()).map { a.getString(it) }.toSet())
    }

    private val DEFAULT = GCfg(false, 2, 20, 20, emptySet())

    fun cfg(c: Context): GCfg {
        val p = sp(c)
        val st = p.getString("g_staged", null)
        if (st != null && now(c) >= p.getLong("g_stagedAt", Long.MAX_VALUE)) {
            p.edit().putString("g_cfg", st).remove("g_staged").remove("g_stagedAt").apply()
        }
        val s = p.getString("g_cfg", null)
        return if (s != null) fromJson(s) else DEFAULT
    }

    /** الإعداد الذي يعدّله المستخدم: المعلّق إن وجد وإلا المطبّق. */
    fun working(c: Context): GCfg {
        val s = sp(c).getString("g_staged", null)
        return if (s != null) fromJson(s) else cfg(c)
    }

    fun stagedRemainingMs(c: Context): Long? {
        val p = sp(c)
        if (p.getString("g_staged", null) == null) return null
        return p.getLong("g_stagedAt", 0L) - now(c)
    }

    /** true = طُبّق فوراً، false = معلّق 24 ساعة لأنه يخفف القيود. */
    fun submit(c: Context, n: GCfg): Boolean {
        val cur = cfg(c); val p = sp(c)
        val weaker = cur.enabled && (!n.enabled || 23 * n.base + n.bonusM > 23 * cur.base + cur.bonusM ||
            n.bonusH != cur.bonusH || (n.exempt - cur.exempt).isNotEmpty())
        if (!weaker) {
            p.edit().putString("g_cfg", toJson(n)).remove("g_staged").remove("g_stagedAt").apply()
            refresh(c); return true
        }
        p.edit().putString("g_staged", toJson(n)).putLong("g_stagedAt", now(c) + DELAY).apply()
        return false
    }

    fun cancelStaged(c: Context) { sp(c).edit().remove("g_staged").remove("g_stagedAt").apply() }

    // ---------- فتح الإعدادات بتأخير ----------
    fun requestUnlock(c: Context) {
        val t = now(c)
        sp(c).edit().putLong("g_ulAt", t + UNLOCK_WAIT).putLong("g_ulUntil", t + UNLOCK_WAIT + UNLOCK_LEN).apply()
    }
    fun unlockInfo(c: Context): Pair<Long, Long> { val p = sp(c); return Pair(p.getLong("g_ulAt", 0L), p.getLong("g_ulUntil", 0L)) }
    fun settingsOpen(c: Context): Boolean { val (a, u) = unlockInfo(c); val t = now(c); return t in a until u }

    // ---------- الحالة الفورية ----------
    fun refresh(c: Context): Boolean {
        val g = cfg(c)
        enabled = g.enabled
        exempt = g.exempt
        if (!g.enabled) { blocked = false; return false }
        val t = now(c)
        blocked = earned(c, g, t) - used(c, t) <= 0 || !NavService.active
        return blocked
    }

    fun isNeutral(pkg: String) = pkg in NEUTRAL
    fun isExempt(pkg: String) = pkg.isEmpty() || pkg in NEUTRAL || pkg in exempt
    fun dimmed(pkg: String) = blocked && !isExempt(pkg)

    /** الهاتف والكاميرا والحاسبة والمترجم (واللانشر والنظام عبر NEUTRAL). */
    fun defaultExempt(c: Context): Set<String> {
        val pm = c.packageManager
        val s = HashSet<String>()
        fun add(i: Intent) {
            val p = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (p != null && p != "android") s.add(p)
        }
        add(Intent(Intent.ACTION_DIAL))
        add(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        add(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        add(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
        s.addAll(listOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.google.android.apps.translate", "com.microsoft.translator", "com.deepl.mobile",
            "com.android.camera", "com.android.camera2", "com.google.android.GoogleCamera", "com.sec.android.app.camera",
            "com.google.android.calculator", "com.android.calculator2", "com.sec.android.app.popupcalculator"))
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(li, 0).forEach {
            val p = it.activityInfo.packageName
            if (p.contains("translat") || p.contains("calculator")) s.add(p)
        }
        return s
    }
}
