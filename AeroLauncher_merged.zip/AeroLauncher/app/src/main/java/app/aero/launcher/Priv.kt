package app.aero.launcher

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * كل ما يحتاج صلاحيات خاصة يمر من هنا: روت (su) أو Shizuku (صلاحية shell).
 * لا نطلب إمكانية الوصول ولا أي صلاحية يدوية.
 */
object Priv {
    /** "root" أو "shizuku" أو "" (لم يُحدَّد بعد). */
    @Volatile var mode: String = ""

    fun shizukuAlive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun shizukuGranted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun shizukuRequest() { try { Shizuku.requestPermission(4242) } catch (e: Throwable) {} }

    /** تنفيذ أمر عبر Shizuku (newProcess خاصة في الإصدارات الحديثة فنستدعيها بالانعكاس). */
    fun viaShizuku(cmd: String, seconds: Long): RootSh.Out = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val text = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(seconds, java.util.concurrent.TimeUnit.SECONDS)) { p.destroy(); RootSh.Out(-1, text) }
        else RootSh.Out(p.exitValue(), text)
    } catch (e: Throwable) { RootSh.Out(-1, e.message ?: e.javaClass.simpleName) }

    fun label(): String = when (mode) {
        "root" -> "روت"
        "shizuku" -> "Shizuku"
        else -> "—"
    }
}
