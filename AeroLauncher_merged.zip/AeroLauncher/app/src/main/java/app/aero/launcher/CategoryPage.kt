package app.aero.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/** مكتبة التطبيقات: كل التطبيقات في تصنيفات (10 كحد أقصى). المس عنوان التصنيف لطيّه. */
class CategoryPage(ctx: Context) : ScrollView(ctx) {
    private val d = resources.displayMetrics.density
    private val col = LinearLayout(ctx)

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        col.orientation = LinearLayout.VERTICAL
        val p = (8 * d).toInt()
        col.setPadding(p, p, p, (24 * d).toInt())
        addView(col, FrameLayout.LayoutParams(-1, -2))
    }

    fun toolbar(copy: () -> Unit, paste: () -> Unit, reset: () -> Unit) {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, f: () -> Unit): TextView = TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; maxLines = 2
            background = rr(0x4D000000, 22 * d)
            setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
            setOnClickListener { f() }
        }
        val lp = { LinearLayout.LayoutParams(0, (48 * d).toInt(), 1f).apply { setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0) } }
        row.addView(btn("1) نسخ أمر الذكاء الاصطناعي", copy), lp())
        row.addView(btn("2) لصق الرد وتطبيقه", paste), lp())
        row.addView(btn("تصنيف تلقائي", reset), lp())
        col.addView(row)
        col.addView(TextView(context).apply {
            text = "انسخ الأمر ← الصقه في أي ذكاء اصطناعي ← انسخ رده ← اضغط «لصق الرد». اضغط مطولاً على أي تطبيق لتغيير تصنيفه."
            setTextColor(0xB3FFFFFF.toInt()); textSize = 12f
            setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), 0)
        })
    }

    private var grid: TileGrid? = null
    fun section(title: String, apps: List<AppInfo>, cols: Int, onOpen: () -> Unit) {
        val g = grid ?: TileGrid(context, cols).also { grid = it; col.addView(it, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * d).toInt() }) }
        g.addView(BigFolderTile(context, title, apps).also { it.setOnClickListener { onOpen() } })
    }
}

class FlowGrid(ctx: Context, private val cols: Int) : ViewGroup(ctx) {
    private val d = resources.displayMetrics.density
    private fun cellH(w: Int): Int = minOf(((w / cols) * 1.25f).toInt(), (96 * d).toInt())
    override fun onMeasure(ws: Int, hs: Int) {
        val w = sz(ws); val rows = (childCount + cols - 1) / cols; val ch = cellH(w)
        setMeasuredDimension(w, rows * ch)
        for (i in 0 until childCount) getChildAt(i).measure(ex(w / cols), ex(ch))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l; val cw = w / cols; val ch = cellH(w)
        for (i in 0 until childCount) {
            val x = (i % cols) * cw; val y = (i / cols) * ch
            getChildAt(i).layout(x, y, x + cw, y + ch)
        }
    }
}

// شبكة مجلدات كبيرة: عمودان طولي / 3 أفقي
class TileGrid(ctx: Context, private val cols: Int) : ViewGroup(ctx) {
    private val m get() = (4 * resources.displayMetrics.density).toInt()
    private fun ch(w: Int) = ((w / cols) * 0.95f).toInt()
    override fun onMeasure(ws: Int, hs: Int) {
        val w = sz(ws); val cw = w / cols; val h = ch(w); val rows = (childCount + cols - 1) / cols
        setMeasuredDimension(w, rows * h)
        for (i in 0 until childCount) getChildAt(i).measure(ex(cw - 2 * m), ex(h - 2 * m))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols; val h = ch(r - l)
        for (i in 0 until childCount) { val x = (i % cols) * cw; val y = (i / cols) * h; getChildAt(i).layout(x + m, y + m, x + cw - m, y + h - m) }
    }
}

// مجلد كبير: عنوان + معاينة 3×3 (أول 8 + عدّاد الباقي)
class BigFolderTile(ctx: Context, private val title: String, private val apps: List<AppInfo>) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    init { isClickable = true }
    override fun setPressed(pressed: Boolean) { super.setPressed(pressed); val s = if (pressed) 0.95f else 1f; animate().scaleX(s).scaleY(s).setDuration(110).start() }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRoundRect(RectF(0f, 0f, w, h), 26 * d, 26 * d, bg)
        val pad = 12 * d; val label = "$title  (${apps.size})"
        tp.textSize = 15 * d; val tw = tp.measureText(label)
        if (tw > w - 2 * pad) tp.textSize = tp.textSize * (w - 2 * pad) / tw
        c.drawText(label, w / 2f, pad + 15 * d, tp)
        val top = pad * 2 + 16 * d; val cell = min(w - 2 * pad, h - top - pad) / 3f; val x0 = (w - cell * 3) / 2f
        val more = apps.size > 9; val shown = if (more) 8 else apps.size
        for (i in 0 until shown) {
            val a = apps[i]; val l = x0 + (i % 3) * cell + cell * 0.1f; val t = top + (i / 3) * cell + cell * 0.1f; val s = cell * 0.8f
            val cb = a.custom
            if (cb != null) c.drawBitmap(cb, null, RectF(l, t, l + s, t + s), bp)
            else { a.icon.setBounds(l.toInt(), t.toInt(), (l + s).toInt(), (t + s).toInt()); a.icon.draw(c) }
        }
        if (more) { tp.textSize = cell * 0.3f; c.drawText("+${apps.size - 8}", x0 + 2.5f * cell, top + 2 * cell + cell * 0.58f, tp) }
    }
}

// لوح فتح المجلد الكبير (مستقل عن FolderOverlay). اضغط الخلفية للإغلاق
class MaxScroll(ctx: Context) : ScrollView(ctx) {
    override fun onMeasure(ws: Int, hs: Int) =
        super.onMeasure(ws, MeasureSpec.makeMeasureSpec((resources.displayMetrics.heightPixels * 0.66f).toInt(), MeasureSpec.AT_MOST))
}
class CatOverlay(ctx: Context, title: String, apps: List<AppInfo>, cols: Int, cellOf: (AppInfo) -> AppCell, private val onClose: () -> Unit) : FrameLayout(ctx) {
    private val d = resources.displayMetrics.density
    init {
        setBackgroundColor(0x99000000.toInt()); isClickable = true
        setOnClickListener { close() }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; isClickable = true
            background = rr(0xF0101216.toInt(), 28 * d)
            val p = (10 * d).toInt(); setPadding(p, p, p, p)
        }
        box.addView(TextView(ctx).apply {
            text = "$title  (${apps.size})"; setTextColor(Color.WHITE); textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
        })
        val sv = MaxScroll(ctx).apply { isVerticalScrollBarEnabled = false }
        val g = FlowGrid(ctx, cols); apps.forEach { g.addView(cellOf(it)) }
        sv.addView(g, FrameLayout.LayoutParams(-1, -2))
        box.addView(sv, LinearLayout.LayoutParams(-1, -2))
        val mg = (16 * d).toInt()
        addView(box, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(mg, mg, mg, mg) })
        alpha = 0f; animate().alpha(1f).setDuration(160).start()
    }
    fun close() {
        onClose()
        animate().alpha(0f).setDuration(140).withEndAction { (parent as? ViewGroup)?.removeView(this) }.start()
    }
}
