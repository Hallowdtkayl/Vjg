package app.aero.launcher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** منتقي الويدجت: معاينة بشكل الويدجت وحجمه. اضغط للإضافة أو اسحب وأفلت على الشاشة الرئيسية. */
class WidgetPicker(private val a: MainActivity) : FrameLayout(a) {
    private val d = resources.displayMetrics.density
    private val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private val panel = LinearLayout(a)
    private var ghost: ImageView? = null
    private var drag: AppWidgetProviderInfo? = null
    private var gw = 0
    private var gh = 0

    init {
        setBackgroundColor(0x66000000)
        isClickable = true
        setOnClickListener { close() }
        val ins = a.root.inset
        panel.orientation = LinearLayout.VERTICAL
        panel.isClickable = true
        panel.setPadding(ins.left + (12 * d).toInt(), (14 * d).toInt(), ins.right + (12 * d).toInt(), ins.bottom + (14 * d).toInt())
        panel.background = GradientDrawable().apply {
            setColor(0xF21B1C21.toInt()); val r = 28 * d
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        panel.addView(TextView(a).apply {
            text = "الويدجت — اضغط للإضافة أو اسحب إلى الشاشة"
            setTextColor(Color.WHITE); textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding((8 * d).toInt(), 0, (8 * d).toInt(), (10 * d).toInt())
        })
        val hs = HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(a)
        val pm = a.packageManager
        AppWidgetManager.getInstance(a).installedProviders.sortedBy { it.loadLabel(pm).lowercase() }.forEach {
            row.addView(card(it), LinearLayout.LayoutParams(-2, -2).apply { marginEnd = (10 * d).toInt() })
        }
        hs.addView(row)
        panel.addView(hs)
        addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    }

    private fun card(p: AppWidgetProviderInfo): View {
        val wpx = ((if (land) 104 else 130) * d).toInt()
        val ratio = (p.minHeight.toFloat() / maxOf(p.minWidth, 1)).coerceIn(0.4f, 1.1f)
        val hpx = (wpx * ratio).toInt()
        val cellsW = ((p.minWidth / d + 30) / 70).toInt().coerceAtLeast(1)
        val cellsH = ((p.minHeight / d + 30) / 70).toInt().coerceAtLeast(1)
        val pv = try { p.loadPreviewImage(a, 0) } catch (e: Exception) { null } ?: p.loadIcon(a, 0)
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val img = ImageView(a).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rr(0x26FFFFFF, 14 * d)
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            setImageDrawable(pv)
        }
        box.addView(img, LinearLayout.LayoutParams(wpx, hpx))
        box.addView(TextView(a).apply {
            text = p.loadLabel(a.packageManager); setTextColor(Color.WHITE); textSize = 12f
            maxLines = 2; gravity = Gravity.CENTER; setPadding(0, (6 * d).toInt(), 0, 0)
        }, LinearLayout.LayoutParams(wpx, -2))
        box.addView(TextView(a).apply { text = "$cellsW×$cellsH"; setTextColor(0x99FFFFFF.toInt()); textSize = 11f; gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(wpx, -2))
        box.setOnClickListener { close(); a.addWidget(p, null) }
        box.setOnLongClickListener {
            box.parent?.requestDisallowInterceptTouchEvent(true)
            box.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            startDrag(p, img, wpx, hpx); true
        }
        box.setOnTouchListener { _, e ->
            if (ghost != null) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_MOVE -> moveGhost(e.rawX, e.rawY)
                    MotionEvent.ACTION_UP -> endDrag(e.rawX, e.rawY)
                    MotionEvent.ACTION_CANCEL -> restore()
                }
                true
            } else false
        }
        return box
    }

    private fun startDrag(p: AppWidgetProviderInfo, src: ImageView, w: Int, h: Int) {
        drag = p; gw = w; gh = h
        val g = ImageView(a).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rr(0xE62A2C33.toInt(), 14 * d)
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            setImageDrawable(src.drawable); elevation = 12 * d
        }
        addView(g, FrameLayout.LayoutParams(w, h))
        ghost = g
        setBackgroundColor(0)
        panel.animate().alpha(0.0f).setDuration(150).start()
        val loc = IntArray(2); src.getLocationOnScreen(loc)
        moveGhost(loc[0] + w / 2f, loc[1] + h / 2f)
    }

    private fun moveGhost(x: Float, y: Float) {
        val g = ghost ?: return
        val loc = IntArray(2); getLocationOnScreen(loc)
        g.translationX = x - loc[0] - gw / 2f
        g.translationY = y - loc[1] - gh / 2f
    }

    private fun endDrag(x: Float, y: Float) {
        val p = drag
        val idx = a.widgetDropIndex(x, y)
        ghost?.let { removeView(it) }; ghost = null; drag = null
        if (p != null && idx != null) { close(false); a.addWidget(p, idx) } else restore()
    }

    private fun restore() {
        ghost?.let { removeView(it) }; ghost = null; drag = null
        setBackgroundColor(0x66000000)
        panel.animate().alpha(1f).setDuration(150).start()
    }

    fun open() {
        alpha = 0f; panel.translationY = 400f * d
        animate().alpha(1f).setDuration(180).start()
        panel.animate().translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator(2f)).start()
    }

    fun close(anim: Boolean = true) {
        a.picker = null
        if (anim) animate().alpha(0f).setDuration(150).withEndAction { (parent as? ViewGroup)?.removeView(this) }.start()
        else (parent as? ViewGroup)?.removeView(this)
    }
}
