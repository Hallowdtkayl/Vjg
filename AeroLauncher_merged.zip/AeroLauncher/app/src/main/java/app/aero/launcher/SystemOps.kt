package app.aero.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.util.concurrent.Executors

/**
 * ما يمكن لتطبيق عادي فعله مع نظام crDroid: لا توجد (فيما وجدته) واجهة عامة في crDroid لطلب freeform أو التجميد،
 * لذلك نستخدم آليات أندرويد القياسية التي يطبّقها النظام نفسه:
 *  - freeform: النوافذ تُفتح بالنظام نفسه (فيظهر شريط عنوانها وتغيير حجمها من crDroid) عبر
 *    `am start --windowingMode 5` بالروت، أو launch bounds بدونه.
 *  - التجميد: `pm disable-user` بالروت.
 */

/** حالة الروت المشتركة بين اللانشر وشريط المهام وتقسيم الشاشة. */
object RootAccess {
    @Volatile var state: Boolean? = null   // null = لم يُفحص بعد
    private val ex = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("aero", Context.MODE_PRIVATE)

    fun set(ctx: Context, ok: Boolean) {
        state = ok
        prefs(ctx).edit().putBoolean("rootOk", ok).apply()
    }

    /** فحص متزامن (على خيط خلفي فقط): قد ينتظر نافذة Magisk حتى 30 ثانية. */
    fun check(ctx: Context): Boolean {
        val p = RootSh.probe()
        val ok = p.code == 0 && p.text.trim() == "0"
        set(ctx, ok)
        return ok
    }

    /** عند التشغيل: إن كان الروت ممنوحاً سابقاً نتحقق بصمت (لا نافذة طلب جديدة). */
    fun init(ctx: Context) {
        if (state != null || !prefs(ctx).getBoolean("rootOk", false)) return
        ex.execute { check(ctx) }
    }

    /** طلب الروت صراحةً (يُظهر نافذة Magisk/KernelSU أول مرة)؛ النتيجة على الخيط الرئيسي. */
    fun request(ctx: Context, done: (Boolean, String) -> Unit) {
        ex.execute {
            val p = RootSh.probe()
            val ok = p.code == 0 && p.text.trim() == "0"
            set(ctx, ok)
            main.post { done(ok, p.text.trim().take(120)) }
        }
    }

    fun label(): String = when (state) {
        true -> "متاح ✓ (${Priv.label()})"
        false -> "غير متاح ✗"
        null -> "لم يُفحص"
    }
}

/** التحكم بنوافذ التطبيقات (مشترك بين التقسيم والنافذة المنبثقة وشريط المهام). */
object WinCtl {
    @Volatile var lastOp: String = ""

    /** أسماء الحزم والمكوّنات تمر في أمر su: نقبل الأحرف المعتادة فقط. */
    fun safe(s: String): Boolean = s.isNotEmpty() && Regex("[A-Za-z0-9._$/]+").matches(s)

    // ---------- بدون روت ----------
    fun boundsLaunch(ctx: Context, c: ComponentName, r: Rect) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(c)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val o = ActivityOptions.makeBasic().setLaunchBounds(r)
        ctx.startActivity(i, o.toBundle())
        Thread.sleep(150)
    }

    // ---------- بالروت ----------
    /** سطر المهمة الأنسب للحزمة من dumpsys (يفضّل الظاهرة). */
    fun taskLine(dump: String, pkg: String): String? {
        val re = Regex("Task\\{[^}]*?#(\\d+)[^}]*?[=:/]" + Regex.escape(pkg) + "[\\s/:}]")
        val m = dump.lines().filter { it.contains("Task{") && re.containsMatchIn(it) }
        return m.firstOrNull { it.contains("visible=true") } ?: m.firstOrNull()
    }

    private fun idOf(line: String): Int =
        Regex("Task\\{[^}]*?#(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: -1

    fun findTask(pkg: String): Int {
        val line = taskLine(RootSh.run("dumpsys activity recents").text, pkg) ?: return -1
        return idOf(line)
    }

    fun modeOf(pkg: String): String {
        val line = taskLine(RootSh.run("dumpsys activity recents").text, pkg) ?: return "؟"
        return Regex("mode=([\\w-]+)").find(line)?.groupValues?.get(1) ?: "؟"
    }

    fun launchRoot(c: ComponentName, sb: StringBuilder): Int {
        val comp = c.flattenToShortString()
        if (!safe(comp)) { sb.append("  ✗ اسم غير صالح: $comp\n"); return -1 }
        var o = RootSh.run("am start -n '$comp' --windowingMode 5")
        if (o.code != 0 || o.text.contains("Error") || o.text.contains("Unknown option")) {
            sb.append("  am start --windowingMode: ").append(o.text.trim().take(120)).append('\n')
            o = RootSh.run("am start -n '$comp'")
        }
        repeat(16) {
            val id = findTask(c.packageName)
            if (id > 0) return id
            Thread.sleep(250)
        }
        sb.append("  ✗ لم أجد مهمة ${c.packageName}: ").append(o.text.trim().take(120)).append('\n')
        return -1
    }

    fun resize(id: Int, r: Rect, sb: StringBuilder): Boolean {
        val a = "${r.left} ${r.top} ${r.right} ${r.bottom}"
        val tries = listOf(
            "cmd activity task resize $id $a",
            "am task resize $id $a",
            "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}"
        )
        var err = ""
        for (t in tries) {
            val o = RootSh.run(t)
            val bad = o.code != 0 || o.text.contains("Exception") || o.text.contains("Error") || o.text.contains("Unknown")
            if (!bad) return true
            err = o.text.trim().lines().firstOrNull().orEmpty()
        }
        sb.append("  ✗ تحجيم #$id: $err\n")
        return false
    }

    /** يضع التطبيق في المستطيل r بالروت (freeform ثم تحجيم)؛ إن لم يصبح freeform نجرّب launch bounds. يعيد رقم المهمة أو -1. */
    fun placeRoot(ctx: Context, c: ComponentName, r: Rect, sb: StringBuilder): Int {
        var id = launchRoot(c, sb)
        if (id <= 0) return -1
        var ok = resize(id, r, sb)
        val m = modeOf(c.packageName)
        if (ok && m != "freeform") {
            sb.append("  ${c.packageName}: الوضع $m، أجرّب launch bounds\n")
            try { boundsLaunch(ctx, c, r); Thread.sleep(600) } catch (e: Exception) { sb.append("  ✗ ${e.message}\n") }
            val id2 = findTask(c.packageName)
            if (id2 > 0) { id = id2; ok = resize(id2, r, sb) }
        }
        return if (ok) id else -1
    }
}

/** نافذة منبثقة (freeform) في منتصف الشاشة، يغيّر النظام حجمها بنفسه. */
object Freeform {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun popupRect(ctx: Context, taskbarPx: Int): Rect {
        val a = Split.area(ctx, taskbarPx)
        val land = a.width() > a.height()
        val w = (a.width() * (if (land) 0.5f else 0.86f)).toInt()
        val h = (a.height() * (if (land) 0.88f else 0.62f)).toInt()
        val l = a.left + (a.width() - w) / 2
        val t = a.top + (a.height() - h) / 2
        return Rect(l, t, l + w, t + h)
    }

    fun open(ctx: Context, c: ComponentName, r: Rect, done: (String) -> Unit) {
        io.execute {
            val sb = StringBuilder("نافذة منبثقة: ${c.packageName}\n")
            val root = if (RootAccess.state == true) true else RootAccess.check(ctx)
            val msg: String
            if (root) {
                val id = WinCtl.placeRoot(ctx, c, r, sb)
                msg = if (id > 0) "فُتح كنافذة منبثقة" else "تعذّر فتحه كنافذة — افتح «الصلاحيات» في الإعدادات"
            } else {
                msg = try {
                    WinCtl.boundsLaunch(ctx, c, r)
                    sb.append("بدون روت: launch bounds\n")
                    "فُتح (بدون روت/Shizuku: يعمل مع التطبيقات غير المفتوحة مسبقاً)"
                } catch (e: Exception) { sb.append("✗ ${e.message}\n"); "تعذّر الفتح: ${e.message}" }
            }
            WinCtl.lastOp = sb.toString()
            main.post { done(msg) }
        }
    }
}

/** تجميد التطبيقات (pm disable-user) بالروت أو Shizuku؛ المجمّد يبقى في اللانشر بأيقونة شاحبة. */
object Freezer {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val deny = setOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone",
        "com.android.server.telecom", "com.android.providers.settings", "com.android.packageinstaller",
        "com.google.android.packageinstaller"
    )

    fun blocked(ctx: Context, pkg: String): Boolean {
        if (pkg == ctx.packageName || pkg in deny) return true
        val ime = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')
        if (pkg == ime) return true
        val home = ctx.packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        return pkg == home
    }

    private fun run(ctx: Context, pkg: String, enable: Boolean, done: (Boolean, String) -> Unit) {
        io.execute {
            val sb = StringBuilder()
            var ok = false
            var msg: String
            if (!WinCtl.safe(pkg)) {
                msg = "اسم الحزمة غير صالح"
            } else if (!(if (RootAccess.state == true) true else RootAccess.check(ctx))) {
                msg = "يحتاج روت أو Shizuku — الإعدادات ← الصلاحيات"
            } else {
                if (!enable) sb.append(RootSh.run("am force-stop $pkg").text)
                val o = RootSh.run(if (enable) "pm enable $pkg" else "pm disable-user --user 0 $pkg")
                sb.append(o.text)
                val t = o.text.lowercase()
                ok = o.code == 0 && (if (enable) t.contains("enabled") else t.contains("disabled"))
                msg = if (ok) (if (enable) "فُكّ التجميد" else "جُمِّد التطبيق") else "فشل: " + o.text.trim().take(100)
            }
            WinCtl.lastOp = "${if (enable) "فك تجميد" else "تجميد"} $pkg\n$sb"
            main.post { done(ok, msg) }
        }
    }

    fun freeze(ctx: Context, pkg: String, done: (Boolean, String) -> Unit) = run(ctx, pkg, false, done)
    fun unfreeze(ctx: Context, pkg: String, done: (Boolean, String) -> Unit) = run(ctx, pkg, true, done)
}
