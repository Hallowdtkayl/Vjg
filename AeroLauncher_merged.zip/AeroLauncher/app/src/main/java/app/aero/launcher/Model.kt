package app.aero.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject

class AppInfo(val key: String, val pkg: String, val cls: String, val orig: String, val icon: Drawable) {
    var label: String = orig
    var custom: Bitmap? = null
    var frozen = false
    fun launchIntent(): Intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(pkg, cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
}

data class FolderData(val id: String, val name: String, val apps: List<String>, val main: String) {
    val key: String get() = "folder:$id"
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("aero", Context.MODE_PRIVATE)
    private fun lst(k: String): List<String> = (sp.getString(k, "") ?: "").split("\n").filter { it.isNotEmpty() }
    private fun put(k: String, l: List<String>) { sp.edit().putString(k, l.joinToString("\n")).apply() }
    private fun obj(k: String) = JSONObject(sp.getString(k, "{}") ?: "{}")
    private fun putObj(k: String, o: JSONObject) { sp.edit().putString(k, o.toString()).apply() }

    var hidden: List<String>
        get() = lst("hidden")
        set(v) = put("hidden", v)
    var home: List<String>
        get() = lst("home")
        set(v) = put("home", v)
    var dock: List<String>
        get() = lst("dock")
        set(v) = put("dock", v)
    var widgets: List<Int>
        get() = lst("widgets").map { it.toInt() }
        set(v) = put("widgets", v.map { it.toString() })
    var scale: Float
        get() = sp.getFloat("scale", 1f)
        set(v) { sp.edit().putFloat("scale", v).apply() }
    var initDone: Boolean
        get() = sp.getBoolean("init", false)
        set(v) { sp.edit().putBoolean("init", v).apply() }

    fun cat(pkg: String): Int? {
        val o = obj("cats")
        if (!o.has(pkg)) return null
        val v = o.optInt(pkg, -1)
        return if (v in 0..9) v else null
    }
    fun setCats(m: Map<String, Int>) {
        val o = obj("cats")
        m.forEach { (k, v) -> o.put(k, v) }
        putObj("cats", o)
    }
    fun clearCats() { sp.edit().remove("cats").apply() }
    fun catName(pkg: String): String? = obj("catn").optString(pkg, "").ifEmpty { null }
    fun setCatNames(m: Map<String, String>) { val o = obj("catn"); m.forEach { (k, v) -> o.put(k, v) }; putObj("catn", o) }
    fun clearCatNames() { sp.edit().remove("catn").apply() }

    var windowed: Boolean
        get() = sp.getBoolean("windowed", true)
        set(v) { sp.edit().putBoolean("windowed", v).apply() }
    var winApps: List<String>
        get() = lst("winapps")
        set(v) = put("winapps", v)

    /** تطبيقات تقسيم الشاشة الأربعة (مفتاح التطبيق أو فارغ = تلقائي). */
    var splitSlots: List<String>
        get() { val l = (sp.getString("splitSlots", "") ?: "").split("|"); return List(4) { l.getOrNull(it) ?: "" } }
        set(v) { sp.edit().putString("splitSlots", List(4) { v.getOrNull(it) ?: "" }.joinToString("|")).apply() }

    /** التطبيقات المجمّدة: سطر لكل تطبيق «مفتاح<TAB>اسم» (تختفي من قائمة النظام فنحتفظ بها هنا). */
    var frozen: List<String>
        get() = lst("frozen")
        set(v) = put("frozen", v)

    fun folders(): List<FolderData> {
        val arr = JSONArray(sp.getString("folders", "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); val a = o.getJSONArray("apps")
            FolderData(o.getString("id"), o.optString("name", "مجلد"), (0 until a.length()).map { a.getString(it) }, o.optString("main", ""))
        }
    }
    fun saveFolders(l: List<FolderData>) {
        val arr = JSONArray()
        l.forEach { f -> arr.put(JSONObject().put("id", f.id).put("name", f.name).put("main", f.main).put("apps", JSONArray(f.apps))) }
        sp.edit().putString("folders", arr.toString()).apply()
    }

    var order: List<String>
        get() = lst("order")
        set(v) = put("order", v)
    var taskbar: Boolean
        get() = sp.getBoolean("taskbar", true)
        set(v) { sp.edit().putBoolean("taskbar", v).apply() }

    fun name(k: String): String = obj("names").optString(k, "")
    fun setName(k: String, v: String) {
        val o = obj("names")
        if (v.isBlank()) o.remove(k) else o.put(k, v.trim())
        putObj("names", o)
    }
    fun iconPath(k: String): String = obj("icons").optString(k, "")
    fun setIconPath(k: String, p: String?) {
        val o = obj("icons")
        if (p == null) o.remove(k) else o.put(k, p)
        putObj("icons", o)
    }
    fun usage(k: String): Int = obj("usage").optInt(k, 0)
    fun bump(k: String) {
        val o = obj("usage"); o.put(k, o.optInt(k, 0) + 1); putObj("usage", o)
    }
}

object Repo {
    /** بصمة قائمة التطبيقات القابلة للتشغيل: تتغير عند تثبيت/حذف/تجميد أي تطبيق. */
    fun signature(ctx: Context): Int {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return ctx.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName + "/" + it.activityInfo.name }.sorted().hashCode()
    }

    fun load(ctx: Context, st: Store): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        fun keyOf(r: android.content.pm.ResolveInfo) = r.activityInfo.packageName + "/" + r.activityInfo.name
        // المكوّنات المفعّلة فقط (لا نُظهر بدائل الأيقونة المعطّلة مثل تيليغرام وX)
        val normal = pm.queryIntentActivities(i, 0)
        val have = normal.map { keyOf(it) }.toSet()
        // المجمَّد (pm disable-user) يبقى ظاهراً بأيقونة شاحبة: نضيف مدخله بالتحديد (وتطبيقه معطّل) لا غير
        val fz = st.frozen.map { it.substringBefore('\t') }.toSet()
        val extra = if (fz.isEmpty()) emptyList() else
            pm.queryIntentActivities(i, PackageManager.MATCH_DISABLED_COMPONENTS)
                .filter { keyOf(it) in fz && keyOf(it) !in have && !it.activityInfo.applicationInfo.enabled }
        return (normal + extra)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { r ->
                val a = r.activityInfo
                val app = AppInfo(a.packageName + "/" + a.name, a.packageName, a.name, r.loadLabel(pm).toString(), r.loadIcon(pm))
                app.frozen = !a.applicationInfo.enabled
                val n = st.name(app.key)
                if (n.isNotEmpty()) app.label = n
                val p = st.iconPath(app.key)
                if (p.isNotEmpty()) app.custom = BitmapFactory.decodeFile(p)
                app
            }
            .let { list ->
                val idx = st.order.withIndex().associate { it.value to it.index }
                list.sortedWith(compareBy<AppInfo>({ idx[it.key] ?: Int.MAX_VALUE }, { it.label.lowercase() }))
            }
    }
}
