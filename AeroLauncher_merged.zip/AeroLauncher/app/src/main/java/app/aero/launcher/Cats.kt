package app.aero.launcher

import android.content.Context
import android.content.pm.ApplicationInfo

/** 10 تصنيفات ثابتة فقط. لكل تطبيق تصنيف دائماً (تلقائي، ثم من الذكاء الاصطناعي، ثم يدوي). */
object Cats {
    val names = listOf(
        "تواصل واجتماعي", "ترفيه", "ألعاب", "إنتاجية وعمل", "تسوق ومال",
        "سفر وخرائط", "كاميرا وصور", "تعليم وأخبار", "صحة ورياضة", "أدوات ونظام")
    private val hints = listOf(
        "مراسلة، شبكات اجتماعية، مكالمات، بريد", "فيديو، موسيقى، بث، بودكاست", "كل الألعاب",
        "مستندات، ملاحظات، تقويم، تخزين سحابي، اجتماعات", "متاجر، بنوك، محافظ، دفع",
        "خرائط، مواصلات، حجز، طقس", "كاميرا، معرض، تعديل صور وفيديو", "تعلّم، قراءة، كتب، أخبار",
        "صحة، لياقة، رياضة", "إعدادات، ملفات، حاسبة، ساعة، متصفح، أدوات النظام وأي شيء لا يناسب غيره")

    private val kw: List<Pair<Int, List<String>>> = listOf(
        2 to listOf("game", "supercell", "mojang", "roblox", "pubg", "garena", "miniclip", "gameloft", "zynga", "unity3d"),
        0 to listOf("whatsapp", "telegram", "messenger", "instagram", "facebook", "twitter", "snapchat", "discord", "signal",
            "viber", "tiktok", "linkedin", "reddit", "wechat", "skype", "dialer", "contacts", "mms", "messaging", "sms",
            "gmail", "email", "mail", "outlook", "truecaller", "pinterest", "threads"),
        1 to listOf("youtube", "netflix", "spotify", "music", "video", "vlc", "podcast", "twitch", "shahid", "anghami",
            "soundcloud", "deezer", "disney", "primevideo"),
        6 to listOf("camera", "gallery", "photo", "snapseed", "lightroom", "vsco", "capcut", "inshot", "picsart"),
        5 to listOf("maps", "navigation", "uber", "careem", "booking", "airbnb", "weather", "taxi", "transit", "flight",
            "travel", "waze", "hotel", "airline"),
        4 to listOf("bank", "wallet", "paypal", "shop", "amazon", "aliexpress", "ebay", "noon", "temu", "shein", "finance",
            "crypto", "binance"),
        8 to listOf("health", "fitness", "fitbit", "workout", "sport", "gym", "medical", "yoga", "calorie", "pharm", "doctor", "strava"),
        7 to listOf("news", "kindle", "duolingo", "school", "quran", "bible", "coursera", "udemy", "khan", "dictionary",
            "translate", "wikipedia"),
        3 to listOf("office", "docs", "sheets", "excel", "powerpoint", "drive", "notes", "calendar", "todo", "notion", "pdf",
            "slack", "zoom", "teams", "dropbox", "onenote", "evernote", "trello", "scanner")
    )

    @Suppress("DEPRECATION")
    fun auto(ctx: Context, a: AppInfo): Int {
        val ai = try { ctx.packageManager.getApplicationInfo(a.pkg, 0) } catch (e: Exception) { null }
        if (ai != null) {
            when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> return 2
                ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> return 1
                ApplicationInfo.CATEGORY_IMAGE -> return 6
                ApplicationInfo.CATEGORY_SOCIAL -> return 0
                ApplicationInfo.CATEGORY_NEWS -> return 7
                ApplicationInfo.CATEGORY_MAPS -> return 5
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> return 3
                else -> {}
            }
            if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return 2
        }
        val s = (a.pkg + " " + a.orig).lowercase()
        for ((i, ks) in kw) if (ks.any { s.contains(it) }) return i
        return 9
    }

    fun promptBalanced(apps: List<AppInfo>): String {
        val l = apps.distinctBy { it.pkg }
        val n = (l.size / 12).coerceIn(4, 14); val per = l.size / n
        val sb = StringBuilder()
        sb.append("قسّم تطبيقات أندرويد التالية إلى $n تصنيفاً. اختر أنت اسماً قصيراً لكل تصنيف (كلمتان كحد أقصى) يناسب محتواه.\n")
        sb.append("شرط أساسي: عدد التطبيقات في كل تصنيف متقارب جداً (نحو $per، بين ${per * 3 / 4} و ${per * 5 / 4}). لا تصنيف بتطبيق واحد ولا تصنيف ضخم؛ اجمع المواضيع القريبة أو قسّم الكبيرة بأسماء مختلفة.\n")
        sb.append("كل تطبيق يحصل على تصنيف واحد بدون استثناء. أجب فقط بسطر لكل تطبيق: اسم.الحزمة=اسم التصنيف، بدون شرح أو ترقيم، وانسخ اسم الحزمة كما هو.\n\nالتطبيقات (الحزمة | الاسم):\n")
        l.forEach { sb.append("${it.pkg} | ${it.orig}\n") }
        return sb.toString()
    }

    private val rxb = Regex("""([A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+)["']?\s*(?:->|=>|→|[:=|])\s*["']?\s*([^"'\n}\]]+)""")
    fun parseBalanced(text: String, pkgs: Set<String>): Map<String, String> {
        val out = HashMap<String, String>()
        rxb.findAll(text).forEach { m ->
            val p = m.groupValues[1]; val n = m.groupValues[2].trim().trimEnd(',', '،').take(24)
            if (p in pkgs && n.isNotEmpty() && !n.all { it.isDigit() }) out[p] = n
        }
        return out
    }

    /** موازنة محلية مضمونة فوق أي تصنيف (ذكي/تلقائي/يدوي): تقسيم الكبير، ودمج الصغير */
    fun balance(g: Map<String, List<AppInfo>>): Map<String, List<AppInfo>> {
        val total = g.values.sumOf { it.size }; if (total == 0) return g
        val n = (total / 12).coerceIn(4, 14); val target = (total + n - 1) / n
        val maxS = (target * 1.4f).toInt(); val minS = (target * 0.5f).toInt().coerceAtLeast(3)
        val out = LinkedHashMap<String, MutableList<AppInfo>>(); val pool = ArrayList<AppInfo>()
        fun put(name: String, l: List<AppInfo>) {
            if (l.size <= maxS) { out[name] = l.toMutableList(); return }
            val p = (l.size + target - 1) / target; val sz = (l.size + p - 1) / p
            l.chunked(sz).forEachIndexed { i, c -> out[if (i == 0) name else "$name ${i + 1}"] = c.toMutableList() }
        }
        g.entries.sortedByDescending { it.value.size }.forEach { (name, l) -> if (l.size < minS) pool.addAll(l) else put(name, l) }
        if (pool.isNotEmpty()) {
            if (pool.size < minS && out.isNotEmpty()) out.values.minByOrNull { it.size }!!.addAll(pool) else put("متفرقات", pool)
        }
        return out
    }
}
