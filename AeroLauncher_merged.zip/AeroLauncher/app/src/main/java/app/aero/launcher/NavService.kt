package app.aero.launcher

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.app.KeyguardManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.widget.TextView
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/** شريط تنقل عائم فوق كل التطبيقات + قائمة التطبيقات النشطة (كشريط مهام ويندوز). */
class NavService : AccessibilityService() {
    companion object {
        var active = false
        var inst: NavService? = null
        var onChange: (() -> Unit)? = null
        const val H_DP = 46
        fun isEnabled(ctx: Context): Boolean {
            val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val cn = ComponentName(ctx, NavService::class.java)
            return s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString())
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private var bar: Taskbar? = null
    var split: SplitEngine? = null
    private val open = LinkedHashSet<String>()
    private var fg: String? = null
    private var ufg: String? = null
    private var lastTickEl = 0L
    private var lastKick = 0L
    private val h = Handler(Looper.getMainLooper())
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    @Volatile private var syncing = false
    private val tick = object : Runnable { override fun run() { onTick(); h.postDelayed(this, 2000) } }
    private val spl = SharedPreferences.OnSharedPreferenceChangeListener { _, k -> if (k == "taskbar") sync() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sp = getSharedPreferences("aero", MODE_PRIVATE)
        sp.registerOnSharedPreferenceChangeListener(spl)
        active = true
        inst = this
        RootAccess.init(this)
        split = SplitEngine(this)
        lastTickEl = SystemClock.elapsedRealtime()
        h.postDelayed(tick, 2000)
        sync()
    }

    private fun sync() {
        val on = sp.getBoolean("taskbar", true)
        if (on && bar == null) show() else if (!on && bar != null) hide()
        onChange?.invoke()
    }

    private fun navOffset(): Int {
        if (Settings.Secure.getInt(contentResolver, "navigation_mode", 2) != 0) return 0
        if (resources.configuration.orientation != Configuration.ORIENTATION_PORTRAIT) return 0
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun show() {
        val b = Taskbar(this, this)
        val lp = WindowManager.LayoutParams(
            -1, (H_DP * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM
        lp.y = navOffset()
        try { wm.addView(b, lp); bar = b; refresh() } catch (e: Exception) { bar = null }
    }

    private fun hide() {
        bar?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bar = null
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        split?.onConfig()
        val b = bar ?: return
        val lp = b.layoutParams as WindowManager.LayoutParams
        lp.y = navOffset()
        try { wm.updateViewLayout(b, lp) } catch (e: Exception) {}
    }

    private fun imePkg(): String? =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) { fg = null; ufg = null; refresh(); split?.onForeground(pkg); return }
        if (Guard.isNeutral(pkg) || pkg == imePkg()) return
        split?.onForeground(pkg)
        ufg = pkg
        enforce()
        if (packageManager.getLaunchIntentForPackage(pkg) == null) return
        if (Guard.blocked && !Guard.isExempt(pkg)) return
        open.add(pkg)
        fg = pkg
        refresh()
    }

    // ---------- تحديد الاستخدام ----------
    private fun defaultHome(): String? = packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName

    /** طرد التطبيق الحالي إلى اللانشر (وإن غُيّر اللانشر الافتراضي نُعيد فتح لانشرنا). */
    private fun kick() {
        val el = SystemClock.elapsedRealtime()
        if (el - lastKick < 600) return
        lastKick = el
        if (defaultHome() == packageName) performGlobalAction(GLOBAL_ACTION_HOME)
        else try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (e: Exception) { performGlobalAction(GLOBAL_ACTION_HOME) }
    }

    private fun enforce() {
        val f = ufg ?: return
        val g = Guard.cfg(this)
        if (!g.enabled) return
        val bad = (Guard.blocked && !Guard.isExempt(f)) || (f in Guard.GUARDED && !Guard.settingsOpen(this))
        if (bad) kick()
    }

    // ---------- مزامنة التطبيقات المفتوحة مع النظام (بالروت) ----------
    // الأحداث وحدها لا تكشف إغلاق التطبيق ولا تفتح كل النوافذ الحرة؛ مع الروت نقرأ المهام الفعلية من النظام.
    private fun rootSync() {
        if (syncing || bar == null || RootAccess.state != true) return
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        syncing = true
        io.execute {
            val live = try { WinCtl.liveApps() } catch (e: Exception) { null }
            h.post { syncing = false; if (live != null) applyLive(live) }
        }
    }

    private fun eligible(p: String): Boolean {
        if (p == packageName || Guard.isNeutral(p) || p == imePkg()) return false
        if (packageManager.getLaunchIntentForPackage(p) == null) return false
        return !(Guard.blocked && !Guard.isExempt(p))
    }

    private fun applyLive(live: List<String>) {
        val before = open.toList()
        val keep = live.filter { eligible(it) }
        open.retainAll(keep.toSet())
        keep.reversed().forEach { open.add(it) }   // الأقدم أولاً؛ الموجود يحتفظ بمكانه
        if (fg != null && fg !in open) fg = null
        if (open.toList() != before) refresh()
    }

    private fun onTick() {
        rootSync()
        val el = SystemClock.elapsedRealtime()
        val dt = (el - lastTickEl).coerceIn(0L, 10_000L)
        lastTickEl = el
        val g = Guard.cfg(this)
        if (!g.enabled) { Guard.refresh(this); bar?.setInfo(""); return }
        val t = Guard.now(this)
        val f = ufg
        val interactive = getSystemService(PowerManager::class.java).isInteractive
        val locked = getSystemService(KeyguardManager::class.java).isKeyguardLocked
        if (f != null && interactive && !locked && !Guard.isExempt(f)) Guard.addUsed(this, t, dt)
        val was = Guard.blocked
        Guard.refresh(this)
        if (Guard.blocked != was) refresh()
        val rem = Guard.earned(this, g, t) - Guard.used(this, t)
        bar?.setInfo(if (rem <= 0) "⏱ 0:00" else "⏱ ${rem / 60000}:${(rem / 1000 % 60).toString().padStart(2, '0')}")
        enforce()
    }

    private fun refresh() {
        open.removeAll { packageManager.getLaunchIntentForPackage(it) == null }
        bar?.setItems(if (Guard.blocked) emptyList() else open.toList(), fg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        active = false
        inst = null
        split?.stop(); split = null
        h.removeCallbacksAndMessages(null)
        hide()
        try { sp.unregisterOnSharedPreferenceChangeListener(spl) } catch (e: Exception) {}
        onChange?.invoke()
        super.onDestroy()
    }

    // ---- أوامر الأزرار ----
    fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
    fun home() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun recents() { performGlobalAction(GLOBAL_ACTION_RECENTS) }
    fun openApp(pkg: String) {
        if (pkg == fg) { home(); return }
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val cn = i.component
        val o = if (cn != null) Win.options(this, cn, Store(this), (H_DP * resources.displayMetrics.density).toInt()) else null
        try { startActivity(i, o) } catch (e: Exception) {}
    }
    /** إغلاق عنصر الشريط: بالروت نوقف التطبيق فعلاً، وبدونه نزيله من الشريط فقط. */
    fun closeItem(pkg: String) {
        open.remove(pkg); if (fg == pkg) fg = null; refresh()
        if (RootAccess.state == true && WinCtl.safe(pkg)) io.execute { RootSh.run("am force-stop $pkg") }
    }

    /** تبديل: نافذة عمودية (أفقي) <-> ملء الشاشة. يعيد فتح التطبيق الحالي بالوضع الجديد. */
    fun toggleWindow() {
        val st = Store(this)
        st.windowed = !st.windowed
        android.widget.Toast.makeText(this, if (st.windowed) "وضع النافذة العمودية" else "ملء الشاشة", android.widget.Toast.LENGTH_SHORT).show()
        val pkg = fg ?: return
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val cn = i.component ?: return
        val o = Win.options(this, cn, st, (H_DP * resources.displayMetrics.density).toInt(), !st.windowed)
        try { startActivity(i, o) } catch (e: Exception) {}
    }
}

class NavBtn(ctx: Context, private val kind: Int, act: () -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    init {
        isClickable = true
        setOnClickListener { act() }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, rr(Color.WHITE, 20 * d))
    }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        when (kind) {
            0 -> { val path = Path(); path.moveTo(cx + 4 * d, cy - 7 * d); path.lineTo(cx - 4 * d, cy); path.lineTo(cx + 4 * d, cy + 7 * d); c.drawPath(path, p) }
            1 -> c.drawCircle(cx, cy, 7 * d, p)
            2 -> c.drawRoundRect(cx - 7 * d, cy - 7 * d, cx + 7 * d, cy + 7 * d, 3 * d, 3 * d, p)
            else -> { c.drawRoundRect(cx - 9 * d, cy - 6 * d, cx + 9 * d, cy + 6 * d, 2 * d, 2 * d, p); c.drawRect(cx - 2.5f * d, cy - 4 * d, cx + 2.5f * d, cy + 4 * d, p) }
        }
    }
}

class Taskbar(ctx: Context, private val svc: NavService) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val items = LinearLayout(ctx)
    private val info = TextView(ctx)

    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = GradientDrawable().apply {
            setColor(0xF0101216.toInt()); val r = 14 * d
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f); setStroke((1 * d).toInt(), 0x22FFFFFF)
        }
        setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
        val bw = (48 * d).toInt()
        addView(NavBtn(ctx, 0) { svc.back() }, LinearLayout.LayoutParams(bw, -1))
        addView(NavBtn(ctx, 1) { svc.home() }, LinearLayout.LayoutParams(bw, -1))
        addView(NavBtn(ctx, 2) { svc.recents() }, LinearLayout.LayoutParams(bw, -1))
        addView(NavBtn(ctx, 3) { svc.toggleWindow() }, LinearLayout.LayoutParams(bw, -1))
        val div = View(ctx).apply { setBackgroundColor(0x33FFFFFF) }
        addView(div, LinearLayout.LayoutParams((1 * d).toInt(), (24 * d).toInt()).apply { setMargins((6 * d).toInt(), 0, (6 * d).toInt(), 0) })
        items.orientation = HORIZONTAL
        val hs = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        hs.addView(items, FrameLayout.LayoutParams(-2, -1))
        addView(hs, LinearLayout.LayoutParams(0, -1, 1f))
        info.setTextColor(0xCCFFFFFF.toInt()); info.textSize = 12f; info.gravity = Gravity.CENTER_VERTICAL
        info.setPadding((8 * d).toInt(), 0, (8 * d).toInt(), 0); info.visibility = View.GONE
        addView(info, LinearLayout.LayoutParams(-2, -1))
    }

    private fun info(pkg: String): AppInfo? {
        val pm = context.packageManager
        val cn = pm.getLaunchIntentForPackage(pkg)?.component ?: return null
        val ic = try { pm.getActivityIcon(cn) } catch (e: Exception) { return null }
        val key = cn.packageName + "/" + cn.className
        val a = AppInfo(key, cn.packageName, cn.className, "", ic)
        val path = Store(context).iconPath(key)
        if (path.isNotEmpty()) a.custom = BitmapFactory.decodeFile(path)
        return a
    }

    fun setInfo(s: String) { info.text = s; info.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE }

    fun setItems(pkgs: List<String>, fg: String?) {
        items.removeAllViews()
        pkgs.forEach { pkg ->
            val a = info(pkg) ?: return@forEach
            val f = FrameLayout(context)
            val c = AppCell(context, a, false, 0.8f)
            c.setOnClickListener { svc.openApp(pkg) }
            c.setOnLongClickListener { svc.closeItem(pkg); true }
            f.addView(c, FrameLayout.LayoutParams(-1, -1))
            val on = pkg == fg
            val ind = View(context).apply { background = rr(Color.WHITE, 2 * d); alpha = if (on) 1f else 0.35f }
            f.addView(ind, FrameLayout.LayoutParams(((if (on) 20 else 10) * d).toInt(), (3 * d).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (2 * d).toInt() })
            items.addView(f, LinearLayout.LayoutParams((46 * d).toInt(), -1))
        }
    }
}
