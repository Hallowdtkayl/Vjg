package app.aero.launcher

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.TextView
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/**
 * شريط تنقل عائم + قائمة التطبيقات النشطة (كشريط مهام ويندوز) وأزرار التقسيم.
 * خدمة عادية (ليست إمكانية وصول): النافذة العائمة بإذن «العرض فوق التطبيقات» الذي يمنحه الروت/Shizuku،
 * ومعرفة التطبيق الأمامي والتنقل (رجوع/رئيسية/أخيرة) بأوامر الروت/Shizuku.
 */
class NavService : Service() {
    companion object {
        var active = false
        var inst: NavService? = null
        var onChange: (() -> Unit)? = null
        const val H_DP = 46
        fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)
        fun start(ctx: Context) { try { ctx.startService(Intent(ctx, NavService::class.java)) } catch (e: Exception) {} }
    }

    private lateinit var wm: WindowManager
    private lateinit var sp: SharedPreferences
    private var bar: Taskbar? = null
    var split: SplitEngine? = null
    private val open = LinkedHashSet<String>()
    private var fg: String? = null
    private var lastTop: String? = null
    private val NEUTRAL = setOf("app.aero.launcher", "com.android.systemui", "android", "com.android.server.telecom", "com.android.incallui",
        "com.android.phone", "com.android.emergency", "com.google.android.permissioncontroller", "com.android.permissioncontroller")
    private val h = Handler(Looper.getMainLooper())
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor()
    @Volatile private var syncing = false
    private val tick = object : Runnable { override fun run() { onTick(); h.postDelayed(this, 2000) } }
    private val spl = SharedPreferences.OnSharedPreferenceChangeListener { _, k -> if (k == "taskbar") sync() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sp = getSharedPreferences("aero", MODE_PRIVATE)
        sp.registerOnSharedPreferenceChangeListener(spl)
        active = true
        inst = this
        RootAccess.init(this)
        split = SplitEngine(this)
        h.postDelayed(tick, 1500)
        sync()
    }

    private fun sync() {
        val on = sp.getBoolean("taskbar", true)
        if (on && bar == null) show() else if (!on && bar != null) hide()
        onChange?.invoke()
    }

    private fun navOffset(): Int {
        if (Settings.Secure.getInt(contentResolver, "navigation_mode", 2) != 0) return 0
        if (resources.configuration.orientation != Configuration.ORIENTATION_PORTRAIT) return 0
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun show() {
        if (!Settings.canDrawOverlays(this)) return
        val b = Taskbar(this, this)
        val lp = WindowManager.LayoutParams(
            -1, (H_DP * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM
        lp.y = navOffset()
        try { wm.addView(b, lp); bar = b; refresh() } catch (e: Exception) { bar = null }
    }

    private fun hide() {
        bar?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bar = null
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        split?.onConfig()
        val b = bar ?: return
        val lp = b.layoutParams as WindowManager.LayoutParams
        lp.y = navOffset()
        try { wm.updateViewLayout(b, lp) } catch (e: Exception) {}
    }

    private fun imePkg(): String? =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')

    /** التطبيق الأمامي تغيّر (من استطلاع النظام بدل أحداث إمكانية الوصول). */
    private fun onTop(pkg: String?) {
        if (pkg == null || pkg == lastTop) return
        lastTop = pkg
        if (pkg == packageName) { fg = null; refresh(); split?.onForeground(pkg); return }
        if (pkg in NEUTRAL || pkg == imePkg()) return
        split?.onForeground(pkg)
        if (packageManager.getLaunchIntentForPackage(pkg) == null) return
        open.add(pkg)
        fg = pkg
        refresh()
    }

    // ---------- مزامنة التطبيقات المفتوحة والأمامي مع النظام (روت/Shizuku) ----------
    private fun onTick() {
        if (syncing || RootAccess.state != true) return
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        syncing = true
        io.execute {
            val top = try { WinCtl.topPackage() } catch (e: Exception) { null }
            val live = if (bar != null) { try { WinCtl.liveApps() } catch (e: Exception) { null } } else null
            h.post { syncing = false; onTop(top); if (live != null) applyLive(live) }
        }
    }

    private fun eligible(p: String): Boolean {
        if (p == packageName || p in NEUTRAL || p == imePkg()) return false
        if (packageManager.getLaunchIntentForPackage(p) == null) return false
        return true
    }

    private fun applyLive(live: List<String>) {
        val before = open.toList()
        val keep = live.filter { eligible(it) }
        open.retainAll(keep.toSet())
        keep.reversed().forEach { open.add(it) }   // الأقدم أولاً؛ الموجود يحتفظ بمكانه
        if (fg != null && fg !in open) fg = null
        if (open.toList() != before) refresh()
    }

    private fun refresh() {
        open.removeAll { packageManager.getLaunchIntentForPackage(it) == null }
        bar?.setItems(open.toList(), fg)
    }

    override fun onDestroy() {
        active = false
        inst = null
        split?.stop(); split = null
        h.removeCallbacksAndMessages(null)
        hide()
        try { sp.unregisterOnSharedPreferenceChangeListener(spl) } catch (e: Exception) {}
        onChange?.invoke()
        super.onDestroy()
    }

    // ---- أوامر الأزرار (بأحداث مفاتيح عبر الروت/Shizuku) ----
    private fun key(code: Int) {
        if (RootAccess.state == true) io.execute { RootSh.run("input keyevent $code", 5) }
        else android.widget.Toast.makeText(this, "أزرار التنقل تحتاج روت أو Shizuku", android.widget.Toast.LENGTH_SHORT).show()
    }
    fun back() { key(4) }
    fun home() {
        if (RootAccess.state == true) { key(3); return }
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }
    fun recents() { key(187) }
    fun openApp(pkg: String) {
        if (pkg == fg) { home(); return }
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val cn = i.component
        val o = if (cn != null) Win.options(this, cn, Store(this), (H_DP * resources.displayMetrics.density).toInt()) else null
        try { startActivity(i, o) } catch (e: Exception) {}
    }
    /** إغلاق عنصر الشريط: بالصلاحية نوقف التطبيق فعلاً، وبدونها نزيله من الشريط فقط. */
    fun closeItem(pkg: String) {
        open.remove(pkg); if (fg == pkg) fg = null; refresh()
        if (RootAccess.state == true && WinCtl.safe(pkg)) io.execute { RootSh.run("am force-stop $pkg") }
    }

    /** تبديل: نافذة عمودية (أفقي) <-> ملء الشاشة. يعيد فتح التطبيق الحالي بالوضع الجديد. */
    fun toggleWindow() {
        val st = Store(this)
        st.windowed = !st.windowed
        android.widget.Toast.makeText(this, if (st.windowed) "وضع النافذة العمودية" else "ملء الشاشة", android.widget.Toast.LENGTH_SHORT).show()
        val pkg = fg ?: return
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val cn = i.component ?: return
        val o = Win.options(this, cn, st, (H_DP * resources.displayMetrics.density).toInt(), !st.windowed)
        try { startActivity(i, o) } catch (e: Exception) {}
    }
}

class NavBtn(ctx: Context, private val kind: Int, act: () -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    init {
        isClickable = true
        setOnClickListener { act() }
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, rr(Color.WHITE, 20 * d))
    }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        when (kind) {
            0 -> { val path = Path(); path.moveTo(cx + 4 * d, cy - 7 * d); path.lineTo(cx - 4 * d, cy); path.lineTo(cx + 4 * d, cy + 7 * d); c.drawPath(path, p) }
            1 -> c.drawCircle(cx, cy, 7 * d, p)
            2 -> c.drawRoundRect(cx - 7 * d, cy - 7 * d, cx + 7 * d, cy + 7 * d, 3 * d, 3 * d, p)
            else -> { c.drawRoundRect(cx - 9 * d, cy - 6 * d, cx + 9 * d, cy + 6 * d, 2 * d, 2 * d, p); c.drawRect(cx - 2.5f * d, cy - 4 * d, cx + 2.5f * d, cy + 4 * d, p) }
        }
    }
}

class Taskbar(ctx: Context, private val svc: NavService) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val items = LinearLayout(ctx)
    private val info = TextView(ctx)

    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = GradientDrawable().apply {
            setColor(0xF0101216.toInt()); val r = 14 * d
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f); setStroke((1 * d).toInt(), 0x22FFFFFF)
        }
        setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
        val bw = (48 * d).toInt()
        addView(NavBtn(ctx, 0) { svc.back() }, LinearLayout.LayoutParams(bw, -1))
        addView(NavBtn(ctx, 1) { svc.home() }, LinearLayout.LayoutParams(bw, -1))
        addView(NavBtn(ctx, 2) { svc.recents() }, LinearLayout.LayoutParams(bw, -1))
        addView(NavBtn(ctx, 3) { svc.toggleWindow() }, LinearLayout.LayoutParams(bw, -1))
        val div = View(ctx).apply { setBackgroundColor(0x33FFFFFF) }
        addView(div, LinearLayout.LayoutParams((1 * d).toInt(), (24 * d).toInt()).apply { setMargins((6 * d).toInt(), 0, (6 * d).toInt(), 0) })
        items.orientation = HORIZONTAL
        val hs = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        hs.addView(items, FrameLayout.LayoutParams(-2, -1))
        addView(hs, LinearLayout.LayoutParams(0, -1, 1f))
        info.setTextColor(0xCCFFFFFF.toInt()); info.textSize = 12f; info.gravity = Gravity.CENTER_VERTICAL
        info.setPadding((8 * d).toInt(), 0, (8 * d).toInt(), 0); info.visibility = View.GONE
        addView(info, LinearLayout.LayoutParams(-2, -1))
    }

    private fun info(pkg: String): AppInfo? {
        val pm = context.packageManager
        val cn = pm.getLaunchIntentForPackage(pkg)?.component ?: return null
        val ic = try { pm.getActivityIcon(cn) } catch (e: Exception) { return null }
        val key = cn.packageName + "/" + cn.className
        val a = AppInfo(key, cn.packageName, cn.className, "", ic)
        val path = Store(context).iconPath(key)
        if (path.isNotEmpty()) a.custom = BitmapFactory.decodeFile(path)
        return a
    }

    fun setInfo(s: String) { info.text = s; info.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE }

    fun setItems(pkgs: List<String>, fg: String?) {
        items.removeAllViews()
        pkgs.forEach { pkg ->
            val a = info(pkg) ?: return@forEach
            val f = FrameLayout(context)
            val c = AppCell(context, a, false, 0.8f)
            c.setOnClickListener { svc.openApp(pkg) }
            c.setOnLongClickListener { svc.closeItem(pkg); true }
            f.addView(c, FrameLayout.LayoutParams(-1, -1))
            val on = pkg == fg
            val ind = View(context).apply { background = rr(Color.WHITE, 2 * d); alpha = if (on) 1f else 0.35f }
            f.addView(ind, FrameLayout.LayoutParams(((if (on) 20 else 10) * d).toInt(), (3 * d).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (2 * d).toInt() })
            items.addView(f, LinearLayout.LayoutParams((46 * d).toInt(), -1))
        }
    }
}
