package app.aero.launcher

import android.content.ComponentName
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display

/** الشاشة وفتح التطبيقات العمودية بثلث العرض في الوضع الأفقي (يتطلب دعم النوافذ الحرة في النظام). */
object Win {
    fun screen(ctx: Context): Rect {
        val dm = DisplayMetrics()
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    fun portraitDeclared(ctx: Context, cn: ComponentName): Boolean = try {
        when (ctx.packageManager.getActivityInfo(cn, 0).screenOrientation) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT,
            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT -> true
            else -> false
        }
    } catch (e: Exception) { false }

    /** تطبيقات عمودية في الأساس لا تصرّح بذلك في المانيفست دائماً. */
    private val KNOWN = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.instagram.barcelona",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.snapchat.android", "com.facebook.orca")

    /** في الوضع الأفقي: التطبيق العمودي يُفتح بثلث عرض الشاشة (3 معاً). */
    fun wantsThird(ctx: Context, cn: ComponentName, st: Store): Boolean {
        if (ctx.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE) return false
        return thirdPref(ctx, cn, st)
    }

    /** تفضيل التطبيق (دون النظر للاتجاه): المفتاح في القائمة = تشغيل، و«-المفتاح» = إيقاف، وإلا التلقائي. */
    fun thirdPref(ctx: Context, cn: ComponentName, st: Store): Boolean {
        val key = cn.packageName + "/" + cn.className
        if (("-" + key) in st.winApps) return false
        if (key in st.winApps) return true
        return portraitDeclared(ctx, cn) || cn.packageName in KNOWN
    }

    /** الثلث رقم slot (0..2 من اليسار) بكامل ارتفاع المساحة المتاحة. */
    fun thirdRect(ctx: Context, slot: Int): Rect {
        val a = Split.area(ctx, 0)
        val w = a.width()
        return Rect(a.left + w * slot / 3, a.top, a.left + w * (slot + 1) / 3, a.bottom)
    }
}
