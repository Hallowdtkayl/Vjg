package app.aero.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Display

/** فتح التطبيقات العمودية كنافذة في الوضع الأفقي (يتطلب دعم النوافذ الحرة في النظام). */
object Win {
    fun screen(ctx: Context): Rect {
        val dm = DisplayMetrics()
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    fun portraitDeclared(ctx: Context, cn: ComponentName): Boolean = try {
        when (ctx.packageManager.getActivityInfo(cn, 0).screenOrientation) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT,
            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT -> true
            else -> false
        }
    } catch (e: Exception) { false }

    /** نافذة بنسبة هاتف تشغل ~ثلث إلى نصف عرض الشاشة، في المنتصف فوق شريط التنقل. */
    fun phoneBounds(ctx: Context, tb: Int): Rect {
        val s = screen(ctx)
        val w = maxOf(s.height() * 0.56f, s.width() * 0.34f).coerceAtMost(s.width() * 0.5f).toInt()
        val l = (s.width() - w) / 2
        return Rect(l, 0, l + w, s.height() - tb)
    }

    fun options(ctx: Context, cn: ComponentName, st: Store, tb: Int, forceFull: Boolean = false): Bundle? {
        if (ctx.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE) return null
        val o = ActivityOptions.makeBasic()
        if (forceFull) {
            val s = screen(ctx)
            o.setLaunchBounds(Rect(0, 0, s.width(), s.height() - tb))
            return o.toBundle()
        }
        if (!st.windowed) return null
        val key = cn.packageName + "/" + cn.className
        if (portraitDeclared(ctx, cn) || key in st.winApps) {
            o.setLaunchBounds(phoneBounds(ctx, tb))
            return o.toBundle()
        }
        return null
    }
}
