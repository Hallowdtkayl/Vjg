package app.aero.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * تقسيم الشاشة إلى 4 نوافذ حرة.
 *  - عمودي: 2 فوق + 2 تحت.   - أفقي: 4 جنب بعض.
 *  - أزرار 1-4 عند نقطة التقاء النوافذ: تركيز نافذة (تكبر وتتقلص البقية)، وضغطة ثانية ترجع التقسيم الرباعي.
 */
object Split {
    const val FOCUS = 0.65f   // نسبة النافذة المركّزة

    /** سجل آخر ترتيب (للتشخيص من قائمة التقسيم). */
    @Volatile var lastLog: String = "لم يُشغَّل التقسيم بعد."

    // هوامش النظام (شريط الحالة/التنقل) كما رآها اللانشر، لكل اتجاه للشاشة.
    private val insetCache = HashMap<Int, Rect>()

    fun remember(rot: Int, l: Int, t: Int, r: Int, b: Int) { insetCache[rot] = Rect(l, t, r, b) }

    fun rotation(ctx: Context): Int =
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation

    private fun dimen(ctx: Context, name: String): Int {
        val id = ctx.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else 0
    }

    /** المساحة المتاحة للنوافذ: الشاشة ناقص شريط الحالة وشريط التنقل وشريط مهام Aero. */
    fun area(ctx: Context, taskbarPx: Int): Rect {
        val s = Win.screen(ctx)
        val c = insetCache[rotation(ctx)]
        val l: Int; val t: Int; val r: Int; val b: Int
        if (c != null) { l = c.left; t = c.top; r = c.right; b = c.bottom }
        else {
            val portrait = s.height() > s.width()
            val threeBtn = Settings.Secure.getInt(ctx.contentResolver, "navigation_mode", 2) == 0
            l = 0; r = 0; t = dimen(ctx, "status_bar_height")
            b = if (portrait && threeBtn) dimen(ctx, "navigation_bar_height") else 0
        }
        return Rect(s.left + l, s.top + t, s.right - r, s.bottom - b - taskbarPx)
    }

    /** 4 تطبيقات: المختار أولاً، والخانات الفارغة تُملأ بالأكثر استخداماً. لا يتكرر تطبيق (حزمة) في نافذتين. */
    fun resolve(all: List<AppInfo>, st: Store): List<ComponentName?> {
        val byKey = all.associateBy { it.key }
        val chosen = st.splitSlots.map { k -> byKey[k]?.takeIf { !it.frozen }?.let { ComponentName(it.pkg, it.cls) } }.toMutableList()
        while (chosen.size < 4) chosen.add(null)
        val used = HashSet<String>()
        for (i in chosen.indices) { val c = chosen[i]; if (c != null && !used.add(c.packageName)) chosen[i] = null }
        val pool = all.filter { it.key !in st.hidden && !it.frozen }.sortedByDescending { st.usage(it.key) }.iterator()
        for (i in chosen.indices) {
            if (chosen[i] != null) continue
            while (pool.hasNext()) {
                val a = pool.next()
                if (a.pkg in used) continue
                used.add(a.pkg); chosen[i] = ComponentName(a.pkg, a.cls); break
            }
        }
        return chosen
    }

    // ---------- هندسة النوافذ: تُحسب من دقة الشاشة وdpi والحد الأدنى لحجم النافذة في النظام ----------

    /** الحد الأدنى لنافذة freeform في هذا النظام (px): النظام يكبّر أي نافذة أصغر منه فيتداخل الجيران أو تظهر فراغات. */
    fun minSize(ctx: Context): Int {
        val sys = android.content.res.Resources.getSystem()
        val id = sys.getIdentifier("default_minimal_size_resizable_task", "dimen", "android")
        val v = if (id > 0) sys.getDimensionPixelSize(id) else 0
        return if (v > 0) v else (220 * ctx.resources.displayMetrics.density).toInt()
    }

    fun dpi(ctx: Context): Int = ctx.resources.displayMetrics.densityDpi

    /** سطر تشخيص: الدقة والكثافة والمساحة المتاحة بالـdp والحد الأدنى للنافذة. */
    fun infoLine(ctx: Context, a: Rect): String {
        val s = Win.screen(ctx); val dn = ctx.resources.displayMetrics.density
        return "الشاشة ${s.width()}×${s.height()} @${dpi(ctx)}dpi | المتاحة ${(a.width() / dn).toInt()}×${(a.height() / dn).toInt()}dp | أدنى نافذة ${(minSize(ctx) / dn).toInt()}dp"
    }

    class Result(val rects: List<Rect>, val seamX: Int, val seamY: Int, val central: Boolean, val deficitDp: Int)

    private fun bounds(lo: Int, hi: Int, k: Int) = IntArray(k + 1) { lo + (hi - lo) * it / k }   // تقسيم تام بلا بقايا

    private fun table(a: Rect, cols: Int, rows: Int): List<Rect> {
        val bx = bounds(a.left, a.right, cols); val by = bounds(a.top, a.bottom, rows)
        val out = ArrayList<Rect>()
        for (r in 0 until rows) for (c in 0 until cols) out.add(Rect(bx[c], by[r], bx[c + 1], by[r + 1]))
        return out
    }

    /** كل طرق تقسيم المنطقة إلى n نافذة متجاورة تغطيها كلها بلا فراغ ولا تداخل. */
    private fun candidates(a: Rect, n: Int): List<List<Rect>> {
        val mx = a.centerX(); val my = a.centerY()
        return when (n) {
            1 -> listOf(listOf(Rect(a)))
            2 -> listOf(table(a, 2, 1), table(a, 1, 2))
            3 -> listOf(
                listOf(Rect(a.left, a.top, mx, my), Rect(mx, a.top, a.right, my), Rect(a.left, my, a.right, a.bottom)),
                listOf(Rect(a.left, a.top, a.right, my), Rect(a.left, my, mx, a.bottom), Rect(mx, my, a.right, a.bottom)),
                listOf(Rect(a.left, a.top, mx, a.bottom), Rect(mx, a.top, a.right, my), Rect(mx, my, a.right, a.bottom)),
                listOf(Rect(a.left, a.top, mx, my), Rect(a.left, my, mx, a.bottom), Rect(mx, a.top, a.right, a.bottom)),
                table(a, 3, 1), table(a, 1, 3))
            else -> listOf(table(a, 2, 2), table(a, 4, 1), table(a, 1, 4))
        }
    }

    private fun deficit(r: Rect, min: Int) = maxOf(0, min - r.width()) + maxOf(0, min - r.height())

    /** يرفع أي نافذة أصغر من الحد الأدنى إلى الحد الأدنى مثبّتة في زاويتها الأقرب، فلا تخرج من الشاشة ولا تترك فراغاً عند الحافة. */
    private fun anchored(r: Rect, a: Rect, min: Int): Rect {
        val w = minOf(maxOf(r.width(), min), a.width()); val h = minOf(maxOf(r.height(), min), a.height())
        val l = if (r.centerX() <= a.centerX()) r.left else r.right - w
        val t = if (r.centerY() <= a.centerY()) r.top else r.bottom - h
        return Rect(l, t, l + w, t + h)
    }

    /** يختار أفضل تقسيم (الأقل نقصاً عن الحد الأدنى؛ الأرباع أولاً عند التعادل) ثم يثبّت النوافذ في زواياها. */
    private fun tile(a: Rect, n: Int, min: Int): Pair<List<Rect>, Int> {
        val cands = candidates(a, n)
        var best = cands[0]; var bestD = Int.MAX_VALUE
        for (c in cands) { val dd = c.sumOf { deficit(it, min) }; if (dd < bestD) { bestD = dd; best = c } }
        return Pair(best.map { anchored(it, a, min) }, bestD)
    }

    /**
     * n نافذة (1..4) داخل المنطقة a. بلا تركيز: أرباع (أو أنسب تقسيم يتسع). مع التركيز: المركّزة تأخذ f من المساحة
     * (عمودي: في الأسفل، أفقي: في جهتها) والبقية تتوزع على الباقي بالطريقة نفسها.
     */
    fun compute(a: Rect, n: Int, focus: Int, f: Float, min: Int): Result {
        if (n <= 0) return Result(emptyList(), a.centerX(), a.centerY(), false, 0)
        if (focus < 0 || n == 1) {
            val (r, dd) = tile(a, n, min)
            val quarters = n == 4 && r[0].right <= r[1].left + 1 && r[2].top >= r[0].bottom - 1 && r[1].top == r[0].top
            return Result(r, a.centerX(), if (quarters) a.centerY() else a.bottom, quarters, dd)
        }
        val land = a.width() > a.height()
        val others = (0 until n).filter { it != focus }
        val out = arrayOfNulls<Rect>(n)
        val seamX: Int; val seamY: Int
        val rest: Rect
        if (!land) {
            val fh = (a.height() * f).toInt()
            val fr = Rect(a.left, a.bottom - fh, a.right, a.bottom)
            out[focus] = fr; rest = Rect(a.left, a.top, a.right, a.bottom - fh)
            seamX = a.centerX(); seamY = fr.top
        } else {
            val fw = (a.width() * f).toInt()
            val onRight = focus >= (n + 1) / 2
            val fr = if (onRight) Rect(a.right - fw, a.top, a.right, a.bottom) else Rect(a.left, a.top, a.left + fw, a.bottom)
            out[focus] = fr; rest = if (onRight) Rect(a.left, a.top, a.right - fw, a.bottom) else Rect(a.left + fw, a.top, a.right, a.bottom)
            seamX = if (onRight) fr.left else fr.right; seamY = a.bottom
        }
        val (rr2, dd) = tile(rest, others.size, min)
        others.forEachIndexed { i, slot -> out[slot] = rr2[i] }
        return Result(out.map { it!! }, seamX, seamY, false, dd)
    }
}

/** تنفيذ الأوامر المميّزة: روت أو Shizuku (الأول الذي يعمل). */
object RootSh {
    class Out(val code: Int, val text: String)

    private fun viaSu(cmd: String, seconds: Long): Out = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(seconds, TimeUnit.SECONDS)) { p.destroy(); Out(-1, text) } else Out(p.exitValue(), text)
    } catch (e: Exception) { Out(-1, e.message ?: "") }

    fun run(cmd: String, seconds: Long = 8): Out =
        if (Priv.mode == "shizuku") Priv.viaShizuku(cmd, seconds) else viaSu(cmd, seconds)

    /**
     * فحص الصلاحية: روت أولاً (قد تظهر نافذة Magisk أول مرة)، ثم Shizuku.
     * عند النجاح يعيد Out(0, "0") في الحالتين.
     */
    fun probe(): Out {
        val r = viaSu("id -u", 30)
        if (r.code == 0 && r.text.trim() == "0") { Priv.mode = "root"; return r }
        if (Priv.shizukuAlive()) {
            if (Priv.shizukuGranted()) {
                val s = Priv.viaShizuku("id -u", 15)
                val u = s.text.trim()
                if (s.code == 0 && (u == "0" || u == "2000")) { Priv.mode = "shizuku"; return Out(0, "0") }
                return Out(-1, "Shizuku: " + s.text.trim().take(80))
            }
            Priv.shizukuRequest()
            return Out(-1, "Shizuku يعمل — امنح Aero الإذن في النافذة التي ظهرت ثم أعد المحاولة")
        }
        return Out(-1, if (r.text.isNotBlank()) r.text else "لا روت ولا Shizuku — شغّل Shizuku أو امنح الروت")
    }
}

/**
 * المحرك: يعمل داخل NavService (خدمة عادية) وتظهر أزرار التركيز بإذن «العرض فوق التطبيقات» الممنوح بالروت/Shizuku.
 *  - بالروت: يشغّل كل تطبيق بوضع freeform (windowingMode 5) ويحفظ رقم مهمته، ثم `task resize`.
 *    التركيز والتدوير يعيدان التحجيم فقط (دون إعادة تشغيل التطبيقات) فلا تتبدّل الشاشات.
 *  - إن لم يتحول التطبيق إلى freeform نجرّب launch bounds (الآلية نفسها التي يستخدمها اللانشر لنوافذه).
 *  - بدون روت: launch bounds عند التشغيل فقط، ولا تُعاد ترتيب نوافذ مفتوحة.
 * كل خطوة تُسجَّل في Split.lastLog (قائمة التقسيم ← تشخيص).
 */
class SplitEngine(private val svc: NavService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val d: Float get() = svc.resources.displayMetrics.density

    private var cluster: LinearLayout? = null
    private var clusterCentral = false
    private val btns = ArrayList<TextView>()
    private var slots: List<ComponentName> = emptyList()
    private var focus = -1
    private var startedAt = 0L

    @Volatile private var root: Boolean? = null
    private val ids = IntArray(4) { -1 }   // رقم مهمة كل نافذة بعد ضبطها

    var running = false
        private set

    private val relayout = Runnable { apply(false) }

    fun start(list: List<ComponentName?>) {
        slots = list.filterNotNull(); focus = -1; running = true; root = null
        ids.fill(-1)
        startedAt = SystemClock.elapsedRealtime()
        apply(true)
    }

    fun stop() {
        running = false
        h.removeCallbacks(relayout)
        removeCluster()
    }

    /** تدوير الشاشة: ننتظر استقراره ثم نعيد التحجيم. */
    fun onConfig() {
        if (!running) return
        h.removeCallbacks(relayout); h.postDelayed(relayout, 700)
    }

    /** نخفي الأزرار عند العودة للانشر ونُظهرها مع أي تطبيق آخر. */
    fun onForeground(pkg: String) {
        if (!running) return
        val v = cluster ?: return
        if (pkg == svc.packageName) {
            if (SystemClock.elapsedRealtime() - startedAt > 2500) v.visibility = View.GONE
        } else v.visibility = View.VISIBLE
    }

    private fun onTap(i: Int) {
        if (root == false) { toast("التركيز يحتاج روت أو Shizuku"); return }
        focus = if (focus == i) -1 else i
        apply(false)
    }

    private fun apply(first: Boolean) {
        if (!running) return
        val st = Store(svc)
        val tb = if (st.taskbar) (NavService.H_DP * d).toInt() else 0
        val area = Split.area(svc, tb)
        val land = area.width() > area.height()
        val min = Split.minSize(svc)
        val res = Split.compute(area, slots.size, focus, Split.FOCUS, min)
        try { showCluster(res) } catch (e: Exception) { toast("تعذر عرض أزرار التقسيم") }
        val rects = res.rects; val list: List<ComponentName?> = slots; val f = focus
        val info = Split.infoLine(svc, area) + (if (res.deficitDp > 0) " | ⚠ نقص ${(res.deficitDp / d).toInt()}dp عن الحد الأدنى (تثبيت بالزوايا)" else " | ✓ تناسب كامل")
        io.execute { arrange(first, rects, list, land, area, f, info) }
    }

    // ---------- الترتيب (على خيط خلفي) ----------
    private fun arrange(first: Boolean, rects: List<Rect>, list: List<ComponentName?>, land: Boolean, area: Rect, f: Int, info: String) {
        val sb = StringBuilder()
        val now = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        sb.append("[$now] ${if (land) "أفقي" else "عمودي"} | المساحة ${area.width()}×${area.height()} | تركيز: ${if (f < 0) "لا" else (f + 1).toString()}\n$info\n")

        val cached = root
        val useRoot: Boolean
        if (cached == null || first) {
            val p = RootSh.probe()
            useRoot = p.code == 0 && p.text.trim() == "0"
            root = useRoot
            RootAccess.set(svc, useRoot)
            sb.append("الصلاحية: ").append(if (useRoot) "متاح ✓ (${Priv.label()})" else "غير متاح ✗ (" + p.text.trim().take(100) + ")").append('\n')
            if (first) {
                val msg = if (useRoot) "الصلاحية متاحة (${Priv.label()}) ✓ — أرتّب النوافذ"
                else "لا روت ولا Shizuku — تُضبط أبعاد التطبيقات غير المفتوحة فقط. شغّل Shizuku أو امنح الروت."
                h.post { toast(msg) }
            }
        } else {
            useRoot = cached
        }

        var failures = 0
        if (useRoot) {
            for (i in list.indices) {
                val c = list.getOrNull(i) ?: continue
                val r = rects[i]
                var id = if (first) -1 else ids[i]
                var ok = false
                if (id > 0) { ok = resize(id, r, sb); if (!ok) id = -1 }
                if (!ok) { id = WinCtl.placeRoot(svc, c, r, sb); ok = id > 0 }
                ids[i] = if (ok) id else -1
                if (!ok) failures++
            }
            failures += report(list, sb)
        } else if (first) {
            for (i in list.indices) {
                val c = list.getOrNull(i) ?: continue
                try { boundsPlace(c, rects[i]); sb.append("  ${i + 1}. ${c.packageName}: launch bounds\n") }
                catch (e: Exception) { sb.append("  ✗ ${c.packageName}: ${e.message}\n"); failures++ }
            }
        } else {
            sb.append("بدون روت: لا إعادة ترتيب\n")
        }

        Split.lastLog = sb.toString()
        if (failures > 0) h.post { toast("تعذّر ضبط $failures نافذة — افتح «تشخيص» من قائمة تقسيم الشاشة") }
    }

    // ---------- مساعدات (المنطق المشترك في WinCtl) ----------
    private fun boundsPlace(c: ComponentName, r: Rect) = WinCtl.boundsLaunch(svc, c, r)

    private fun resize(id: Int, r: Rect, sb: StringBuilder) = WinCtl.resize(id, r, sb)

    /** يسجل وضع كل نافذة؛ يعيد عدد النوافذ التي لم تصبح freeform. */
    private fun report(list: List<ComponentName?>, sb: StringBuilder): Int {
        val dump = RootSh.run("dumpsys activity recents").text
        var bad = 0
        list.forEachIndexed { i, c ->
            if (c == null) return@forEachIndexed
            val line = WinCtl.taskLine(dump, c.packageName)
            val mode = line?.let { Regex("mode=([\\w-]+)").find(it)?.groupValues?.get(1) } ?: "؟"
            sb.append("  ${i + 1}. ${c.packageName} #${ids[i]} mode=$mode\n")
            if (mode != "freeform") bad++
        }
        if (bad > 0) sb.append("تنبيه: $bad نافذة ليست freeform — فعّل Enable freeform windows وForce activities to be resizable ثم أعد التشغيل.\n")
        return bad
    }

    // ---------- أزرار التركيز ----------
    private fun buildCluster(central: Boolean, n: Int): LinearLayout {
        btns.clear()
        val box = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val size = (34 * d).toInt(); val m = (2 * d).toInt()
        fun btn(i: Int) = TextView(svc).apply {
            text = (i + 1).toString(); gravity = Gravity.CENTER; textSize = 14f; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(size, size).also { it.setMargins(m, m, m, m) }
            setOnClickListener { onTap(i) }
            setOnLongClickListener { cluster?.visibility = View.GONE; toast("أُخفيت الأزرار — ترجع مع فتح أي تطبيق"); true }
        }.also { btns.add(it) }
        val rows = if (central && n > 2) 2 else 1; val per = (n + rows - 1) / rows
        for (r in 0 until rows) {
            val line = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until per) { val i = r * per + c; if (i < n) line.addView(btn(i)) }
            box.addView(line)
        }
        return box
    }

    private fun showCluster(res: Split.Result) {
        val n = res.rects.size
        if (cluster != null && (clusterCentral != res.central || btns.size != n)) removeCluster()
        if (cluster == null) {
            val v = buildCluster(res.central, n)
            val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            wm.addView(v, lp)
            cluster = v; clusterCentral = res.central
        }
        cluster?.visibility = View.VISIBLE
        btns.forEachIndexed { i, b ->
            b.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i == focus) 0xFF3D7BFF.toInt() else 0xCC222222.toInt())
                setStroke(maxOf(1, d.toInt()), 0x66FFFFFF)
            }
        }
        val v = cluster ?: return
        v.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val lp = v.layoutParams as WindowManager.LayoutParams
        lp.x = res.seamX - v.measuredWidth / 2
        lp.y = if (res.central) res.seamY - v.measuredHeight / 2 else res.seamY - v.measuredHeight - (12 * d).toInt()
        wm.updateViewLayout(v, lp)
    }

    private fun removeCluster() {
        cluster?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        cluster = null
    }

    private fun toast(m: String) = Toast.makeText(svc, m, Toast.LENGTH_LONG).show()
}
