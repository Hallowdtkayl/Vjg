package app.aero.launcher

import android.content.Context
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.view.Display
import java.util.concurrent.TimeUnit

/** المساحة المتاحة للنوافذ الحرة (الشاشة ناقص شريط الحالة والتنقل كما رآها اللانشر). */
object Split {
    // هوامش النظام (شريط الحالة/التنقل) كما رآها اللانشر، لكل اتجاه للشاشة.
    private val insetCache = HashMap<Int, Rect>()

    fun remember(rot: Int, l: Int, t: Int, r: Int, b: Int) { insetCache[rot] = Rect(l, t, r, b) }

    fun rotation(ctx: Context): Int =
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation

    private fun dimen(ctx: Context, name: String): Int {
        val id = ctx.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else 0
    }

    fun area(ctx: Context, extraBottomPx: Int = 0): Rect {
        val s = Win.screen(ctx)
        val c = insetCache[rotation(ctx)]
        val l: Int; val t: Int; val r: Int; val b: Int
        if (c != null) { l = c.left; t = c.top; r = c.right; b = c.bottom }
        else {
            val portrait = s.height() > s.width()
            val threeBtn = Settings.Secure.getInt(ctx.contentResolver, "navigation_mode", 2) == 0
            l = 0; r = 0; t = dimen(ctx, "status_bar_height")
            b = if (portrait && threeBtn) dimen(ctx, "navigation_bar_height") else 0
        }
        return Rect(s.left + l, s.top + t, s.right - r, s.bottom - b - extraBottomPx)
    }
}

/** تنفيذ الأوامر المميّزة: روت أو Shizuku (الأول الذي يعمل). */
object RootSh {
    class Out(val code: Int, val text: String)

    private fun viaSu(cmd: String, seconds: Long): Out = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(seconds, TimeUnit.SECONDS)) { p.destroy(); Out(-1, text) } else Out(p.exitValue(), text)
    } catch (e: Exception) { Out(-1, e.message ?: "") }

    fun run(cmd: String, seconds: Long = 8): Out =
        if (Priv.mode == "shizuku") Priv.viaShizuku(cmd, seconds) else viaSu(cmd, seconds)

    /**
     * فحص الصلاحية: روت أولاً (قد تظهر نافذة Magisk أول مرة)، ثم Shizuku.
     * عند النجاح يعيد Out(0, "0") في الحالتين.
     */
    fun probe(): Out {
        val r = viaSu("id -u", 30)
        if (r.code == 0 && r.text.trim() == "0") { Priv.mode = "root"; return r }
        if (Priv.shizukuAlive()) {
            if (Priv.shizukuGranted()) {
                val s = Priv.viaShizuku("id -u", 15)
                val u = s.text.trim()
                if (s.code == 0 && (u == "0" || u == "2000")) { Priv.mode = "shizuku"; return Out(0, "0") }
                return Out(-1, "Shizuku: " + s.text.trim().take(80))
            }
            Priv.shizukuRequest()
            return Out(-1, "Shizuku يعمل — امنح Aero الإذن في النافذة التي ظهرت ثم أعد المحاولة")
        }
        return Out(-1, if (r.text.isNotBlank()) r.text else "لا روت ولا Shizuku — شغّل Shizuku أو امنح الروت")
    }
}

