package app.aero.launcher

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.widget.TextView

/** واجهة إعداد «تحديد الاستخدام». */
class GuardUi(private val a: MainActivity) {
    private fun fmt(ms: Long): String { val s = maxOf(ms, 0L) / 1000; return "${s / 60} د ${s % 60} ث" }
    private fun hms(ms: Long): String { val m = maxOf(ms, 0L) / 60000; return "${m / 60} س ${m % 60} د" }

    private fun submit(n: GCfg) {
        val now = Guard.submit(a, n)
        a.toast(if (now) "تم التطبيق" else "هذا يخفف القيود: سيُطبَّق بعد 24 ساعة")
        Guard.refresh(a)
    }

    private fun choose(title: String, opts: List<Int>, label: (Int) -> String, apply: (Int) -> Unit) {
        val sh = Sheet(a).header(title)
        opts.forEach { v -> sh.action(label(v)) { apply(v); show() } }
        sh.show()
    }

    fun show() {
        val g = Guard.cfg(a)
        val w = Guard.working(a)
        val sb = StringBuilder()
        sb.append("الحماية: ").append(if (g.enabled) "مفعّلة" else "متوقفة").append('\n')
        sb.append("خدمة الإنفاذ (إمكانية الوصول): ").append(if (NavService.active) "تعمل" else "غير مفعّلة").append('\n')
        if (g.enabled) {
            sb.append("الرصيد المتبقي: ").append(fmt(Guard.remainingMs(a))).append('\n')
            sb.append("رصيد جديد بعد: ").append(Guard.nextGrantMs(a) / 60000).append(" دقيقة\n")
        }
        sb.append("القاعدة: ${g.base} دقيقة كل ساعة، و${g.bonusM} دقيقة عند الساعة ${g.bonusH}:00\n")
        sb.append("يُصفَّر الرصيد يومياً الساعة 8:00 صباحاً\n")
        Guard.stagedRemainingMs(a)?.let { sb.append("تغيير معلّق يُطبَّق بعد ").append(hms(it)).append('\n') }
        val (ua, uu) = Guard.unlockInfo(a)
        val t = Guard.now(a)
        if (t < ua) sb.append("فتح الإعدادات سيبدأ بعد ").append(hms(ua - t)).append('\n')
        else if (t < uu) sb.append("الإعدادات مفتوحة الآن لمدة ").append(hms(uu - t)).append('\n')

        val tv = TextView(a).apply { text = sb.toString().trim(); setTextColor(Color.WHITE); textSize = 13.5f }
        val sh = Sheet(a).header("تحديد الاستخدام (منع الإدمان)").view(tv)

        if (!w.enabled) {
            sh.action("تشغيل الحماية") {
                if (!NavService.isEnabled(a)) {
                    a.toast("فعّل «Aero شريط التنقل» أولاً من إمكانية الوصول")
                    a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    return@action
                }
                Guard.tz(a)
                val ex = if (w.exempt.isEmpty()) Guard.defaultExempt(a) else w.exempt
                submit(w.copy(enabled = true, exempt = ex))
                show()
            }
        } else {
            sh.action("إيقاف الحماية (يُطبَّق بعد 24 ساعة)", true) { submit(w.copy(enabled = false)); show() }
        }
        sh.action("دقائق كل ساعة: ${w.base}") {
            choose("دقائق كل ساعة", listOf(1, 2, 3, 5, 10, 15), { "$it دقيقة" }) { submit(w.copy(base = it)) }
        }
        sh.action("دقائق المكافأة: ${w.bonusM}") {
            choose("دقائق المكافأة", listOf(5, 10, 15, 20, 30, 45, 60), { "$it دقيقة" }) { submit(w.copy(bonusM = it)) }
        }
        sh.action("ساعة المكافأة: ${w.bonusH}:00") {
            choose("ساعة المكافأة", listOf(12, 15, 18, 19, 20, 21, 22, 23), { "$it:00" }) { submit(w.copy(bonusH = it)) }
        }
        sh.action("التطبيقات المستثناة (${w.exempt.size})") { exemptSheet() }
        sh.action("طلب فتح الإعدادات (بعد 30 دقيقة، لمدة 10 دقائق)") { Guard.requestUnlock(a); a.toast("سيُفتح بعد 30 دقيقة"); show() }
        if (Guard.stagedRemainingMs(a) != null) sh.action("إلغاء التغيير المعلّق") { Guard.cancelStaged(a); show() }
        sh.action("استثناء الحماية من توفير البطارية") {
            try { a.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + a.packageName))) }
            catch (e: Exception) { a.toast("غير متاح على هذا الجهاز") }
        }
        sh.action("فتح إعدادات إمكانية الوصول") {
            if (g.enabled && NavService.active && !Guard.settingsOpen(a)) a.toast("الإعدادات مقفلة بالحماية — اطلب الفتح أولاً")
            else a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        sh.show()
    }

    private fun exemptSheet() {
        val w = Guard.working(a)
        val sh = Sheet(a).header("التطبيقات المستثناة — اضغط للتبديل")
        a.all.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }.forEach { app ->
            val on = app.pkg in w.exempt
            sh.action((if (on) "✓  " else "      ") + app.label) {
                val cur = Guard.working(a)
                submit(cur.copy(exempt = if (app.pkg in cur.exempt) cur.exempt - app.pkg else cur.exempt + app.pkg))
                exemptSheet()
            }
        }
        sh.show()
    }
}
