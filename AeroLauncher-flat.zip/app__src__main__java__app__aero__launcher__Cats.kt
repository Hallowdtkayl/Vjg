package app.aero.launcher

import android.content.Context
import android.content.pm.ApplicationInfo

/** 10 تصنيفات ثابتة فقط. لكل تطبيق تصنيف دائماً (تلقائي، ثم من الذكاء الاصطناعي، ثم يدوي). */
object Cats {
    val names = listOf(
        "تواصل واجتماعي", "ترفيه", "ألعاب", "إنتاجية وعمل", "تسوق ومال",
        "سفر وخرائط", "كاميرا وصور", "تعليم وأخبار", "صحة ورياضة", "أدوات ونظام")
    private val hints = listOf(
        "مراسلة، شبكات اجتماعية، مكالمات، بريد", "فيديو، موسيقى، بث، بودكاست", "كل الألعاب",
        "مستندات، ملاحظات، تقويم، تخزين سحابي، اجتماعات", "متاجر، بنوك، محافظ، دفع",
        "خرائط، مواصلات، حجز، طقس", "كاميرا، معرض، تعديل صور وفيديو", "تعلّم، قراءة، كتب، أخبار",
        "صحة، لياقة، رياضة", "إعدادات، ملفات، حاسبة، ساعة، متصفح، أدوات النظام وأي شيء لا يناسب غيره")

    fun prompt(apps: List<AppInfo>): String {
        val sb = StringBuilder()
        sb.append("صنّف تطبيقات أندرويد التالية. لكل تطبيق اختر رقم تصنيف واحداً فقط من هذه القائمة:\n")
        names.forEachIndexed { i, n -> sb.append("${i + 1} = $n (${hints[i]})\n") }
        sb.append("\nالقواعد:\n")
        sb.append("- كل تطبيق يجب أن يحصل على تصنيف واحد بدون أي استثناء.\n")
        sb.append("- لا تضف تصنيفات جديدة، والرقم 10 هو الخيار الافتراضي عند الشك.\n")
        sb.append("- أجب فقط بسطر لكل تطبيق بهذا الشكل: اسم.الحزمة=الرقم\n")
        sb.append("- بدون شرح أو ترقيم أو عناوين أو أي نص آخر، وانسخ اسم الحزمة كما هو بالضبط.\n\n")
        sb.append("التطبيقات (الحزمة | الاسم):\n")
        apps.distinctBy { it.pkg }.forEach { sb.append("${it.pkg} | ${it.orig}\n") }
        return sb.toString()
    }

    private val rx = Regex("""([A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+)["']?\s*(?:->|=>|→|[:=|,\-–—])\s*["']?\s*([^"'\n,}\]]+)""")

    /** يقرأ رد الذكاء الاصطناعي (أسطر أو JSON) ويعيد خريطة حزمة -> فهرس تصنيف. */
    fun parse(text: String, pkgs: Set<String>): Map<String, Int> {
        val out = HashMap<String, Int>()
        rx.findAll(text).forEach { m ->
            val pkg = m.groupValues[1]
            if (pkg !in pkgs) return@forEach
            val v = m.groupValues[2].trim()
            val lead = Regex("^\\d{1,2}").find(v)?.value?.toIntOrNull()
            val tail = Regex("(\\d{1,2})\\s*$").find(v)?.groupValues?.get(1)?.toIntOrNull()
            val byName = names.indexOfFirst { v.contains(it) }
            val idx = when {
                lead != null -> lead - 1
                byName >= 0 -> byName
                tail != null -> tail - 1
                else -> -1
            }
            if (idx in 0..9) out[pkg] = idx
        }
        return out
    }

    private val kw: List<Pair<Int, List<String>>> = listOf(
        2 to listOf("game", "supercell", "mojang", "roblox", "pubg", "garena", "miniclip", "gameloft", "zynga", "unity3d"),
        0 to listOf("whatsapp", "telegram", "messenger", "instagram", "facebook", "twitter", "snapchat", "discord", "signal",
            "viber", "tiktok", "linkedin", "reddit", "wechat", "skype", "dialer", "contacts", "mms", "messaging", "sms",
            "gmail", "email", "mail", "outlook", "truecaller", "pinterest", "threads"),
        1 to listOf("youtube", "netflix", "spotify", "music", "video", "vlc", "podcast", "twitch", "shahid", "anghami",
            "soundcloud", "deezer", "disney", "primevideo"),
        6 to listOf("camera", "gallery", "photo", "snapseed", "lightroom", "vsco", "capcut", "inshot", "picsart"),
        5 to listOf("maps", "navigation", "uber", "careem", "booking", "airbnb", "weather", "taxi", "transit", "flight",
            "travel", "waze", "hotel", "airline"),
        4 to listOf("bank", "wallet", "paypal", "shop", "amazon", "aliexpress", "ebay", "noon", "temu", "shein", "finance",
            "crypto", "binance"),
        8 to listOf("health", "fitness", "fitbit", "workout", "sport", "gym", "medical", "yoga", "calorie", "pharm", "doctor", "strava"),
        7 to listOf("news", "kindle", "duolingo", "school", "quran", "bible", "coursera", "udemy", "khan", "dictionary",
            "translate", "wikipedia"),
        3 to listOf("office", "docs", "sheets", "excel", "powerpoint", "drive", "notes", "calendar", "todo", "notion", "pdf",
            "slack", "zoom", "teams", "dropbox", "onenote", "evernote", "trello", "scanner")
    )

    @Suppress("DEPRECATION")
    fun auto(ctx: Context, a: AppInfo): Int {
        val ai = try { ctx.packageManager.getApplicationInfo(a.pkg, 0) } catch (e: Exception) { null }
        if (ai != null) {
            when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> return 2
                ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> return 1
                ApplicationInfo.CATEGORY_IMAGE -> return 6
                ApplicationInfo.CATEGORY_SOCIAL -> return 0
                ApplicationInfo.CATEGORY_NEWS -> return 7
                ApplicationInfo.CATEGORY_MAPS -> return 5
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> return 3
                else -> {}
            }
            if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return 2
        }
        val s = (a.pkg + " " + a.orig).lowercase()
        for ((i, ks) in kw) if (ks.any { s.contains(it) }) return i
        return 9
    }
}
