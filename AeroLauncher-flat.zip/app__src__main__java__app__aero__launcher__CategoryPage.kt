package app.aero.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** مكتبة التطبيقات: كل التطبيقات في تصنيفات (10 كحد أقصى). المس عنوان التصنيف لطيّه. */
class CategoryPage(ctx: Context) : ScrollView(ctx) {
    private val d = resources.displayMetrics.density
    private val col = LinearLayout(ctx)

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        col.orientation = LinearLayout.VERTICAL
        val p = (8 * d).toInt()
        col.setPadding(p, p, p, (24 * d).toInt())
        addView(col, FrameLayout.LayoutParams(-1, -2))
    }

    fun toolbar(copy: () -> Unit, paste: () -> Unit, reset: () -> Unit) {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, f: () -> Unit): TextView = TextView(context).apply {
            text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; maxLines = 2
            background = rr(0x4D000000, 22 * d)
            setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
            setOnClickListener { f() }
        }
        val lp = { LinearLayout.LayoutParams(0, (48 * d).toInt(), 1f).apply { setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0) } }
        row.addView(btn("1) نسخ أمر الذكاء الاصطناعي", copy), lp())
        row.addView(btn("2) لصق الرد وتطبيقه", paste), lp())
        row.addView(btn("تصنيف تلقائي", reset), lp())
        col.addView(row)
        col.addView(TextView(context).apply {
            text = "انسخ الأمر ← الصقه في أي ذكاء اصطناعي ← انسخ رده ← اضغط «لصق الرد». اضغط مطولاً على أي تطبيق لتغيير تصنيفه."
            setTextColor(0xB3FFFFFF.toInt()); textSize = 12f
            setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), 0)
        })
    }

    fun section(title: String, cells: List<AppCell>, cols: Int) {
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = rr(0x4D000000, 22 * d)
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (8 * d).toInt())
        }
        val grid = FlowGrid(context, cols)
        cells.forEach { grid.addView(it) }
        val head = TextView(context).apply {
            text = "$title  (${cells.size})"; setTextColor(Color.WHITE); textSize = 15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            setOnClickListener { grid.visibility = if (grid.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        box.addView(head)
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        col.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (10 * d).toInt() })
    }
}

class FlowGrid(ctx: Context, private val cols: Int) : ViewGroup(ctx) {
    private val d = resources.displayMetrics.density
    private fun cellH(w: Int): Int = minOf(((w / cols) * 1.25f).toInt(), (96 * d).toInt())
    override fun onMeasure(ws: Int, hs: Int) {
        val w = sz(ws); val rows = (childCount + cols - 1) / cols; val ch = cellH(w)
        setMeasuredDimension(w, rows * ch)
        for (i in 0 until childCount) getChildAt(i).measure(ex(w / cols), ex(ch))
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l; val cw = w / cols; val ch = cellH(w)
        for (i in 0 until childCount) {
            val x = (i % cols) * cw; val y = (i / cols) * ch
            getChildAt(i).layout(x, y, x + cw, y + ch)
        }
    }
}
