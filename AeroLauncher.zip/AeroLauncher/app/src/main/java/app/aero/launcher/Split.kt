package app.aero.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * تقسيم الشاشة إلى 4 نوافذ حرة.
 *  - عمودي: 2 فوق + 2 تحت.   - أفقي: 4 جنب بعض.
 *  - أزرار 1-4 عند نقطة التقاء النوافذ: تركيز نافذة (تكبر وتتقلص البقية)، وضغطة ثانية ترجع التقسيم الرباعي.
 */
object Split {
    const val FOCUS = 0.65f   // نسبة النافذة المركّزة
    const val GAP_DP = 4

    /** سجل آخر ترتيب (للتشخيص من قائمة التقسيم). */
    @Volatile var lastLog: String = "لم يُشغَّل التقسيم بعد."

    // هوامش النظام (شريط الحالة/التنقل) كما رآها اللانشر، لكل اتجاه للشاشة.
    private val insetCache = HashMap<Int, Rect>()

    fun remember(rot: Int, l: Int, t: Int, r: Int, b: Int) { insetCache[rot] = Rect(l, t, r, b) }

    fun rotation(ctx: Context): Int =
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation

    private fun dimen(ctx: Context, name: String): Int {
        val id = ctx.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else 0
    }

    /** المساحة المتاحة للنوافذ: الشاشة ناقص شريط الحالة وشريط التنقل وشريط مهام Aero. */
    fun area(ctx: Context, taskbarPx: Int): Rect {
        val s = Win.screen(ctx)
        val c = insetCache[rotation(ctx)]
        val l: Int; val t: Int; val r: Int; val b: Int
        if (c != null) { l = c.left; t = c.top; r = c.right; b = c.bottom }
        else {
            val portrait = s.height() > s.width()
            val threeBtn = Settings.Secure.getInt(ctx.contentResolver, "navigation_mode", 2) == 0
            l = 0; r = 0; t = dimen(ctx, "status_bar_height")
            b = if (portrait && threeBtn) dimen(ctx, "navigation_bar_height") else 0
        }
        return Rect(s.left + l, s.top + t, s.right - r, s.bottom - b - taskbarPx)
    }

    /** 4 تطبيقات: المختار أولاً، والخانات الفارغة تُملأ تلقائياً بالأكثر استخداماً. */
    fun resolve(all: List<AppInfo>, st: Store): List<ComponentName?> {
        val byKey = all.associateBy { it.key }
        val chosen = st.splitSlots.map { k -> byKey[k]?.let { ComponentName(it.pkg, it.cls) } }.toMutableList()
        val used = chosen.filterNotNull().map { it.packageName + "/" + it.className }.toMutableSet()
        val pool = all.filter { it.key !in st.hidden }.sortedByDescending { st.usage(it.key) }.iterator()
        for (i in 0..3) {
            if (chosen[i] != null) continue
            while (pool.hasNext()) {
                val a = pool.next()
                if (a.key in used) continue
                used.add(a.key); chosen[i] = ComponentName(a.pkg, a.cls); break
            }
        }
        return chosen
    }

    class Result(val rects: List<Rect>, val seamX: Int, val seamY: Int)

    /**
     * ترتيب الخانات: عمودي 0=أعلى يسار 1=أعلى يمين 2=أسفل يسار 3=أسفل يمين، وأفقي من اليسار لليمين.
     * التركيز: عمودي = المركّزة في الأسفل (متناول الإبهام) والبقية في شريط علوي؛
     *          أفقي = المركّزة في جهتها والبقية مكدّسة في العمود المقابل.
     */
    fun compute(a: Rect, land: Boolean, gap: Int, focus: Int, f: Float): Result {
        if (focus < 0) return grid(a, land, gap)
        val others = (0..3).filter { it != focus }
        val out = arrayOfNulls<Rect>(4)
        if (!land) {
            val fh = ((a.height() - gap) * f).toInt()
            val stripH = a.height() - gap - fh
            val fr = Rect(a.left, a.bottom - fh, a.right, a.bottom)
            out[focus] = fr
            val w = (a.width() - 2 * gap) / 3
            others.forEachIndexed { n, slot ->
                val l = a.left + n * (w + gap)
                out[slot] = Rect(l, a.top, l + w, a.top + stripH)
            }
            return Result(out.map { it!! }, a.centerX(), fr.top - gap / 2)
        }
        val fw = ((a.width() - gap) * f).toInt()
        val stripW = a.width() - gap - fw
        val onRight = focus >= 2
        val fr = if (onRight) Rect(a.right - fw, a.top, a.right, a.bottom) else Rect(a.left, a.top, a.left + fw, a.bottom)
        out[focus] = fr
        val h = (a.height() - 2 * gap) / 3
        val sl = if (onRight) a.left else a.right - stripW
        others.forEachIndexed { n, slot ->
            val t = a.top + n * (h + gap)
            out[slot] = Rect(sl, t, sl + stripW, t + h)
        }
        return Result(out.map { it!! }, if (onRight) fr.left - gap / 2 else fr.right + gap / 2, a.bottom)
    }

    private fun grid(a: Rect, land: Boolean, gap: Int): Result {
        val rects = ArrayList<Rect>(4)
        if (land) {
            val w = (a.width() - 3 * gap) / 4
            for (i in 0..3) { val l = a.left + i * (w + gap); rects.add(Rect(l, a.top, l + w, a.bottom)) }
            return Result(rects, a.centerX(), a.bottom)
        }
        val w = (a.width() - gap) / 2; val h = (a.height() - gap) / 2
        for (i in 0..3) {
            val l = a.left + (i % 2) * (w + gap); val t = a.top + (i / 2) * (h + gap)
            rects.add(Rect(l, t, l + w, t + h))
        }
        return Result(rects, a.centerX(), a.centerY())
    }
}

/** أوامر الروت (su). */
object RootSh {
    class Out(val code: Int, val text: String)

    fun run(cmd: String, seconds: Long = 8): Out = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(seconds, TimeUnit.SECONDS)) { p.destroy(); Out(-1, text) } else Out(p.exitValue(), text)
    } catch (e: Exception) { Out(-1, e.message ?: "") }

    /** فحص الروت: مهلة طويلة لأن Magisk قد يعرض نافذة طلب الإذن أول مرة. */
    fun probe(): Out = run("id -u", 30)
}

/**
 * المحرك: يعمل داخل NavService (خدمة إمكانية الوصول) فتظهر أزرار التركيز بلا صلاحية «العرض فوق التطبيقات».
 *  - بالروت: يشغّل كل تطبيق بوضع freeform (windowingMode 5) ويحفظ رقم مهمته، ثم `task resize`.
 *    التركيز والتدوير يعيدان التحجيم فقط (دون إعادة تشغيل التطبيقات) فلا تتبدّل الشاشات.
 *  - إن لم يتحول التطبيق إلى freeform نجرّب launch bounds (الآلية نفسها التي يستخدمها اللانشر لنوافذه).
 *  - بدون روت: launch bounds عند التشغيل فقط، ولا تُعاد ترتيب نوافذ مفتوحة.
 * كل خطوة تُسجَّل في Split.lastLog (قائمة التقسيم ← تشخيص).
 */
class SplitEngine(private val svc: NavService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val d: Float get() = svc.resources.displayMetrics.density

    private var cluster: LinearLayout? = null
    private var clusterLand = false
    private val btns = ArrayList<TextView>()
    private var slots: List<ComponentName?> = emptyList()
    private var focus = -1
    private var startedAt = 0L

    @Volatile private var root: Boolean? = null
    private val ids = IntArray(4) { -1 }   // رقم مهمة كل نافذة بعد ضبطها

    var running = false
        private set

    private val relayout = Runnable { apply(false) }

    fun start(list: List<ComponentName?>) {
        slots = list; focus = -1; running = true; root = null
        ids.fill(-1)
        startedAt = SystemClock.elapsedRealtime()
        apply(true)
    }

    fun stop() {
        running = false
        h.removeCallbacks(relayout)
        removeCluster()
    }

    /** تدوير الشاشة: ننتظر استقراره ثم نعيد التحجيم. */
    fun onConfig() {
        if (!running) return
        h.removeCallbacks(relayout); h.postDelayed(relayout, 700)
    }

    /** نخفي الأزرار عند العودة للانشر ونُظهرها مع أي تطبيق آخر. */
    fun onForeground(pkg: String) {
        if (!running) return
        val v = cluster ?: return
        if (pkg == svc.packageName) {
            if (SystemClock.elapsedRealtime() - startedAt > 2500) v.visibility = View.GONE
        } else v.visibility = View.VISIBLE
    }

    private fun onTap(i: Int) {
        if (root == false) { toast("التركيز يحتاج روت، والروت غير متاح لهذا التطبيق"); return }
        focus = if (focus == i) -1 else i
        apply(false)
    }

    private fun apply(first: Boolean) {
        if (!running) return
        val st = Store(svc)
        val tb = if (st.taskbar) (NavService.H_DP * d).toInt() else 0
        val area = Split.area(svc, tb)
        val land = area.width() > area.height()
        val res = Split.compute(area, land, (Split.GAP_DP * d).toInt(), focus, Split.FOCUS)
        try { showCluster(res, land) } catch (e: Exception) { toast("تعذر عرض أزرار التقسيم") }
        val rects = res.rects; val list = slots; val f = focus
        io.execute { arrange(first, rects, list, land, area, f) }
    }

    // ---------- الترتيب (على خيط خلفي) ----------
    private fun arrange(first: Boolean, rects: List<Rect>, list: List<ComponentName?>, land: Boolean, area: Rect, f: Int) {
        val sb = StringBuilder()
        val now = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        sb.append("[$now] ${if (land) "أفقي" else "عمودي"} | المساحة ${area.width()}×${area.height()} | تركيز: ${if (f < 0) "لا" else (f + 1).toString()}\n")

        val cached = root
        val useRoot: Boolean
        if (cached == null || first) {
            val p = RootSh.probe()
            useRoot = p.code == 0 && p.text.trim() == "0"
            root = useRoot
            sb.append("الروت: ").append(if (useRoot) "متاح ✓" else "غير متاح ✗ (" + p.text.trim().take(100) + ")").append('\n')
            if (first) {
                val msg = if (useRoot) "الروت متاح ✓ — أرتّب النوافذ"
                else "الروت غير متاح — تُضبط أبعاد التطبيقات غير المفتوحة فقط. أغلق التطبيقات ثم أعد التشغيل، أو امنح التطبيق صلاحية الروت."
                h.post { toast(msg) }
            }
        } else {
            useRoot = cached
        }

        var failures = 0
        if (useRoot) {
            for (i in 0..3) {
                val c = list.getOrNull(i) ?: continue
                val r = rects[i]
                var id = if (first) -1 else ids[i]
                var ok = false
                if (id > 0) { ok = resize(id, r, sb); if (!ok) id = -1 }
                if (!ok) {
                    id = launchRoot(c, sb)
                    if (id > 0) {
                        ok = resize(id, r, sb)
                        val m = modeOf(c.packageName)
                        if (ok && m != "freeform") {
                            sb.append("  ${c.packageName}: الوضع $m، أجرّب launch bounds\n")
                            try { boundsPlace(c, r); Thread.sleep(600) } catch (e: Exception) { sb.append("  ✗ ${e.message}\n") }
                            val id2 = findTask(c.packageName)
                            if (id2 > 0) { id = id2; ok = resize(id2, r, sb) }
                        }
                    }
                }
                ids[i] = if (ok) id else -1
                if (!ok) failures++
            }
            failures += report(list, sb)
        } else if (first) {
            for (i in 0..3) {
                val c = list.getOrNull(i) ?: continue
                try { boundsPlace(c, rects[i]); sb.append("  ${i + 1}. ${c.packageName}: launch bounds\n") }
                catch (e: Exception) { sb.append("  ✗ ${c.packageName}: ${e.message}\n"); failures++ }
            }
        } else {
            sb.append("بدون روت: لا إعادة ترتيب\n")
        }

        Split.lastLog = sb.toString()
        if (failures > 0) h.post { toast("تعذّر ضبط $failures نافذة — افتح «تشخيص» من قائمة تقسيم الشاشة") }
    }

    // ---------- بدون روت ----------
    private fun boundsPlace(c: ComponentName, r: Rect) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(c)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val o = ActivityOptions.makeBasic().setLaunchBounds(r)
        svc.startActivity(i, o.toBundle())
        Thread.sleep(150)
    }

    // ---------- بالروت ----------
    private fun launchRoot(c: ComponentName, sb: StringBuilder): Int {
        val comp = c.flattenToShortString()
        var o = RootSh.run("am start -n '$comp' --windowingMode 5")
        if (o.code != 0 || o.text.contains("Error") || o.text.contains("Unknown option")) {
            sb.append("  am start --windowingMode: ").append(o.text.trim().take(120)).append('\n')
            o = RootSh.run("am start -n '$comp'")
        }
        repeat(16) {
            val id = findTask(c.packageName)
            if (id > 0) return id
            Thread.sleep(250)
        }
        sb.append("  ✗ لم أجد مهمة ${c.packageName}: ").append(o.text.trim().take(120)).append('\n')
        return -1
    }

    private fun resize(id: Int, r: Rect, sb: StringBuilder): Boolean {
        val a = "${r.left} ${r.top} ${r.right} ${r.bottom}"
        val tries = listOf(
            "cmd activity task resize $id $a",
            "am task resize $id $a",
            "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}"
        )
        var err = ""
        for (t in tries) {
            val o = RootSh.run(t)
            val bad = o.code != 0 || o.text.contains("Exception") || o.text.contains("Error") || o.text.contains("Unknown")
            if (!bad) return true
            err = o.text.trim().lines().firstOrNull().orEmpty()
        }
        sb.append("  ✗ تحجيم #$id: $err\n")
        return false
    }

    /** سطر المهمة الأنسب للحزمة من dumpsys (يفضّل الظاهرة). */
    private fun taskLine(dump: String, pkg: String): String? {
        val re = Regex("Task\\{[^}]*?#(\\d+)[^}]*?[=:/]" + Regex.escape(pkg) + "[\\s/:}]")
        val m = dump.lines().filter { it.contains("Task{") && re.containsMatchIn(it) }
        return m.firstOrNull { it.contains("visible=true") } ?: m.firstOrNull()
    }

    private fun idOf(line: String): Int =
        Regex("Task\\{[^}]*?#(\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: -1

    private fun findTask(pkg: String): Int {
        val line = taskLine(RootSh.run("dumpsys activity recents").text, pkg) ?: return -1
        return idOf(line)
    }

    private fun modeOf(pkg: String): String {
        val line = taskLine(RootSh.run("dumpsys activity recents").text, pkg) ?: return "؟"
        return Regex("mode=([\\w-]+)").find(line)?.groupValues?.get(1) ?: "؟"
    }

    /** يسجل وضع كل نافذة؛ يعيد عدد النوافذ التي لم تصبح freeform. */
    private fun report(list: List<ComponentName?>, sb: StringBuilder): Int {
        val dump = RootSh.run("dumpsys activity recents").text
        var bad = 0
        list.forEachIndexed { i, c ->
            if (c == null) return@forEachIndexed
            val line = taskLine(dump, c.packageName)
            val mode = line?.let { Regex("mode=([\\w-]+)").find(it)?.groupValues?.get(1) } ?: "؟"
            sb.append("  ${i + 1}. ${c.packageName} #${ids[i]} mode=$mode\n")
            if (mode != "freeform") bad++
        }
        if (bad > 0) sb.append("تنبيه: $bad نافذة ليست freeform — فعّل Enable freeform windows وForce activities to be resizable ثم أعد التشغيل.\n")
        return bad
    }

    // ---------- أزرار التركيز ----------
    private fun buildCluster(land: Boolean): LinearLayout {
        btns.clear()
        val box = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val size = (34 * d).toInt(); val m = (2 * d).toInt()
        fun btn(i: Int) = TextView(svc).apply {
            text = (i + 1).toString(); gravity = Gravity.CENTER; textSize = 14f; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(size, size).also { it.setMargins(m, m, m, m) }
            setOnClickListener { onTap(i) }
            setOnLongClickListener { cluster?.visibility = View.GONE; toast("أُخفيت الأزرار — ترجع مع فتح أي تطبيق"); true }
        }.also { btns.add(it) }
        val rows = if (land) 1 else 2; val per = 4 / rows
        for (r in 0 until rows) {
            val line = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until per) line.addView(btn(r * per + c))
            box.addView(line)
        }
        return box
    }

    private fun showCluster(res: Split.Result, land: Boolean) {
        if (cluster != null && clusterLand != land) removeCluster()
        if (cluster == null) {
            val v = buildCluster(land)
            val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            wm.addView(v, lp)
            cluster = v; clusterLand = land
        }
        cluster?.visibility = View.VISIBLE
        btns.forEachIndexed { i, b ->
            b.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i == focus) 0xFF3D7BFF.toInt() else 0xCC222222.toInt())
                setStroke(maxOf(1, d.toInt()), 0x66FFFFFF)
            }
        }
        val v = cluster ?: return
        v.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val lp = v.layoutParams as WindowManager.LayoutParams
        lp.x = res.seamX - v.measuredWidth / 2
        lp.y = if (land) res.seamY - v.measuredHeight - (12 * d).toInt() else res.seamY - v.measuredHeight / 2
        wm.updateViewLayout(v, lp)
    }

    private fun removeCluster() {
        cluster?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        cluster = null
    }

    private fun toast(m: String) = Toast.makeText(svc, m, Toast.LENGTH_LONG).show()
}
