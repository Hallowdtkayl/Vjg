package app.aero.launcher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * تقسيم الشاشة إلى 4 نوافذ حرة.
 *  - عمودي: 2 فوق + 2 تحت.   - أفقي: 4 جنب بعض.
 *  - أزرار 1-4 عند نقطة التقاء النوافذ: تركيز نافذة (تكبر وتتقلص البقية)، وضغطة ثانية ترجع التقسيم الرباعي.
 */
object Split {
    const val FOCUS = 0.65f   // نسبة النافذة المركّزة
    const val GAP_DP = 4

    // هوامش النظام (شريط الحالة/التنقل) كما رآها اللانشر، لكل اتجاه للشاشة.
    private val insetCache = HashMap<Int, Rect>()

    fun remember(rot: Int, l: Int, t: Int, r: Int, b: Int) { insetCache[rot] = Rect(l, t, r, b) }

    fun rotation(ctx: Context): Int =
        ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation

    private fun dimen(ctx: Context, name: String): Int {
        val id = ctx.resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else 0
    }

    /** المساحة المتاحة للنوافذ: الشاشة ناقص شريط الحالة وشريط التنقل وشريط مهام Aero. */
    fun area(ctx: Context, taskbarPx: Int): Rect {
        val s = Win.screen(ctx)
        val c = insetCache[rotation(ctx)]
        val l: Int; val t: Int; val r: Int; val b: Int
        if (c != null) { l = c.left; t = c.top; r = c.right; b = c.bottom }
        else {
            val portrait = s.height() > s.width()
            val threeBtn = Settings.Secure.getInt(ctx.contentResolver, "navigation_mode", 2) == 0
            l = 0; r = 0; t = dimen(ctx, "status_bar_height")
            b = if (portrait && threeBtn) dimen(ctx, "navigation_bar_height") else 0
        }
        return Rect(s.left + l, s.top + t, s.right - r, s.bottom - b - taskbarPx)
    }

    /** 4 تطبيقات: المختار أولاً، والخانات الفارغة تُملأ تلقائياً بالأكثر استخداماً. */
    fun resolve(all: List<AppInfo>, st: Store): List<ComponentName?> {
        val byKey = all.associateBy { it.key }
        val chosen = st.splitSlots.map { k -> byKey[k]?.let { ComponentName(it.pkg, it.cls) } }.toMutableList()
        val used = chosen.filterNotNull().map { it.packageName + "/" + it.className }.toMutableSet()
        val pool = all.filter { it.key !in st.hidden }.sortedByDescending { st.usage(it.key) }.iterator()
        for (i in 0..3) {
            if (chosen[i] != null) continue
            while (pool.hasNext()) {
                val a = pool.next()
                if (a.key in used) continue
                used.add(a.key); chosen[i] = ComponentName(a.pkg, a.cls); break
            }
        }
        return chosen
    }

    class Result(val rects: List<Rect>, val seamX: Int, val seamY: Int)

    /**
     * ترتيب الخانات: عمودي 0=أعلى يسار 1=أعلى يمين 2=أسفل يسار 3=أسفل يمين، وأفقي من اليسار لليمين.
     * التركيز: عمودي = المركّزة في الأسفل (متناول الإبهام) والبقية في شريط علوي؛
     *          أفقي = المركّزة في جهتها والبقية مكدّسة في العمود المقابل.
     */
    fun compute(a: Rect, land: Boolean, gap: Int, focus: Int, f: Float): Result {
        if (focus < 0) return grid(a, land, gap)
        val others = (0..3).filter { it != focus }
        val out = arrayOfNulls<Rect>(4)
        if (!land) {
            val fh = ((a.height() - gap) * f).toInt()
            val stripH = a.height() - gap - fh
            val fr = Rect(a.left, a.bottom - fh, a.right, a.bottom)
            out[focus] = fr
            val w = (a.width() - 2 * gap) / 3
            others.forEachIndexed { n, slot ->
                val l = a.left + n * (w + gap)
                out[slot] = Rect(l, a.top, l + w, a.top + stripH)
            }
            return Result(out.map { it!! }, a.centerX(), fr.top - gap / 2)
        }
        val fw = ((a.width() - gap) * f).toInt()
        val stripW = a.width() - gap - fw
        val onRight = focus >= 2
        val fr = if (onRight) Rect(a.right - fw, a.top, a.right, a.bottom) else Rect(a.left, a.top, a.left + fw, a.bottom)
        out[focus] = fr
        val h = (a.height() - 2 * gap) / 3
        val sl = if (onRight) a.left else a.right - stripW
        others.forEachIndexed { n, slot ->
            val t = a.top + n * (h + gap)
            out[slot] = Rect(sl, t, sl + stripW, t + h)
        }
        return Result(out.map { it!! }, if (onRight) fr.left - gap / 2 else fr.right + gap / 2, a.bottom)
    }

    private fun grid(a: Rect, land: Boolean, gap: Int): Result {
        val rects = ArrayList<Rect>(4)
        if (land) {
            val w = (a.width() - 3 * gap) / 4
            for (i in 0..3) { val l = a.left + i * (w + gap); rects.add(Rect(l, a.top, l + w, a.bottom)) }
            return Result(rects, a.centerX(), a.bottom)
        }
        val w = (a.width() - gap) / 2; val h = (a.height() - gap) / 2
        for (i in 0..3) {
            val l = a.left + (i % 2) * (w + gap); val t = a.top + (i / 2) * (h + gap)
            rects.add(Rect(l, t, l + w, t + h))
        }
        return Result(rects, a.centerX(), a.centerY())
    }
}

/** أوامر الروت (su). */
object RootSh {
    class Out(val code: Int, val text: String)

    fun run(cmd: String): Out = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(8, TimeUnit.SECONDS)) { p.destroy(); Out(-1, text) } else Out(p.exitValue(), text)
    } catch (e: Exception) { Out(-1, e.message ?: "") }

    fun has(): Boolean { val o = run("id -u"); return o.code == 0 && o.text.trim() == "0" }
}

/**
 * المحرك: يعمل داخل NavService (خدمة إمكانية الوصول) فتظهر أزرار التركيز بلا صلاحية «العرض فوق التطبيقات».
 *  - بالروت: `am start --windowingMode 5` ثم `task resize`، فيعاد تحجيم النوافذ المفتوحة فوراً عند التركيز/التدوير.
 *  - بدون روت: launch bounds عند التشغيل فقط (التركيز لا يعمل على نوافذ مفتوحة).
 */
class SplitEngine(private val svc: NavService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val d: Float get() = svc.resources.displayMetrics.density

    private var cluster: LinearLayout? = null
    private var clusterLand = false
    private val btns = ArrayList<TextView>()
    private var slots: List<ComponentName?> = emptyList()
    private var focus = -1
    private var startedAt = 0L
    private var root: Boolean? = null
    private var last: Split.Result? = null

    var running = false
        private set

    private val relayout = Runnable { apply() }

    fun start(list: List<ComponentName?>) {
        slots = list; focus = -1; running = true; root = null
        startedAt = SystemClock.elapsedRealtime()
        apply()
    }

    fun stop() {
        running = false
        h.removeCallbacks(relayout)
        removeCluster()
    }

    /** تدوير الشاشة: ننتظر استقراره ثم نعيد الترتيب. */
    fun onConfig() {
        if (!running) return
        h.removeCallbacks(relayout); h.postDelayed(relayout, 700)
    }

    /** يُستدعى من أحداث النوافذ: نخفي الأزرار عند العودة للانشر ونُظهرها مع أي تطبيق آخر. */
    fun onForeground(pkg: String) {
        if (!running) return
        val v = cluster ?: return
        if (pkg == svc.packageName) {
            if (SystemClock.elapsedRealtime() - startedAt > 2500) v.visibility = View.GONE
        } else v.visibility = View.VISIBLE
    }

    private fun onTap(i: Int) { focus = if (focus == i) -1 else i; apply() }

    private fun apply() {
        if (!running) return
        val st = Store(svc)
        val tb = if (st.taskbar) (NavService.H_DP * d).toInt() else 0
        val area = Split.area(svc, tb)
        val land = area.width() > area.height()
        val res = Split.compute(area, land, (Split.GAP_DP * d).toInt(), focus, Split.FOCUS)
        last = res
        try { showCluster(res, land) } catch (e: Exception) { toast("تعذر عرض أزرار التقسيم") }
        val rects = res.rects
        io.execute {
            val log = StringBuilder()
            val useRoot = root ?: RootSh.has().also { root = it }
            for (i in 0..3) {
                val c = slots.getOrNull(i) ?: continue
                try {
                    if (useRoot) rootPlace(c, rects[i], log) else boundsPlace(c, rects[i])
                } catch (e: Exception) { log.append("النافذة ${i + 1}: ${e.message}\n") }
            }
            if (log.isNotBlank()) h.post { toast(log.toString().trim()) }
        }
    }

    // ---------- بدون روت ----------
    private fun boundsPlace(c: ComponentName, r: Rect) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(c)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val o = ActivityOptions.makeBasic().setLaunchBounds(r)
        try {
            ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(o, 5)
        } catch (e: Throwable) { /* غير متاح: نكتفي بـ launch bounds */ }
        svc.startActivity(i, o.toBundle())
        Thread.sleep(150)
    }

    // ---------- بالروت ----------
    private fun rootPlace(c: ComponentName, r: Rect, log: StringBuilder) {
        RootSh.run("am start -n '${c.flattenToShortString()}' --windowingMode 5")
        var id = -1
        for (k in 0 until 16) { id = findTask(c.packageName); if (id > 0) break; Thread.sleep(250) }
        if (id <= 0) { log.append("لم أجد مهمة ${c.packageName}\n"); return }
        val a = "${r.left} ${r.top} ${r.right} ${r.bottom}"
        val tries = listOf("cmd activity task resize $id $a", "am task resize $id $a",
            "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}")
        var ok = false; var err = ""
        for (t in tries) {
            val o = RootSh.run(t)
            if (o.code == 0 && !o.text.contains("Exception") && !o.text.contains("Error")) { ok = true; break }
            err = o.text.trim()
        }
        if (!ok) log.append("فشل تحجيم ${c.packageName}: $err\n")
    }

    /** رقم أحدث مهمة للحزمة من dumpsys (يفضّل الظاهرة). */
    private fun findTask(pkg: String): Int {
        val dump = RootSh.run("dumpsys activity recents").text
        val re = Regex("Task\\{[^}]*?#(\\d+)[^}]*?[=:/]" + Regex.escape(pkg) + "[\\s/:}]")
        val m = dump.lines().filter { it.contains("Task{") }.mapNotNull { l -> re.find(l)?.let { l to it.groupValues[1].toInt() } }
        return (m.firstOrNull { it.first.contains("visible=true") } ?: m.firstOrNull())?.second ?: -1
    }

    // ---------- أزرار التركيز ----------
    private fun buildCluster(land: Boolean): LinearLayout {
        btns.clear()
        val box = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val size = (34 * d).toInt(); val m = (2 * d).toInt()
        fun btn(i: Int) = TextView(svc).apply {
            text = (i + 1).toString(); gravity = Gravity.CENTER; textSize = 14f; setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(size, size).also { it.setMargins(m, m, m, m) }
            setOnClickListener { onTap(i) }
            setOnLongClickListener { cluster?.visibility = View.GONE; toast("أُخفيت الأزرار — ترجع مع فتح أي تطبيق"); true }
        }.also { btns.add(it) }
        val rows = if (land) 1 else 2; val per = 4 / rows
        for (r in 0 until rows) {
            val line = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until per) line.addView(btn(r * per + c))
            box.addView(line)
        }
        return box
    }

    private fun showCluster(res: Split.Result, land: Boolean) {
        if (cluster != null && clusterLand != land) removeCluster()
        if (cluster == null) {
            val v = buildCluster(land)
            val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            wm.addView(v, lp)
            cluster = v; clusterLand = land
        }
        cluster?.visibility = View.VISIBLE
        btns.forEachIndexed { i, b ->
            b.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i == focus) 0xFF3D7BFF.toInt() else 0xCC222222.toInt())
                setStroke(maxOf(1, d.toInt()), 0x66FFFFFF)
            }
        }
        val v = cluster ?: return
        v.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val lp = v.layoutParams as WindowManager.LayoutParams
        lp.x = res.seamX - v.measuredWidth / 2
        lp.y = if (land) res.seamY - v.measuredHeight - (12 * d).toInt() else res.seamY - v.measuredHeight / 2
        wm.updateViewLayout(v, lp)
    }

    private fun removeCluster() {
        cluster?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        cluster = null
    }

    private fun toast(m: String) = Toast.makeText(svc, m, Toast.LENGTH_LONG).show()
}
