package app.aero.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

class MainActivity : Activity() {
    lateinit var st: Store
    lateinit var frame: FrameLayout
    lateinit var root: LauncherLayout
    private lateinit var pager: ViewPager2
    private lateinit var dots: Dots
    private lateinit var dock: DockView
    private lateinit var host: AppWidgetHost
    private lateinit var mgr: AppWidgetManager
    var all: List<AppInfo> = emptyList()
    var search: SearchOverlay? = null
    var picker: WidgetPicker? = null
    var folder: FolderOverlay? = null
    private var infos: Map<String, AppInfo> = emptyMap()
    private var curPageIds: List<String> = emptyList()
    private var curHomeIds: List<String> = emptyList()
    private var pages: List<View> = emptyList()
    private var perPage = 30
    private var pendingKey = ""
    private var pendingWidget = -1
    private var pendingIndex: Int? = null
    private var lastRot = -1
    private var swallow = false
    private val gtick = object : Runnable {
        override fun run() {
            val was = Guard.blocked
            Guard.refresh(this@MainActivity)
            if (Guard.blocked != was) rebuild()
            hnd.postDelayed(this, 3000)
        }
    }

    private enum class Src { PAGE, HOME, DOCK }
    private val hnd = Handler(Looper.getMainLooper())
    private var dragGhost: AppCell? = null
    private var dragMoved = false
    private var dragX0 = 0f
    private var dragY0 = 0f
    private var edgeDir = 0
    private val flip = object : Runnable {
        override fun run() {
            if (edgeDir == 0 || dragGhost == null) return
            val n = pager.currentItem + edgeDir
            if (n in 0 until pages.size) pager.setCurrentItem(n, true)
            hnd.postDelayed(this, 750)
        }
    }

    private val REQ_ICON = 11
    private val REQ_BIND = 12
    private val REQ_CONFIG = 13
    private val HOME = 1
    private var firstBuild = true
    private val autoCat = HashMap<String, Int>()

    val d: Float get() = resources.displayMetrics.density
    val visible: List<AppInfo> get() = all.filter { it.key !in st.hidden }
    private val land: Boolean get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun isFolder(id: String) = id.startsWith("folder:")
    private fun tbPx(): Int = if (NavService.active && st.taskbar) (NavService.H_DP * d).toInt() else 0
    @Suppress("DEPRECATION")
    private fun rot(): Int = windowManager.defaultDisplay.rotation

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { reload() }
    }
    private val dl = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { if (rot() != lastRot) rebuild() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false }
        mgr = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        pager = ViewPager2(this); dots = Dots(this); dock = DockView(this)
        pager.layoutDirection = View.LAYOUT_DIRECTION_LTR
        dots.layoutDirection = View.LAYOUT_DIRECTION_LTR
        pager.setPageTransformer { v, pos ->
            val k = 1f - abs(pos).coerceAtMost(1f)
            v.alpha = 0.35f + 0.65f * k
            v.scaleX = 0.93f + 0.07f * k; v.scaleY = 0.93f + 0.07f * k
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(p: Int, o: Float, px: Int) { dots.pos = p + o }
            override fun onPageSelected(position: Int) { root.noSearch = position == 0 }
        })
        root = LauncherLayout(this, pager, dots, dock)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x33000000, 0x00000000, 0x66000000))
        root.onSwipeDown = { openSearch() }
        frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        ViewCompat.setOnApplyWindowInsetsListener(frame) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            Split.remember(rot(), bars.left, bars.top, bars.right, bars.bottom)
            root.inset.set(bars.left, bars.top, bars.right, bars.bottom + tbPx())
            root.requestLayout()
            ins
        }
        ViewCompat.requestApplyInsets(frame)
        Guard.refresh(this)
        reload()
    }

    override fun onStart() {
        super.onStart()
        try { host.startListening() } catch (e: Exception) {}
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED) else registerReceiver(pkgReceiver, f)
        getSystemService(DisplayManager::class.java).registerDisplayListener(dl, null)
        NavService.onChange = { runOnUiThread { ViewCompat.requestApplyInsets(frame) } }
        hnd.post(gtick)
        ViewCompat.requestApplyInsets(frame)
        if (rot() != lastRot) rebuild()
    }

    override fun onStop() {
        super.onStop()
        NavService.onChange = null
        hnd.removeCallbacks(gtick)
        try { host.stopListening() } catch (e: Exception) {}
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        getSystemService(DisplayManager::class.java).unregisterDisplayListener(dl)
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        rebuild()
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        search?.close(false); picker?.close(false); folder?.close(false)
        pager.setCurrentItem(HOME, true)
    }

    @Suppress("DEPRECATION")
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        // زر الفأرة الأيمن = رجوع
        if (e.isFromSource(InputDevice.SOURCE_MOUSE)) {
            if (e.actionMasked == MotionEvent.ACTION_DOWN && (e.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                swallow = true
                onBackPressed()
                return true
            }
            if (swallow) {
                if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) swallow = false
                return true
            }
        }
        return super.dispatchTouchEvent(e)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (picker != null) picker?.close()
        else if (folder != null) folder?.close()
        else if (search != null) search?.close()
        else if (pager.currentItem != HOME) pager.currentItem = HOME
    }

    // ---------- البيانات والبناء ----------
    fun reload() {
        all = Repo.load(this, st)
        if (!st.initDone && all.isNotEmpty()) { initDefaults(); st.initDone = true }
        rebuild()
    }

    private fun initDefaults() {
        fun pk(i: Intent) = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val browser = if (all.any { it.pkg == "com.android.chrome" }) "com.android.chrome"
        else pk(Intent(Intent.ACTION_VIEW, Uri.parse("http://example.com")))
        val pkgs = listOf(pk(Intent(Intent.ACTION_DIAL)), pk(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            pk(Intent(MediaStore.ACTION_IMAGE_CAPTURE)), browser)
        st.dock = pkgs.mapNotNull { p -> all.firstOrNull { it.pkg == p }?.key }.distinct()
    }

    private fun folderInfo(f: FolderData, byKey: Map<String, AppInfo>): AppInfo {
        val ai = AppInfo(f.key, "", "", f.name, FolderDrawable(f.apps.mapNotNull { byKey[it] }.take(4)))
        val p = st.iconPath(f.key)
        if (p.isNotEmpty()) ai.custom = BitmapFactory.decodeFile(p)
        return ai
    }

    private fun cellOf(a: AppInfo, label: Boolean, src: Src): AppCell {
        val c = AppCell(this, a, label, st.scale)
        if (isFolder(a.key)) {
            var pend: Runnable? = null
            c.setOnClickListener {
                val main = st.folders().firstOrNull { it.key == a.key }?.main ?: ""
                val mainApp = if (main.isNotEmpty()) all.firstOrNull { it.key == main } else null
                if (mainApp == null) openFolder(a.key, c)
                else if (pend != null) { pend?.let { c.removeCallbacks(it) }; pend = null; launch(mainApp, c) }
                else { val r = Runnable { pend = null; openFolder(a.key, c) }; pend = r; c.postDelayed(r, 260) }
            }
        } else c.setOnClickListener { launch(a, c) }
        c.setOnLongClickListener { startDrag(c, src); true }
        return c
    }

    fun rebuild() {
        lastRot = rot()
        val l = land
        root.side = if (!l) 0 else if (lastRot == Surface.ROTATION_90) 2 else 1
        dock.vertical = l
        val byKey = all.associateBy { it.key }
        val hid = st.hidden
        val fl = st.folders()
        val inFolder = fl.flatMap { it.apps }.toSet()
        infos = byKey + fl.associate { f -> f.key to folderInfo(f, byKey) }

        dock.removeAllViews()
        st.dock.mapNotNull { byKey[it] }.filter { it.key !in hid }.take(5).forEach { dock.addView(cellOf(it, false, Src.DOCK)) }

        curHomeIds = st.home.filter { infos.containsKey(it) && it !in hid && it !in inFolder }.distinct()
        val homeSet = curHomeIds.toSet()
        val avail = all.map { it.key }.filter { it !in hid && it !in inFolder && it !in homeSet } +
            fl.map { it.key }.filter { it !in homeSet }
        val availSet = avail.toSet()
        val ord = st.order.filter { it in availSet }.distinct()
        curPageIds = ord + avail.filter { it !in ord }

        // الرئيسية: 4×6 طولي / 6×4 أفقي — باقي الصفحات: 5×6 طولي / 7×4 أفقي
        val cols = if (l) 7 else 5; val rows = if (l) 4 else 6
        perPage = cols * rows
        val list = ArrayList<View>()
        val favCap = (if (l) 3 else 4) * 4
        val favCells = curHomeIds.take(favCap).mapNotNull { infos[it] }.map { cellOf(it, true, Src.HOME) }
        val home = HomePage(this, l, favCells, st.widgets.mapNotNull { widgetView(it) })
        home.setOnLongClickListener { openSettings(); true }
        val cat = CategoryPage(this)
        cat.toolbar({ copyPrompt() }, { importClipboard() }, { st.clearCats(); autoCat.clear(); rebuild() })
        val groups = visible.groupBy { catIndex(it) }
        for (i in Cats.names.indices) {
            val g = groups[i] ?: continue
            cat.section(Cats.names[i], g.sortedBy { it.label.lowercase() }.map { libCell(it) }, if (l) 7 else 5)
        }
        list.add(cat)
        list.add(home)
        curPageIds.mapNotNull { infos[it] }.chunked(perPage).forEach { chunk ->
            val g = GridPage(this, cols, rows, chunk.map { cellOf(it, true, Src.PAGE) }, (6 * d).toInt())
            g.setOnLongClickListener { openSettings(); true }
            list.add(g)
        }
        pages = list
        pager.offscreenPageLimit = maxOf(1, list.size)
        val cur = if (firstBuild) HOME else pager.currentItem
        firstBuild = false
        pager.adapter = PagesAdapter(list)
        pager.setCurrentItem(minOf(cur, list.size - 1), false)
        root.noSearch = pager.currentItem == 0
        dots.count = list.size
        dots.pos = pager.currentItem.toFloat()
    }

    fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    fun launch(a: AppInfo, v: View? = null) {
        if (isFolder(a.key)) return
        if (Guard.refresh(this) && !Guard.isExempt(a.pkg)) {
            val g = Guard.cfg(this)
            toast(if (g.enabled && !NavService.active) "فعّل خدمة الحماية (إمكانية الوصول) لاستخدام التطبيقات"
                  else "انتهى رصيدك — رصيد جديد خلال ${Guard.nextGrantMs(this) / 60000} دقيقة")
            return
        }
        st.bump(a.key)
        search?.close(false); folder?.close(false)
        try {
            val wo = Win.options(this, ComponentName(a.pkg, a.cls), st, tbPx())
            val o: Bundle? = wo ?: (if (v != null && v.width > 0) ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle() else null)
            startActivity(a.launchIntent(), o)
        } catch (e: Exception) { toast("تعذر فتح التطبيق") }
    }

    fun openSearch(onPick: ((AppInfo) -> Unit)? = null) {
        if (search != null || picker != null || folder != null) return
        val s = SearchOverlay(this, onPick)
        frame.addView(s, FrameLayout.LayoutParams(-1, -1))
        search = s
        s.open()
    }

    private fun openFolder(fk: String, origin: View) {
        if (folder != null) return
        val f = st.folders().firstOrNull { it.key == fk } ?: return
        val byKey = all.associateBy { it.key }
        val o = FolderOverlay(this, fk, f.apps.mapNotNull { byKey[it] }, f.name, origin)
        frame.addView(o, FrameLayout.LayoutParams(-1, -1))
        folder = o
        o.open()
    }

    // ---------- السحب والإفلات ----------
    private fun inside(v: View, x: Float, y: Float): Boolean {
        val l = IntArray(2); v.getLocationOnScreen(l)
        return x >= l[0] && x <= l[0] + v.width && y >= l[1] && y <= l[1] + v.height
    }

    private fun startDrag(c: AppCell, src: Src) {
        c.parent?.requestDisallowInterceptTouchEvent(true)
        c.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val g = AppCell(this, c.app, src != Src.DOCK, st.scale)
        g.isClickable = false; g.isLongClickable = false
        g.scaleX = 1.15f; g.scaleY = 1.15f; g.alpha = 0.92f
        frame.addView(g, FrameLayout.LayoutParams(c.width, c.height))
        dragGhost = g
        c.alpha = 0.25f
        dragX0 = c.lastX; dragY0 = c.lastY; dragMoved = false
        root.blockSwipe = true
        c.dragging = true
        c.onDragMove = { x, y -> dragMove(x, y) }
        c.onDragEnd = { x, y, cancel -> dragEnd(c, src, x, y, cancel) }
        dragMove(c.lastX, c.lastY)
    }

    private fun dragMove(x: Float, y: Float) {
        val g = dragGhost ?: return
        if (!dragMoved && (abs(x - dragX0) > 10 * d || abs(y - dragY0) > 10 * d)) dragMoved = true
        val loc = IntArray(2); frame.getLocationOnScreen(loc)
        g.translationX = x - loc[0] - g.layoutParams.width / 2f
        g.translationY = y - loc[1] - g.layoutParams.height / 2f
        val pl = IntArray(2); pager.getLocationOnScreen(pl)
        val zone = 36 * d
        val phys = if (x < pl[0] + zone) -1 else if (x > pl[0] + pager.width - zone) 1 else 0
        val dir = if (pager.layoutDirection == View.LAYOUT_DIRECTION_RTL) -phys else phys
        if (dir != edgeDir) {
            edgeDir = dir
            hnd.removeCallbacks(flip)
            if (dir != 0) hnd.postDelayed(flip, 450)
        }
    }

    private fun dragEnd(c: AppCell, src: Src, x: Float, y: Float, cancel: Boolean) {
        hnd.removeCallbacks(flip); edgeDir = 0
        root.blockSwipe = false
        dragGhost?.let { frame.removeView(it) }
        dragGhost = null
        c.alpha = 1f
        val moved = dragMoved
        frame.post {
            if (cancel) { /* لا شيء */ }
            else if (!moved) appMenu(c.app)
            else drop(c.app, src, x, y)
        }
    }

    private fun drop(item: AppInfo, src: Src, x: Float, y: Float) {
        val id = item.key
        // 1) الدوك (تطبيقات فقط، نسخة)
        if (inside(dock, x, y)) {
            if (isFolder(id)) return
            val list = st.dock.toMutableList()
            val oi = list.indexOf(id)
            if (oi >= 0) list.removeAt(oi)
            else if (list.size >= 5) { toast("الدوك ممتلئ (5 تطبيقات)"); return }
            var idx = 0
            for (i in 0 until dock.childCount) {
                val v = dock.getChildAt(i); val vl = IntArray(2); v.getLocationOnScreen(vl)
                val center = if (land) vl[1] + v.height / 2f else vl[0] + v.width / 2f
                if (center < (if (land) y else x)) idx++
            }
            if (oi in 0 until idx) idx--
            list.add(idx.coerceIn(0, list.size), id)
            st.dock = list; rebuild()
            return
        }
        if (src == Src.DOCK) st.dock = st.dock - id
        val cur = pager.currentItem
        val page = pages.getOrNull(cur) ?: run { rebuild(); return }
        if (page is HomePage) {
            if (!inside(page, x, y)) { rebuild(); return }
            val (i, hit) = page.favDrop(x, y)
            place(id, i, hit, true)
        } else if (page is GridPage) {
            val (i, hit) = page.dropInfo(x, y) ?: run { rebuild(); return }
            place(id, pages.take(cur).count { it is GridPage } * perPage + i, hit, false)
        } else { rebuild() }
    }

    /** نقل (لا نسخ): الرئيسية والمجلدات تسحب التطبيق من أماكنه الأخرى تلقائياً. */
    private fun place(id: String, idx: Int, hit: Boolean, toHome: Boolean) {
        val list = (if (toHome) curHomeIds else curPageIds).toMutableList()
        val tId = list.getOrNull(idx)
        if (hit && tId != null && tId != id && !isFolder(id)) {
            val fk = if (isFolder(tId)) { addToFolder(tId, id); tId } else newFolder(tId, id)
            list.remove(id)
            val ti = list.indexOf(tId)
            if (ti >= 0) list[ti] = fk
            commit(list, toHome, id)
            return
        }
        list.remove(id)
        list.add(idx.coerceIn(0, list.size), id)
        commit(list, toHome, id)
    }

    private fun commit(list: List<String>, toHome: Boolean, id: String) {
        val members = st.folders().flatMap { it.apps }.toSet()
        if (toHome) st.home = list.filter { it !in members || isFolder(it) }
        else {
            st.home = (st.home - id).filter { it !in members }
            st.order = list + st.order.filter { it !in list }
        }
        rebuild()
    }

    private fun saveFolder(fk: String, fn: (FolderData) -> FolderData) {
        st.saveFolders(st.folders().map { if (it.key == fk) fn(it) else it })
    }

    private fun newFolder(a: String, b: String): String {
        val f = FolderData(System.currentTimeMillis().toString(36), "مجلد", listOf(a, b), "")
        st.saveFolders(st.folders() + f)
        return f.key
    }

    private fun addToFolder(fk: String, id: String) {
        saveFolder(fk) { if (id in it.apps) it else it.copy(apps = it.apps + id) }
    }

    fun removeFromFolder(fk: String, id: String) {
        val f = st.folders().firstOrNull { it.key == fk } ?: return
        val rest = f.apps - id
        if (rest.size <= 1) dissolve(fk, rest.firstOrNull())
        else saveFolder(fk) { it.copy(apps = rest, main = if (it.main == id) "" else it.main) }
        rebuild()
    }

    private fun dissolve(fk: String, keep: String?) {
        st.saveFolders(st.folders().filter { it.key != fk })
        st.home = st.home.mapNotNull { if (it == fk) keep else it }
        st.order = st.order.mapNotNull { if (it == fk) keep else it }
        st.setIconPath(fk, null)
    }

    // ---------- القوائم ----------
    fun folderMenu(fk: String) {
        val f = st.folders().firstOrNull { it.key == fk } ?: return
        val info = infos[fk] ?: return
        Sheet(this).header(f.name, info)
            .action("إعادة تسمية المجلد") { folder?.close(false); renameFolder(f) }
            .action("تغيير أيقونة المجلد") { folder?.close(false); pickIcon(info) }
            .action("التطبيق الأساسي (ضغطتان متتاليتان)") { folder?.close(false); pickMain(f) }
            .action("حذف المجلد (إعادة التطبيقات)", true) { folder?.close(false); dissolve(fk, null); rebuild() }
            .show()
    }

    private fun renameFolder(f: FolderData) {
        val et = EditText(this).apply {
            setText(f.name); setSelection(text.length); setTextColor(Color.WHITE); textSize = 17f
            isSingleLine = true; background = rr(0x26FFFFFF, 16 * d)
            val p = (16 * d).toInt(); setPadding(p, p, p, p)
        }
        Sheet(this).header("اسم المجلد", infos[f.key]).view(et)
            .action("حفظ") { saveFolder(f.key) { it.copy(name = et.text.toString().ifBlank { "مجلد" }) }; rebuild() }
            .show()
    }

    private fun pickMain(f: FolderData) {
        val sh = Sheet(this).header("اختر التطبيق الأساسي")
        sh.action("بدون (فتح المجلد دائماً)") { saveFolder(f.key) { it.copy(main = "") }; rebuild() }
        f.apps.mapNotNull { k -> all.firstOrNull { it.key == k } }.forEach { a ->
            sh.action(a.label) { saveFolder(f.key) { it.copy(main = a.key) }; rebuild() }
        }
        sh.show()
    }

    fun folderAppMenu(fk: String, a: AppInfo) {
        Sheet(this).header(a.label, a)
            .action("تعيين كتطبيق أساسي للمجلد") { folder?.close(false); saveFolder(fk) { it.copy(main = a.key) }; rebuild() }
            .action("إخراج من المجلد") { folder?.close(false); removeFromFolder(fk, a.key) }
            .action("إعادة تسمية") { rename(a) }
            .action("تغيير الأيقونة") { pickIcon(a) }
            .action("إخفاء التطبيق") { folder?.close(false); hideApp(a) }
            .action("معلومات التطبيق") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)))
            }
            .show()
    }

    private fun hideApp(a: AppInfo) {
        st.folders().filter { a.key in it.apps }.forEach { removeFromFolder(it.key, a.key) }
        st.hidden = st.hidden + a.key; st.home = st.home - a.key; st.dock = st.dock - a.key
        rebuild()
    }

    fun appMenu(a: AppInfo) {
        if (isFolder(a.key)) { folderMenu(a.key); return }
        val inHome = a.key in st.home; val inDock = a.key in st.dock
        val inWin = a.key in st.winApps
        Sheet(this).header(a.label, a)
            .action(if (inHome) "إزالة من الشاشة الرئيسية" else "نقل إلى الشاشة الرئيسية") {
                st.home = if (inHome) st.home - a.key else st.home + a.key; rebuild()
            }
            .action(if (inDock) "إزالة من الدوك" else "إضافة إلى الدوك") {
                if (inDock) { st.dock = st.dock - a.key }
                else if (st.dock.size >= 5) { toast("الدوك ممتلئ (5 تطبيقات)") }
                else { st.dock = st.dock + a.key }
                rebuild()
            }
            .action("إضافة إلى تقسيم الشاشة") { addToSplit(a) }
            .action("إعادة تسمية") { rename(a) }
            .action("تغيير الأيقونة") { pickIcon(a) }
            .action("تغيير التصنيف: ${Cats.names[catIndex(a)]}") { pickCategory(a) }
            .action(if (inWin) "إيقاف: نافذة عمودية في الوضع الأفقي" else "تشغيل: نافذة عمودية في الوضع الأفقي") {
                st.winApps = if (inWin) st.winApps - a.key else st.winApps + a.key
            }
            .action("إخفاء التطبيق") { hideApp(a) }
            .action("معلومات التطبيق") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)))
            }
            .action("إلغاء التثبيت", true) {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)))
            }
            .show()
    }

    private fun rename(a: AppInfo) {
        val et = EditText(this).apply {
            setText(a.label); setSelection(text.length); setTextColor(Color.WHITE); textSize = 17f
            isSingleLine = true; background = rr(0x26FFFFFF, 16 * d)
            val p = (16 * d).toInt(); setPadding(p, p, p, p)
        }
        Sheet(this).header("إعادة تسمية", a).view(et)
            .action("حفظ") { st.setName(a.key, et.text.toString()); reload() }
            .action("استعادة الاسم الأصلي") { st.setName(a.key, ""); reload() }
            .show()
    }

    private fun pickIcon(a: AppInfo) {
        pendingKey = a.key
        Sheet(this).header("تغيير الأيقونة", a)
            .action("اختيار صورة من المعرض") {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_ICON)
            }
            .action("استعادة الأيقونة الأصلية") { st.setIconPath(a.key, null); reload() }
            .show()
    }

    private fun saveIcon(u: Uri) {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 768) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return
            val th = ThumbnailUtils.extractThumbnail(bmp, 256, 256)
            val f = File(filesDir, "ic_" + pendingKey.hashCode() + ".png")
            FileOutputStream(f).use { th.compress(Bitmap.CompressFormat.PNG, 100, it) }
            st.setIconPath(pendingKey, f.absolutePath)
            reload()
        } catch (e: Exception) { toast("تعذر تحميل الصورة") }
    }

    // ---------- التصنيفات ----------
    fun catIndex(a: AppInfo): Int = st.cat(a.pkg) ?: autoCat.getOrPut(a.pkg) { Cats.auto(this, a) }

    private fun libCell(a: AppInfo): AppCell {
        val c = AppCell(this, a, true, st.scale)
        c.setOnClickListener { launch(a, c) }
        c.setOnLongClickListener { appMenu(a); true }
        return c
    }

    private fun copyPrompt() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("prompt", Cats.prompt(visible)))
        toast("تم نسخ الأمر — الصقه في أي ذكاء اصطناعي ثم انسخ رده")
    }

    private fun importClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (t.isBlank()) { toast("الحافظة فارغة"); return }
        val m = Cats.parse(t, all.map { it.pkg }.toSet())
        if (m.isEmpty()) { toast("لم أجد تصنيفات صالحة في النص المنسوخ"); return }
        st.setCats(m)
        rebuild()
        toast("تم تصنيف ${m.size} تطبيق")
    }

    private fun pickCategory(a: AppInfo) {
        val sh = Sheet(this).header("تصنيف: " + a.label, a)
        val cur = catIndex(a)
        Cats.names.forEachIndexed { i, n ->
            sh.action((if (i == cur) "✓ " else "") + n) { st.setCats(mapOf(a.pkg to i)); rebuild() }
        }
        sh.show()
    }

    // ---------- الإعدادات ----------
    fun openSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0) }
        val lbl = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; text = "حجم الأيقونات ${(st.scale * 100).toInt()}%" }
        val seek = SeekBar(this).apply {
            max = 40; progress = ((st.scale * 100).toInt() - 60).coerceIn(0, 40)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { lbl.text = "حجم الأيقونات ${60 + p}%" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { st.scale = (60 + progress) / 100f; rebuild() }
            })
        }
        box.addView(lbl); box.addView(seek)
        val gOn = Guard.cfg(this).enabled
        val sh = Sheet(this).header("إعدادات الواجهة").view(box)
            .action("تقسيم الشاشة ⊞  (4 نوافذ)") { splitMenu() }
            .action("إضافة ويدجت") { pickWidget() }
        if (st.hidden.isNotEmpty()) sh.action("التطبيقات المخفية (${st.hidden.size})") { hiddenMenu() }
        if (!NavService.isEnabled(this)) {
            sh.action("تفعيل شريط التنقل") {
                toast("فعّل «Aero شريط التنقل» من الخدمات المثبتة")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        } else {
            sh.action(if (st.taskbar) "شريط التنقل: مفعّل — اضغط للإيقاف" else "شريط التنقل: متوقف — اضغط للتشغيل") { st.taskbar = !st.taskbar }
        }
        sh.action(if (gOn) "تحديد الاستخدام: مفعّل" else "تحديد الاستخدام: متوقف (اختياري)") { GuardUi(this).show() }
        sh.action("المزيد…") { advancedMenu() }
        sh.show()
    }

    // ---------- تقسيم الشاشة ----------
    /** قائمة بسيطة: تشغيل بضغطة واحدة؛ الخانات الفارغة تُملأ تلقائياً بالأكثر استخداماً. */
    fun splitMenu() {
        val byKey = all.associateBy { it.key }
        val sl = st.splitSlots
        val sh = Sheet(this).header("تقسيم الشاشة — 4 نوافذ")
        sh.action("▶  تشغيل التقسيم") { startSplit() }
        for (i in 0..3) {
            val a = byKey[sl[i]]
            sh.action("النافذة ${i + 1}:  ${a?.label ?: "تلقائي (الأكثر استخداماً)"}") {
                openSearch { picked ->
                    val l = st.splitSlots.toMutableList(); l[i] = picked.key; st.splitSlots = l
                    splitMenu()
                }
            }
        }
        if (sl.any { it.isNotEmpty() }) sh.action("مسح الاختيار (تلقائي)") { st.splitSlots = emptyList() }
        if (NavService.inst?.split?.running == true) sh.action("إيقاف التقسيم", true) { NavService.inst?.split?.stop() }
        sh.show()
    }

    private fun startSplit() {
        val svc = NavService.inst
        if (svc == null) {
            toast("فعّل «Aero شريط التنقل» ثم ارجع واضغط تشغيل")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val blocked = Guard.refresh(this)
        val list = Split.resolve(all, st).map { c ->
            if (c != null && blocked && !Guard.isExempt(c.packageName)) null else c
        }
        if (list.all { it == null }) { toast("لا توجد تطبيقات متاحة للتقسيم"); return }
        list.forEach { c -> if (c != null) st.bump(c.packageName + "/" + c.className) }
        svc.split?.start(list)
    }

    private fun addToSplit(a: AppInfo) {
        val l = st.splitSlots.toMutableList()
        if (a.key in l) { toast("التطبيق موجود في التقسيم"); return }
        val i = l.indexOf("")
        if (i < 0) { toast("الخانات الأربع ممتلئة — امسحها من «تقسيم الشاشة»"); return }
        l[i] = a.key; st.splitSlots = l
        toast("أُضيف إلى النافذة ${i + 1}")
    }

    private fun advancedMenu() {
        val sh = Sheet(this).header("المزيد")
        if (st.widgets.isNotEmpty()) sh.action("حذف ويدجت") { removeWidgetMenu() }
        sh.action(if (st.windowed) "التطبيقات العمودية: نافذة في الوضع الأفقي (اضغط لملء الشاشة)" else "التطبيقات العمودية: ملء الشاشة (اضغط للنافذة)") { st.windowed = !st.windowed }
        sh.action("تفعيل النوافذ الحرة (خيارات المطور)") {
            toast("فعّل: Enable freeform windows + Force activities to be resizable ثم أعد التشغيل")
            try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (e: Exception) {}
        }
        sh.action("تغيير الخلفية") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "الخلفية")) }
        sh.show()
    }

    private fun hiddenMenu() {
        val sh = Sheet(this).header("التطبيقات المخفية — اضغط للإظهار")
        all.filter { it.key in st.hidden }.forEach { a -> sh.action(a.label) { st.hidden = st.hidden - a.key; rebuild() } }
        sh.show()
    }

    // ---------- الويدجت ----------
    private fun widgetView(id: Int): View? {
        val info = mgr.getAppWidgetInfo(id) ?: return null
        val hv = host.createView(this, id, info)
        hv.setOnLongClickListener { removeWidgetSheet(id); true }
        hv.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = ((r - l) / d).toInt(); val h = ((b - t) / d).toInt()
            if (w > 0 && h > 0) hv.updateAppWidgetSize(null, w, h, w, h)
        }
        val w = FrameLayout(this)
        w.addView(hv, FrameLayout.LayoutParams(-1, -1))
        w.tag = maxOf(info.minHeight, (80 * d).toInt())
        w.clipToOutline = true
        w.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 22 * d) }
        }
        return w
    }

    fun pickWidget() {
        if (picker != null) return
        pager.setCurrentItem(HOME, true)
        val p = WidgetPicker(this)
        frame.addView(p, FrameLayout.LayoutParams(-1, -1))
        picker = p
        p.open()
    }

    fun widgetDropIndex(x: Float, y: Float): Int? {
        val page = pages.getOrNull(pager.currentItem) as? HomePage ?: return null
        return if (inside(page, x, y)) page.widgetIndexAt(y) else null
    }

    fun addWidget(p: AppWidgetProviderInfo, index: Int?) {
        pendingIndex = index
        val id = host.allocateAppWidgetId()
        pendingWidget = id
        if (mgr.bindAppWidgetIdIfAllowed(id, p.provider)) configureOrAdd(id)
        else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider), REQ_BIND)
    }

    private fun configureOrAdd(id: Int) {
        val info = mgr.getAppWidgetInfo(id)
        if (info?.configure != null) host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
        else finishAdd(id)
    }

    private fun finishAdd(id: Int) {
        val l = st.widgets.toMutableList()
        l.add((pendingIndex ?: l.size).coerceIn(0, l.size), id)
        st.widgets = l
        pendingIndex = null
        rebuild()
        pager.setCurrentItem(HOME, true)
    }

    private fun removeWidget(id: Int) {
        host.deleteAppWidgetId(id)
        st.widgets = st.widgets - id
        rebuild()
    }

    private fun removeWidgetSheet(id: Int) {
        Sheet(this).header("ويدجت").action("حذف الويدجت", true) { removeWidget(id) }.show()
    }

    private fun removeWidgetMenu() {
        val sh = Sheet(this).header("حذف ويدجت")
        st.widgets.forEach { id ->
            val name = mgr.getAppWidgetInfo(id)?.loadLabel(packageManager) ?: "ويدجت $id"
            sh.action(name, true) { removeWidget(id) }
        }
        sh.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        when (rc) {
            REQ_ICON -> { val u = data?.data; if (res == RESULT_OK && u != null) saveIcon(u) }
            REQ_BIND -> if (res == RESULT_OK) configureOrAdd(pendingWidget) else host.deleteAppWidgetId(pendingWidget)
            REQ_CONFIG -> if (res == RESULT_OK) finishAdd(pendingWidget) else host.deleteAppWidgetId(pendingWidget)
        }
    }
}
